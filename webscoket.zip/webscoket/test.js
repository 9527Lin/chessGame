function getY_0_TickArr(yesterdayClose, AllData) {
  if (yesterdayClose && AllData.length) {
    let maxValue = Math.max(...AllData)
    let valueTickArr = [],
      percentTickArr = []
    let lessArr = [],
      moreArr = [],
      lessPercentArr = [],
      morePercentArr = []
    let incrementPercent = Math.abs(
      (maxValue - yesterdayClose) / yesterdayClose || 0.2 //防止 maxValue===yesterdayClose
    )
    for (let index = 1; index <= 3; index++) {
      let incrementValue = (yesterdayClose * incrementPercent * index).toFixed(
        2
      )
      moreArr.push(
        parseFloat((yesterdayClose + parseFloat(incrementValue)).toFixed(2))
      )
      lessArr.push(
        parseFloat((yesterdayClose - parseFloat(incrementValue)).toFixed(2))
      )
      lessPercentArr.push(
        parseFloat((incrementPercent * index * 100).toFixed(2))
      )
      morePercentArr.push(
        parseFloat((incrementPercent * index * 100).toFixed(2))
      )
    }
    valueTickArr = [
      ...moreArr.sort((x, y) => y - x),
      yesterdayClose,
      ...lessArr.sort((x, y) => y - x)
    ]
    percentTickArr = [
      ...morePercentArr.sort((x, y) => y - x),
      0.0,
      ...lessPercentArr.sort((x, y) => x - y)
    ]
    return { valueTickArr: valueTickArr, percentTickArr: percentTickArr }
  }
  else{
      return []
  }
}

let arr = [264.3, 263.5, 264.7, 264.7, 264.8, 263.7, 264.9]
console.log(getY_0_TickArr([], arr))
