let ws = require('ws')
let socketServer = ws.Server
let uuid = require('uuid')
let wss = new socketServer({ port: 8001 }) //创建websocketServer实例监听8090端口
let clients = [] //创建客户端列表，用于保存客户端及相关连接信息
console.log('开始建立连接...')
let gameUserArr = []
let gameStatus = {
  isReady: false,
  isSortFul: false
}
let pokerArr_1 = [
  {
    cardID: 'card_1',
    card: 'club_1'
  },
  {
    cardID: 'card_2',
    card: 'club_1'
  },
  {
    cardID: 'card_3',
    card: 'club_3'
  },
  {
    cardID: 'card_4',
    card: 'club_4'
  },
  {
    cardID: 'card_5',
    card: 'club_5'
  },
  {
    cardID: 'card_6',
    card: 'club_6'
  },
  {
    cardID: 'card_7',
    card: 'club_6'
  },
  {
    cardID: 'card_8',
    card: 'club_6'
  }
]
//快捷组合
let pokerComb = {
  //对子
  pair: [
    {
      combID: 'pair_1',

      value: ['card_1', 'card_2']
    },
    {
      combID: 'pair_2',

      value: ['card_6', 'card_7']
    },
    {
      combID: 'pair_3',

      value: ['card_6', 'card_8']
    },
    {
      combID: 'pair_4',

      value: ['card_7', 'card_8']
    }
  ],
  //顺子
  straight: [
    {
      combID: 'straight_1',

      value: ['card_3', 'card_4', 'card_5']
    },
    {
      combID: 'straight_2',
      value: ['card_4', 'card_5', 'card_6']
    },
    {
      combID: 'straight_3',
      value: ['card_4', 'card_5', 'card_7']
    },
    {
      combID: 'straight_4',
      value: ['card_4', 'card_5', 'card_8']
    }
  ],
  //炸弹
  bomb: [
    {
      combID: 'bomb_1',
      value: ['card_6', 'card_7', 'card_8']
    }
  ],
  //同花顺
  straight_flush: []
}
//自动摆法
let autoComb = [
  [
    ['card_1', 'card_3'],
    ['card_2', 'card_4', 'card_5'],
    ['card_6', 'card_8', 'card_7']
  ],
  [
    ['card_1', 'card_5'],
    ['card_2', 'card_4', 'card_3'],
    ['card_7', 'card_8', 'card_6']
  ]
]
let baseData = {
  gameType: 'bz',
  allGame: 10, //总局数
  currentGame: 0, //当前局数
  roomNum: 88888, //房间号
  gamePeopleNum: 2,
  roomHostID: 1,
  gameDesc: '特殊牌型 四个王 翻倍 红波浪 去掉2-4', //游戏玩法
  gameUserArr: [],
  pokerData: {}
  //   //已加入游戏用户
  //   {
  //     userID: 3,
  //     nickName: 'aaa',
  //     avatar:
  //       'http://g.hiphotos.baidu.com/zhidao/pic/item/8c1001e93901213fce85790251e736d12e2e95bd.jpg',
  //     score: 0, //用户分数
  //     isReady: true //是否准备
  //   }
  // ]
}
function broadcastSend(data) {
  clients.forEach(function(v, i) {
    if (v.ws.readyState === ws.OPEN) {
      v.ws.send(data)
    }
  })
}
//监听连接
wss.on('connection', function(ws) {
  let client_uuid = uuid.v4()
  clients.push({
    id: client_uuid,
    ws: ws
  })

  console.log(`client ${client_uuid} connected`)
  /**
   * 关闭服务，从客户端监听列表删除
   */
  function closeSocket() {
    for (let i = 0; i < clients.length; i++) {
      if (clients[i].id == client_uuid) {
        console.log(client_uuid + '已关闭链接')
        // let disconnect_message = `${nickname} has disconnected`
        // broadcastSend('notification', disconnect_message, nickname)
        clients.splice(i, 1)
      }
    }
    gameUserArr = []
  }
  /*监听消息*/
  ws.on('message', function(message) {
    const data = JSON.parse(message)
    const action = data.action
    switch (action) {
      case 'setUserInfo':
        gameUserArr.push(data.data)
        break
      case 'createRoom':
        const roomHost = data.data
        baseData.roomHostID = roomHost.userID
        roomHost.isReady = true
        baseData.gameUserArr.push(roomHost)
        broadcastSend(JSON.stringify(baseData))
        break
      case 'joinRoom':
        const gameUser = data.data
        gameUser.isReady = false
        baseData.gameStatus = 'joinRoomed'
        baseData.gameUserArr.push(gameUser)
        broadcastSend(JSON.stringify(baseData))
        break
      case 'ready':
        const userID_ready = data.data.userID
        baseData.gameUserArr.filter((item, index, self) => {
          if (item.userID === userID_ready) {
            item.isReady = true
          }
        })
        broadcastSend(JSON.stringify(baseData))
        break
      case 'startGame':
        let pokerArr = []
        const pokerNum = baseData.gameType === 'bz' ? 8 : 13
        const color = ['spade', 'heart', 'club', 'diamond']
        for (let index = 1; index <= pokerNum; index++) {
          const pokerObj = {}
          const colorIndex = Math.floor(Math.random() * 4)
          const boardNum = Math.floor(Math.random() * (13 - 1 + 1) + 1)
          const keyName = `card_${index}`
          pokerObj.cardID = keyName
          pokerObj.card = `${color[colorIndex]}_${boardNum}`
          pokerObj.isShow = true
          pokerObj.active = false
          pokerArr.push(pokerObj)
        }
        baseData.pokerData.pokerArr = pokerArr
        baseData.pokerData.autoComb = autoComb
        baseData.gameStatus = 'startGame'
        // baseData.pokerData.pokerComb = pokerComb
        broadcastSend(JSON.stringify(baseData))
        break
      //理牌
      case 'sortPoker':
        const userID_sortPoker = data.data.userID
        baseData.gameUserArr.filter((item, index, self) => {
          if (item.userID === userID_sortPoker) {
            item.isSortFul = true
          }
        })
        baseData.gameStatus = 'gameIng'
        broadcastSend(JSON.stringify(baseData))
        break
      //比牌
      case 'comparePoker':
        console.log(data.data)
        const userID_comparePoker = data.data.userID
        const confirmPokerObj = data.data.confirmPokerObj
        //比牌逻辑......
        const newObj = {}
        const resultPokerObj = {}
        resultPokerObj.userID = userID_comparePoker
        newObj.userID = userID_comparePoker
        for (const key in confirmPokerObj) {
          const tempObj = {}
          tempObj.poker = confirmPokerObj[key]
          tempObj.score = -1
          resultPokerObj[key] = tempObj
        }
        resultPokerObj.resultScore = -4
        // console.log(resultPokerObj)
        baseData.gameStatus = 'gameEnd'
        baseData.comparePoker = resultPokerObj
        broadcastSend(JSON.stringify(baseData))
        break
      //退出房间
      case 'exitRoom':
        const exitUserID = data.data.userID
        const newGameUserArr = []
        baseData.gameUserArr.filter((item, index, self) => {
          if (item.userID !== exitUserID) {
            newGameUserArr.push(item)
          }
        })
        baseData.gameUserArr = newGameUserArr
        broadcastSend(JSON.stringify(baseData))
        break
    }
  })
  /*监听断开连接*/
  ws.on('close', function() {
    closeSocket()
  })
})
console.log('WebSocket建立完毕')
