const autoprefixer = require('autoprefixer')
const pxtorem = require('postcss-pxtorem')
const path = require('path')
function resolve(dir) {
  return path.join(__dirname, dir)
}
module.exports = {
  outputDir: 'docs',
  baseUrl: process.env.NODE_ENV === 'production' ? '/vant-demo/' : '/',
  css: {
    loaderOptions: {
      postcss: {
        plugins: [
          autoprefixer(),
          pxtorem({
            rootValue: 37.5,
            propList: ['*']
          })
        ]
      }
    }
  },
  chainWebpack: config => {
    config.resolve.alias
      .set('@$', resolve('src'))
      .set('@js', resolve('src/assets/js'))
      .set('components', resolve('src/components'))
      .set('indexImg', resolve('src/assets/img/index'))
      .set('loginImg', resolve('src/assets/img/login'))
      .set('pokerImg', resolve('src/assets/img/poker'))
      .set('gameImg', resolve('src/assets/img/game'))
      .set('loadingImg', resolve('src/assets/img/loading'))
  }
}
