<template>
  <div class="flex player-box" :style="gameUser.position">
    <user-box
      :avatar="gameUser.avatar"
      :userID="gameUser.userID"
      :nickName="gameUser.nickName"
      :score="gameUser.score"
      :isReady="gameUser.isReady"
    ></user-box>
    <SortFulCard :currUserID="gameUser.userID" v-if="gameUser.isSortFul"></SortFulCard>
    <sort-card-loading v-else></sort-card-loading>
  </div>
</template>

<script>
  import UserBox from "components/game/userBox";
  import PutCard from "components/game/putCard";
  import SortCardLoading from "components/game/sortCardLoading";
  import SortFulCard from "./sortFulcard";
  export default {
    props: {
      gameUser: Object
    },
    data() {
      return {};
    },
    components: { UserBox, PutCard, SortCardLoading, SortFulCard },

    methods: {
      gameData(key) {
        return this.$store.state.gameWetscoketData[key];
      }
    }
  };
</script>

<style scoped>
  .player-box {
    position: absolute;
    width: 75px;
    height: 45px;
    /* background-color: beige; */
    justify-content: flex-start;
  }
</style>
