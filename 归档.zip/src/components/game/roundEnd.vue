<template>
  <div class="round-result">
    <!-- <div :class="key" v-for="value,key in selPokerData">
      <img
        v-for="cardObj in value"
        :class="gameType==='bz'?'poker_bz':'poker_ssz'"
        :src="require(`pokerImg/${pokerName}/${cardObj.card}.png`)"
      >
    </div>-->
  </div>
</template>

<script>
  export default {
    props: {
      gameResult: Object
    },
    data() {
      return {};
    },
    mounted() {
        console.log("roundend");
        
      console.log(this.$store.state.gameWetscoketData.comparePoker);
    },
    computed: {
      pokerName() {
        return this.$store.state.gameSetting.pokerName;
      }
    }
  };
</script>

<style scoped>
  .round-result {
    /* position: relative; */
    margin-left: 2px;
    flex-direction: column;
    align-self: flex-end;
    justify-content: flex-start;
    width: 50px;
    height: 60px;
  }
  .round-result .poker_bz,
  .round-result .poker_ssz {
    width: 18px;
  }
  .round-result .selPoker_0 {
    position: relative;
    width: 33px;
    height: 50px;
  }
  .round-result .selPoker_1 {
    position: relative;
    width: 100%;
    height: 29.44px;
  }
  .round-result .selPoker_2 {
    position: relative;
    width: 100%;
    height: 29.44px;
  }
  /* selPoker_2 */
  .round-result .selPoker_0 .poker_bz:nth-child(1),
  .round-result .selPoker_1 .poker_bz:nth-child(1),
  .round-result .selPoker_2 .poker_bz:nth-child(1) {
    position: absolute;
    bottom: 0;
    left: 0;
  }
  .round-result .selPoker_0 .poker_bz:nth-child(2),
  .round-result .selPoker_1 .poker_bz:nth-child(2),
  .round-result .selPoker_2 .poker_bz:nth-child(2) {
    position: absolute;
    bottom: 0;
    left: 13.5px;
  }
  .round-result .selPoker_0 .poker_bz:nth-child(3),
  .round-result .selPoker_1 .poker_bz:nth-child(3),
  .round-result .selPoker_2 .poker_bz:nth-child(3) {
    position: absolute;
    bottom: 0;
    left: 27px;
  }
  .round-result .selPoker_0 .poker_ssz:nth-child(1),
  .round-result .selPoker_1 .poker_ssz:nth-child(1),
  .round-result .selPoker_2 .poker_ssz:nth-child(1) {
    position: absolute;
    bottom: 0;
    left: 0;
  }
  .round-result .selPoker_0 .poker_ssz:nth-child(2),
  .round-result .selPoker_1 .poker_ssz:nth-child(2),
  .round-result .selPoker_2 .poker_ssz:nth-child(2) {
    position: absolute;
    bottom: 0;
    left: 7.5px;
  }
  .round-result .selPoker_0 .poker_ssz:nth-child(3),
  .round-result .selPoker_1 .poker_ssz:nth-child(3),
  .round-result .selPoker_2 .poker_ssz:nth-child(3) {
    position: absolute;
    bottom: 0;
    left: 15px;
  }
  .round-result .selPoker_0 .poker_ssz:nth-child(4),
  .round-result .selPoker_1 .poker_ssz:nth-child(4),
  .round-result .selPoker_2 .poker_ssz:nth-child(4) {
    position: absolute;
    bottom: 0;
    left: 22.5px;
  }
  .round-result .selPoker_0 .poker_ssz:nth-child(5),
  .round-result .selPoker_1 .poker_ssz:nth-child(5),
  .round-result .selPoker_2 .poker_ssz:nth-child(5) {
    position: absolute;
    bottom: 0;
    left: 30px;
  }
</style>
