<template>
    <transition name="alertBox">
        <div class="alert-box alert-robot" v-if="$store.state.alertBoxState.isShowRobotBox">
        </div>
    </transition>
</template>

<script>
    export default {
      data() {
        return {}
      },
      methods: {
        isShowBox(flag) {
          this.$store.commit('setAlertBoxState', { isShowRobotBox: flag })
        }
      }
    }
</script>

<style scoped>
    .alert-robot {
      top: calc(50% - 20px);
      z-index: 9999;
      width: 200px;
      height: 40px;
      background-repeat: no-repeat;
      background-size: 100%;
      background-image: url('~gameImg/tip.png');
    }
    .alert-robot .img-btn {
      position: absolute;
      width: 20px;
      top: 10px;
      right: 0;
    }
</style>
