<template>
  <div class="flex fast-btn">
    <img
      class="img-btn"
      v-for="btn,index in btns"
      :src="btn.isDisabled?btn.imgs.disabledImg:btn.imgs.normalImg"
      @click="btnClickEven(btn.name,index)"
    >
  </div>
</template>

<script>
  import {
    SelDouByIndex,
    SelShunByIndex,
    SelThrByIndex,
    SelFlowerByIndex,
    dataConversion
  } from "@js/lib/bz_lib";
  export default {
    data() {
      return {
        btns: [],
        pokerComb: {},
        //存放按钮当前组合
        btn_0_CombIndex: 0,
        btn_1_CombIndex: 0,
        btn_2_CombIndex: 0,
        btn_3_CombIndex: 0
      };
    },
    mounted() {
      this.createPokerCombData();
      this.createFastBtnJson();
    },
    watch: {
      "$store.state.tempState.updatePokerCombData"(newValue) {
        if (newValue) {
          this.createPokerCombData();
          this.createFastBtnJson();
          //重置按钮index
          for (let index = 0; index < 4; index++) {
            this[`btn_${index}_CombIndex`] = 0;
          }
        }
      }
    },
    methods: {
      createPokerCombData() {
        const pokerArr = this.$store.state.gameWetscoketData.pokerData.pokerArr;
        const libData = dataConversion(pokerArr);
        const newData = {};
        // //对子
        const pair = SelDouByIndex(libData);
        //炸弹
        const bomb = SelThrByIndex(libData);
        // //顺子
        const straight = SelShunByIndex(libData);
        //同花顺
        const straight_flush = SelFlowerByIndex(libData);
        const pokerComb = { pair, bomb, straight, straight_flush };
        for (const combName in pokerComb) {
          if (pokerComb.hasOwnProperty(combName)) {
            const combs = pokerComb[combName];
            const cmobObjArr = [];
            combs.filter((combItem, index, self) => {
              const combObj = {};
              const combValue = [];
              combItem.filter(combItem_item => {
                combValue.push(combItem_item.id);
              });
              combObj.combID = `${combName}_comb_${index}`;
              combObj.value = combValue;
              cmobObjArr.push(combObj);
            });
            newData[combName] = cmobObjArr;
          }
        }
        this.pokerComb = newData;
        const stateObj = {
          label: "updatePokerCombData",
          value: false
        };
        this.$store.commit("setTempState", stateObj);
      },
      createFastBtnJson() {
        let btns = [];
        const pokerComb = this.pokerComb;
        for (const combName in pokerComb) {
          const btn = {};
          const imgs = {};
          const comb = pokerComb[combName];
          const normalImg = require(`gameImg/game/bz/chooseTypeBtn_${combName}_Normal.png`);
          const disabledImg = require(`gameImg/game/bz/chooseTypeBtn_${combName}_Disable.png`);
          imgs.disabledImg = disabledImg;
          imgs.normalImg = normalImg;
          btn.name = combName;
          btn.isDisabled = !comb.length;
          btn.imgs = imgs;
          btns.push(btn);
        }
        this.btns = btns;
        this.pokerComb = pokerComb;
      },
      btnClickEven(btnName, btnIndex) {
        const comb = this.pokerComb[btnName];
        const combNum = comb.length;
        const combIndex = this[`btn_${btnIndex}_CombIndex`];
        const selectPokerArr = this.$store.state.tempState.selectPoker;
        this.$store.commit("cancelAllActivePoker");
        for (const cardID of comb[combIndex].value) {
          const activeObj = {
            cardID: cardID,
            isActive: true
          };
          const selectPokerObj = {
            action: "add",
            cardID: cardID
          };
          this.$store.commit("setActivePokerbyCardID", activeObj);
        }
        if (combIndex < combNum - 1) {
          this[`btn_${btnIndex}_CombIndex`]++;
        } else {
          this[`btn_${btnIndex}_CombIndex`] = 0;
        }
      }
    }
  };
</script>

<style scoped>
  .fast-btn {
    height: 100%;
  }
  .fast-btn > img {
    padding: 0 5px;
    height: 100%;
  }
</style>
