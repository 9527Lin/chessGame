<template>
  <div class="flex put-card" v-if="$store.state.alertBoxState.isShowPutCard">
    <div class="card-container_column">
      <select-card-container
        v-for="item,index in cardContainers"
        :cardNum="item.cardNum"
        :styleObj="item.styleObj"
        :containerIndex="index"
        :ref="`selectContainer_${index}`"
      ></select-card-container>
    </div>
    <div class="flex card-row">
      <div class="flex poker-area" :style="pokerAreaStyle">
        <Poker
          class="poker"
          v-for="pokerObj,index in pokerArr"
          :leftSliderX="leftSliderX"
          :rightSliderX="rightSliderX"
          :pokerObj="pokerObj"
          :index="index"
        ></Poker>
        <img
          class="img-btn"
          v-if="showPutBtnGroup"
          @click="recoverAllPoker"
          src="~gameImg/game/bz/pokerRecoveryClick.png"
        >
        <img
          class="img-btn"
          v-if="showPutBtnGroup"
          @click="confirmPutPoker"
          src="~gameImg/game/bz/manualSureBtnClick.png"
        >
      </div>
      <img class="img-btn" @click="autoPutPoker" src="~gameImg/game/bz/autoChooseTypeNormal.png">
    </div>
    <div class="flex fast-btn-group">
      <FastBtn></FastBtn>
    </div>
  </div>
</template>

<script>
  import Poker from "./poker";
  import SelectCardContainer from "./selectCardContainer";
  import FastBtn from "./fastBtn";
  import "../../assets/js/utils/hammeris";
  export default {
    data() {
      return {
        activePoker: [],
        leftSliderX: 0,
        rightSliderX: 0,
        autoCombIndex: 0,
        showPutBtnGroup: false,
        cardContainers: [
          {
            cardNum: 2,
            styleObj: {
              position: "absolute",
              left: "42.7%",
              top: "5%",
              width: "16%",
              height: "22.5%",
              zIndex: "11000",
              backgroundRepeat: "no-repeat",
              backgroundSize: "100% 50%"
            }
          },
          {
            cardNum: 3,
            styleObj: {
              position: "absolute",
              left: "39.5%",
              top: "15%",
              width: "22%",
              height: "22.5%",
              zIndex: "11001",
              backgroundRepeat: "no-repeat",
              backgroundSize: "100% 70%"
            }
          },
          {
            cardNum: 3,
            styleObj: {
              position: "absolute",
              left: "39.5%",
              top: "30%",
              width: "22%",
              height: "22.5%",
              zIndex: "11002",
              backgroundRepeat: "no-repeat",
              backgroundSize: "100% 100%"
            }
          }
        ]
      };
    },
    components: { Poker, SelectCardContainer, FastBtn },
    watch: {
      "$store.state.alertBoxState.isShowPutCard": function(newVlue) {
        if (newVlue) {
          let $this = this;
          this.$nextTick(function() {
            $this.pokerSlideFun();
          });
        }
      },
      "$store.state.gameWetscoketData.pokerData": {
        handler: function(newValue) {
          let $this = this;
          const pokerArr = newValue.pokerArr;
          if (pokerArr) {
            let isShowArr = pokerArr.filter(poker => poker.isShow);
            this.showPutBtnGroup = !isShowArr.length;
          }
        },
        deep: true
      }
    },
    computed: {
      pokerAreaStyle() {
        return {
          width: this.gameData("gameType") === "bz" ? "60%" : "70%",
          height: "100%"
        };
      },
      pokerArr() {
        return this.gameData("pokerData").pokerArr;
      }
    },
    methods: {
      gameData(key) {
        return this.$store.state.gameWetscoketData[key];
      },
      pokerSlideFun() {
        let $this = this;
        let cardRowEl = document.getElementsByClassName("card-row")[0];
        let hammertime = new Hammer(cardRowEl);
        hammertime.on("panright", function(ev) {
          $this.rightSliderX = ev.center.x;
        });
        hammertime.on("panleft", function(ev) {
          $this.leftSliderX = ev.center.x;
        });
      },
      //取消选牌
      cancelSelectPoker() {
        this.$store.commit("setSelectPoker", { action: "empty", cardID: "" });
      },
      //自动摆牌
      autoPutPoker() {
        let $this = this;
        //所有poker的isShow=false
        this.$store.commit("displayStateAllPoker", false);
        //将webscoket中的自动摆法对应到selPokerContainerState中
        const autoCombs = this.gameData("pokerData").autoComb;
        const maxAutoCombIndex = autoCombs.length - 1;
        const findPokerObj = cardID => {
          let pokerObj = {};
          const pokerArr = $this.gameData("pokerData").pokerArr;
          pokerArr.filter(poker => {
            if (poker.cardID === cardID) pokerObj = Object.assign({}, poker);
          });
          delete pokerObj.active;
          delete pokerObj.isShow;
          return pokerObj;
        };
        let currIndex = this.autoCombIndex;
        this.autoCombIndex = currIndex < maxAutoCombIndex ? currIndex + 1 : 0;
        autoCombs[currIndex].filter((comb, index, self) => {
          let tempArr = [];
          comb.filter(cardID => {
            tempArr.push(findPokerObj(cardID));
          });
          const stateObj = {
            label: "pokerData",
            index: index,
            value: tempArr
          };
          const tempStateObj = {
            label: "updatePokerCombData",
            value: true
          };
          this.$store.commit("setSelPokerContainerState", stateObj);
          this.$store.commit("setTempState", tempStateObj);
        });
      },
      //回收poker
      recoverAllPoker() {
        //清空selPokerContainerState
        this.$store.commit("clearSelPoker");
        //设置所有poker为true
        this.$store.commit("displayStateAllPoker", true);
        //更新快捷按钮
        const tempStateObj = {
          label: "updatePokerCombData",
          value: true
        };
        this.$store.commit("setTempState", tempStateObj);
      },
      //确定出牌
      confirmPutPoker() {
        //保存牌组
        const $state = this.$store.state;
        const $userID = $state.userInfo.userID;
        const $pokerData = $state.tempState.selPokerContainerState.pokerData;
        // const sortFulPokerArr = Object.assign({}, $pokerData);
        // //清空已选牌组
        // this.$store.commit("clearSelPoker");
        //隐藏put-card
        this.$store.commit("setAlertBoxState", { isShowPutCard: false });
        $state.gameWebscoketObj.send(
          JSON.stringify({
            action: "sortPoker",
            data: { userID: $userID }
          })
        );
      }
    }
  };
</script>

<style scoped>
  .put-card {
    height: 90%;
    width: 100%;
    /* background-color: aqua; */
    flex-direction: column;
    justify-content: flex-start;
    z-index: 9998;
  }
  .card-container_column {
    width: 100%;
    height: 60%;
    flex-direction: column;
    background-size: 55%;
    background-repeat: no-repeat;
    background-position: center;
    background-image: url("~gameImg/game/bz/manualChooseType8Bg2.png");
  }
  .card-row {
    position: relative;
    width: 100%;
    height: 25%;
    /* background-color: black; */
  }
  .card-row > .img-btn {
    position: absolute;
    right: 5px;
    bottom: 0;
    height: 35%;
  }
  .second-card {
    position: absolute;
    left: calc(50% - 37.5px);
    top: 32px;
    width: 80px;
    height: 22.5%;
    background-repeat: no-repeat;
    background-size: 100% 60%;
    background-image: url("~gameImg/game/bz/PokerCandSelect.png");
  }
  .third-card {
    position: absolute;
    left: calc(50% - 37.5px);
    top: 60px;
    width: 80px;
    height: 22.5%;
    background-repeat: no-repeat;
    background-size: 100% 100%;
    background-image: url("~gameImg/game/bz/PokerCandSelect.png");
  }
  .fast-btn-group {
    margin-top: 5px;
    width: 100%;
    height: 20px;
  }
  .poker-area > .img-btn {
    width: 50px;
    padding: 0 10px;
  }
</style>
