<template>
  <transition name="alertBox">
    <div class="flex alert-box alert-diss-room" v-if="$store.state.alertBoxState.isShowDissRoomBox">
      <p>{{isRoomHost?'解散':'退出'}}房间不扣钻石，是否确定{{isRoomHost?'解散':'退出'}}？</p>
      <div class="flex btn-group">
        <img
          class="img-btn"
          @click="isShowBox(false)"
          src="~gameImg/dissRoom/modalWindowCancelBtn.png"
        >
        <img class="img-btn" @click="confirmBtnEven" src="~gameImg/dissRoom/modalWindowSureBtn.png">
      </div>
    </div>
  </transition>
</template>

<script>
  export default {
    data() {
      return {};
    },
    computed: {
      //判断是否为房主
      isRoomHost() {
        const roomHostID = this.gameData("roomHostID");
        return parseInt(this.userID) === parseInt(roomHostID);
      }
    },
    methods: {
      isShowBox(flag) {
        this.$store.commit("setAlertBoxState", { isShowDissRoomBox: flag });
      },
      confirmBtnEven() {
        this.isShowBox(false);
        this.$router.push("/index");
      },
      gameData(key) {
        return this.$store.state.gameWetscoketData[key];
      }
    }
  };
</script>

<style scoped>
  .alert-diss-room {
    top: calc(50% - 55px);
    z-index: 9999;
    width: 190px;
    height: 100px;
    background-repeat: no-repeat;
    flex-direction: column;
    justify-content: flex-start;
    background-size: 100%;
    background-image: url("~gameImg/dissRoom/modalWindowBg.png");
  }
  .alert-diss-room p:nth-child(1) {
    margin-top: 30px;
    font-size: 10px;
    font-weight: 600;
    color: rgb(145, 92, 27);
  }
  .btn-group {
    position: absolute;
    bottom: 15px;
    justify-content: space-around;
    width: 100%;
  }
  .btn-group > img {
    width: 35%;
  }
</style>
