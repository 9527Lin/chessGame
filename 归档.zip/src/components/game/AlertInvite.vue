<template>
  <transition name="alertBox">
    <div class="flex alert-box alert-invite" v-if="$store.state.alertBoxState.isShowInviteBox">
      <img
        class="img-btn"
        src="~indexImg/userinfo/win_closeBtnSelected.png"
        @click="isShowBox(false)"
      >
      <div class="flex xl-box">
        <img src="~gameImg/invite/share_cl.png" class="img-btn">
        <img src="~gameImg/invite/share_cl_title.png">
      </div>
      <div class="flex wx-box">
        <img src="~gameImg/invite/share_wx.png" class="img-btn">
        <img src="~gameImg/invite/share_wx_title.png">
      </div>
    </div>
  </transition>
</template>

<script>
  export default {
    data() {
      return {};
    },
    methods: {
      isShowBox(flag) {
        this.$store.commit("setAlertBoxState", { isShowInviteBox: flag });
      }
    }
  };
</script>

<style scoped>
  .alert-invite {
    top: calc(50% - 50px);
    left: 85px;
    z-index: 9999;
    width: 100px;
    height: 55px;
    background-repeat: no-repeat;
    background-size: 100%;
    justify-content: space-between;
    background-image: url("~gameImg/invite/CLShareWindowBg.png");
  }
  .alert-invite > .img-btn {
    position: absolute;
    width: 18px;
    top: -5px;
    right: -5px;
  }
  .xl-box {
    width: 35%;
    height: 70%;
    flex-direction: column;
    margin-left: 10px;
    /* background-color: rgba(0, 0, 0, 0.6); */
  }
  .xl-box > img:nth-child(1) {
    width: 80%;
  }
  .xl-box > img:nth-child(2) {
    width: 100%;
  }
  .wx-box {
    width: 35%;
    height: 70%;
    margin-right: 10px;
    flex-direction: column;
    /* background-color: rgba(0, 0, 0, 0.9); */
  }
  .wx-box > img:nth-child(1) {
    width: 80%;
  }
  .wx-box > img:nth-child(2) {
    width: 100%;
  }
</style>
