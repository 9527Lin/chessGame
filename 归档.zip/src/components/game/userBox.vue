<template>
  <div class="flex user-box" v-bind:style="position">
    <img class="ishomeowner" v-if="isRoomHost" src="~gameImg/roomOwner.png">
    <div class="flex avatar">
      <img :src="avatar">
      <img v-if="isReady&&!isRoomHost" src="~gameImg/readyStatusIcon.png">
    </div>
    <div class="flex nickname">{{nickName}}</div>
    <div class="flex score">
      <img src="~gameImg/goldImage.png">
      <span class="flex">{{score}}</span>
    </div>
  </div>
</template>

<script>
  export default {
    props: {
      avatar: String,
      userID: Number,
      nickName: String,
      score: Number,
      isReady: Boolean,
      position: Object
    },
    data() {
      return {};
    },
    computed: {
      //判断是否为房主
      isRoomHost() {
        const roomHostID = this.gameData("roomHostID");
        return parseInt(this.userID) === parseInt(roomHostID);
      }
    },
    methods: {
      gameData(key) {
        return this.$store.state.gameWetscoketData[key];
      }
    },
  };
</script>

<style scoped>
  .user-box {
    align-self: flex-end;
    /* position: absolute; */
    position: relative;
    width: 25px;
    height: 35px;
    flex-direction: column;
    justify-content: flex-start;
    background-image: url("~gameImg/gameResultHeadBg1.png");
    background-size: 100%;
    background-repeat: no-repeat;
  }
  .ishomeowner {
    width: 12px;
    position: absolute;
    top: 0;
    right: 0;
    z-index: 2;
  }
  .avatar {
    position: relative;
    /* position: absolute; */
    margin-top: 9%;
    width: 19px;
    height: 19px;
  }
  .avatar img:nth-child(1) {
    width: 100%;
    height: 100%;
  }
  .avatar img:nth-child(2) {
    position: absolute;
    bottom: 0;
    width: 100%;
  }
  .nickname {
    width: calc(100% - 8px);
    height: 5px;
    padding: 0 2px;
    font-size: 3px;
    color: white;
  }
  .nickname > p {
    height: 100%;
  }
  .score {
    width: calc(100% - 8px);
    height: 5px;
    padding: 0 2px;
    font-size: 3px;
    color: white;
    justify-content: flex-start;
  }
  .score > img {
    width: 5px;
  }
  .score > span {
    flex: 1;
    font-size: 3px;
  }
</style>
