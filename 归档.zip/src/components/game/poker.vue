<template>
  <div
    class="poker"
    v-if="pokerObj.isShow"
    :style="pokerStyle"
    :class="{'active':pokerObj.active}"
    @click.stop="pokerClickEven"
  >
    <img :src="require(`pokerImg/${pokerName}/${pokerObj.card}.png`)">
  </div>
</template>

<script>
  import "../../assets/js/utils/hammeris";
  export default {
    props: {
      index: Number,
      pokerObj: Object,
      leftSliderX: Number,
      rightSliderX: Number,
      pokerAreaOffsetLeft: Number
    },
    data() {
      return {
        pokerStyle: {},
        pokerWidth: 0
      };
    },
    watch: {
      rightSliderX(newSliderX) {
        const startLeft = this.$el.offsetLeft;
        const endRight = startLeft + this.pokerWidth;
        if (startLeft < newSliderX && newSliderX < endRight) {
          const obj = {
            index: this.index,
            isActive: true
          };
          this.$store.commit("setActivePokerbyIndex", obj);
        }
      },
      leftSliderX(newSliderX) {
        const startRight = this.$el.offsetLeft + this.pokerWidth;
        const endLeft = this.$el.offsetLeft;
        if (startRight > newSliderX && newSliderX < endLeft) {
          const obj = {
            index: this.index,
            isActive: false
          };
          this.$store.commit("setActivePokerbyIndex", obj);
        }
      },
      'pokerObj.active'(newVlaue) {
        const tempObj = {
          action: newVlaue ? "add" : "del",
          cardID: this.pokerObj.cardID
        };
        this.$store.commit("setSelectPoker", tempObj);
      }
    },
    mounted() {
      this.createPokerStyle();
    },
    computed: {
      pokerName() {
        return this.$store.state.gameSetting.pokerName;
      }
    },
    methods: {
      gameData(cardID) {
        return this.$store.state.gameWetscoketData[cardID];
      },
      createPokerStyle() {
        this.$nextTick(function() {
          //为了得到一个确定的z-index
          const index = parseInt(this.pokerObj.cardID.replace("card_", "")) - 1;
          const cardNum = this.gameData("gameType") === "bz" ? 8 : 13;
          const parentEl = document.getElementsByClassName("poker-area")[0];
          const parentHieght = parentEl.clientHeight;
          const parentWidth = parentEl.clientWidth;
          const realPokerWidth = parentHieght * (131 / 176);
          const pokerWidth = parentWidth / cardNum;
          const left = (parentWidth - realPokerWidth * cardNum) / (cardNum - 1);
          this.pokerWidth = pokerWidth;
          this.pokerStyle = {
            marginLeft: index ? left + "px" : "0px",
            width: "auto",
            zIndex: 10000 + index,
            height: "100%"
          };
        });
      },
      pokerClickEven() {
        const obj = {
          index: this.index,
          isActive: !this.pokerObj.active
        };
        this.$store.commit("setActivePokerbyIndex", obj);
      }
    }
  };
</script>

<style scoped>
  .poker {
    /* background-color: aquamarine; */
  }
  .poker img {
    height: 100%;
    box-shadow: -0.2px 0px 5px rgba(0, 0, 0, 0.5);
  }
  .active {
    transform: translateY(-5px);
  }
</style>
