<template>
  <transition name="slideInRight">
    <div class="flex setting-panel" v-if="$store.state.alertBoxState.isShowSettingPanel">
      <img
        src="~gameImg/setting/roomSettingUpBtnNormal.png"
        @click="setAlertBoxSatet('isShowSettingPanel',false)"
      >
      <div class="flex music-setting">
        <img
          v-for="btn in soundBtns"
          :src="btn.isActive?btn.clicked:btn.normal"
          @click="btn.isActive=!btn.isActive"
        >
      </div>
      <div class="flex desktop-custom">
        <img src="~gameImg/setting/settingRoomBgTitle.png">
        <div class="flex">
          <img
            v-for="btn,btnIndex in desktopData.btns"
            :src="desktopData.activeBtnIndex===btnIndex?btn.clicked:btn.normal"
            @click="chooseBtnEven('desktopData',btnIndex)"
          >
        </div>
      </div>
      <div class="flex poker-shape">
        <img src="~gameImg/setting/settingPokerXTitle.png">
        <img
          v-for="btn,btnIndex in pokerShapeData.btns"
          :src="pokerShapeData.activeBtnIndex===btnIndex?btn.clicked:btn.normal"
          @click="chooseBtnEven('pokerShapeData',btnIndex)"
        >
      </div>
      <div class="flex poker-name">
        <img src="~gameImg/setting/settingPokerMTitle.png">
        <div class="flex">
          <img
            v-for="btn,btnIndex in pokerNameData.btns"
            :src="pokerNameData.activeBtnIndex===btnIndex?btn.clicked:btn.normal"
            @click="chooseBtnEven('pokerNameData',btnIndex)"
          >
        </div>
      </div>
      <div class="flex put-poker-type">
        <img src="~gameImg/setting/settingPokerXTitle.png">
        <img
          v-for="btn,btnIndex in putPokerTypeData.btns"
          :src="putPokerTypeData.activeBtnIndex===btnIndex?btn.clicked:btn.normal"
          @click="chooseBtnEven('putPokerTypeData',btnIndex)"
        >
      </div>
      <div class="flex play-method">
        <img
          src="~gameImg/setting/settingLookIcon.png"
          @click="setAlertBoxSatet('isShowRuleBox',true)"
        >
      </div>
      <div class="flex diss-room">
        <img
          class="img-btn"
          :src="isRoomHost?require('gameImg/setting/roomSettingChooseExitNormal.png'):require('gameImg/setting/roomSettingChooseQuitNormal.png')"
          @click="dissRoomBtnEven()"
        >
      </div>
    </div>
  </transition>
</template>

<script>
  const Data = {
    desktopData: [
      "thirteenGameBg1.png",
      "thirteenGameBg2.png",
      "thirteenGameBg3.png",
      "thirteenGameBg4.png"
    ],
    pokerName: [
      "pokerImg/poker_small_1",
      "pokerImg/poker_small_2",
      "pokerImg/poker_small_3",
      "pokerImg/poker_small_4",
      "pokerImg/poker_small_5",
      "pokerImg/poker_small_6",
      "pokerImg/poker_small_7",
      "pokerImg/poker_small_8"
    ]
  };
  const createDesktopBtns = _ => {
    const btns = [];
    Data.desktopData.map((value, index, self) => {
      const btn = {
        name: value,
        normal: require(`gameImg/setting/settingRoomBg${index + 1}.png`),
        clicked: require(`gameImg/setting/settingRoomBg${index + 1}Select.png`)
      };
      btns.push(btn);
    });
    return btns;
  };
  const createPokerName = _ => {
    const btns = [];
    Data.pokerName.map((value, index, self) => {
      const btn = {
        imgSrc: value,
        normal: require(`gameImg/setting/pokerM${index + 1}.png`),
        clicked: require(`gameImg/setting/pokerM${index + 1}Select.png`)
      };
      btns.push(btn);
    });
    return btns;
  };
  export default {
    data() {
      return {
        soundBtns: [
          {
            name: "music",
            isActive: false,
            normal: require("gameImg/setting/music_off.png"),
            clicked: require("gameImg/setting/music_on.png")
          },
          {
            name: "soundEffect",
            isActive: false,
            normal: require("gameImg/setting/soundEffect_off.png"),
            clicked: require("gameImg/setting/soundEffect_on.png")
          }
        ],
        desktopData: {
          label: "backgroundImgName",
          activeBtnIndex: 0,
          btns: createDesktopBtns()
        },
        pokerShapeData: {
          label: "pokerShape",
          activeBtnIndex: 0,
          btns: [
            {
              name: "rect",
              normal: require("gameImg/setting/rect_normal.png"),
              clicked: require("gameImg/setting/rect_clicked.png")
            },
            {
              name: "sector",
              normal: require("gameImg/setting/sector_normal.png"),
              clicked: require("gameImg/setting/sector_clicked.png")
            }
          ]
        },
        pokerNameData: {
          label: "pokerName",
          activeBtnIndex: 0,
          btns: createPokerName()
        },
        putPokerTypeData: {
          label: "putPokerType",
          activeBtnIndex: 0,
          btns: [
            {
              name: "cross",
              normal: require("gameImg/setting/placeCardCross.png"),
              clicked: require("gameImg/setting/placeCardCrossSelect.png")
            },
            {
              name: "vertical",
              normal: require("gameImg/setting/placeCardVertical.png"),
              clicked: require("gameImg/setting/placeCardVerticalSelect.png")
            }
          ]
        }
      };
    },
    computed: {
      //判断是否为房主
      isRoomHost() {
        const userID=this.$store.state.userInfo.userID;
        const roomHostID = this.gameData("roomHostID");
        return parseInt(userID) === parseInt(roomHostID);
      }
    },
    methods: {
      gameData(key) {
        return this.$store.state.gameWetscoketData[key];
      },
      setAlertBoxSatet(boxStateName, state) {
        const alertBoxObj = { [boxStateName]: state };
        this.$store.commit("setAlertBoxState", alertBoxObj);
      },
      chooseBtnEven(dataName, btnIndex) {
        let settingItemData = this[dataName];
        settingItemData.activeBtnIndex = btnIndex;
        //生成传输对象
        const settingObj = {
          label: settingItemData.label,
          value: settingItemData.btns[btnIndex].name
        };
        this.$store.commit("setSettingState", settingObj);
      },
      dissRoomBtnEven() {
        this.setAlertBoxSatet("isShowSettingPanel", false);
        this.setAlertBoxSatet("isShowDissRoomBox", true);
      }
    }
  };
</script>

<style scoped>
  /* 动画 */
  @keyframes slideInRight {
    0% {
      -webkit-transform: translateX(100%);
      transform: translateX(100%);
      will-change: transform;
    }

    100% {
      -webkit-transform: translateX(0);
      transform: translateX(0);
      will-change: transform;
    }
  }
  .slideInRight-enter-active {
    animation: slideInRight 0.3s;
  }
  .slideInRight-leave-active {
    animation: slideInRight 0.3s reverse;
  }
  .setting-panel {
    z-index: 9;
    justify-content: flex-start;
    align-items: flex-end;
    flex-direction: column;
  }
  .setting-panel > img:nth-child(1) {
    position: absolute;
    right: 2px;
    top: 2px;
    width: 15px;
  }
  .music-setting {
    justify-content: flex-start;
    padding-left: 8px;
    height: 16.5%;
    width: calc(100% - 13px);
    justify-content: flex-start;
  }
  .music-setting > img {
    width: 55px;
  }
  .music-setting > img:nth-child(2) {
    padding-left: 40px;
  }
  .desktop-custom {
    width: calc(100% - 8px);
    height: 19%;
    flex-direction: column;
  }
  .desktop-custom > img:nth-child(1) {
    width: 120px;
  }
  .desktop-custom > div {
    padding-top: 5px;
  }
  .desktop-custom > div > img {
    width: 24%;
  }
  .poker-shape {
    padding-left: 8px;
    height: 8%;
    width: calc(100% - 13px);
    justify-content: flex-start;
    /* background-color: rgba(0, 0, 0, 0.6); */
  }
  .poker-shape > img:nth-child(1) {
    width: 16px;
  }
  .poker-shape > img:nth-child(2),
  .poker-shape > img:nth-child(3) {
    padding-left: 10px;
    width: 45px;
  }
  .poker-name {
    padding-left: 8px;
    height: 17%;
    width: calc(100% - 13px);
    justify-content: flex-start;
  }
  .poker-name > img:nth-child(1) {
    width: 16px;
  }
  .poker-name > div {
    flex: 1;
    height: 100%;
    /* background-color: rgba(0, 0, 0, 0.6); */
  }
  .poker-name > div > img {
    width: 12%;
  }
  .put-poker-type {
    padding-left: 8px;
    height: 18%;
    width: calc(100% - 13px);
    justify-content: flex-start;
  }
  .put-poker-type > img:nth-child(1) {
    width: 16px;
  }
  .put-poker-type > img:nth-child(2),
  .put-poker-type > img:nth-child(3) {
    padding-left: 3px;
    width: 50px;
  }
  .play-method {
    width: calc(100% - 6.5px);
    height: 8%;
    justify-content: flex-end;
    background-size: 100%;
    background-repeat: no-repeat;
    background-image: url("~gameImg/setting/roomSettingChoosePlayNormal.png");
  }
  .play-method > img {
    height: 80%;
  }
  .diss-room {
    flex: 1;
    width: 100%;
  }
  .diss-room > img {
    width: 60px;
  }
</style>
