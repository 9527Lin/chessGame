<template>
  <div class="flex sort-ful-card">
    <div class="flex poker">
      <div :class="key" v-for="value,key in selPokerData" @click="changeShowPokerValue">
        <img
          v-if="showPokerValue"
          v-for="cardObj in value"
          :class="gameType==='bz'?'poker_bz':'poker_ssz'"
          :src="require(`pokerImg/${pokerName}/${cardObj.card}.png`)"
        >
        <img
          v-if="!showPokerValue"
          v-for="i in value.length"
          :class="gameType==='bz'?'poker_bz':'poker_ssz'"
          src="../../assets/img/game/game/bz/poke_small_55.png"
        >
      </div>
    </div>
    <div class="flex score" v-if="gameStatus==='gameEnd'">
      <span>-1</span>
      <span>-1</span>
      <span>-1</span>
      <span>-3</span>
    </div>
  </div>
</template>

<script>
  import RoundEnd from "./roundEnd";
  export default {
    props: {
      currUserID: Number
    },
    data() {
      return {
        showPokerValue: false,
        gameType: this.$store.state.gameWetscoketData.gameType,
        selPokerData: this.$store.state.tempState.selPokerContainerState.pokerData
      };
    },
    components: {
      RoundEnd
    },
    watch: {
      "$store.state.gameWetscoketData.gameUserArr"(newArr) {
        let $this = this;
        const userLen = newArr.length;
        const userID = this.$store.state.userInfo.userID;
        const confirmPokerObj = this.$store.state.tempState.selPokerContainerState
          .pokerData;
        const gameStatus = this.$store.state.gameWetscoketData.gameStatus;
        const userSortFulArr = newArr.filter(userObj => userObj.isSortFul);
        if (gameStatus !== "gameEnd") {
          if (userSortFulArr.length === userLen) {
            //执行比牌action
            const webscoketObj = {};
            webscoketObj.action = "comparePoker";
            webscoketObj.data = {
              userID: userID,
              confirmPokerObj: confirmPokerObj
            };
            this.$store.state.gameWebscoketObj.send(JSON.stringify(webscoketObj));
          }
        } else {
          this.showPokerValue = true;
        }
      }
    },
    computed: {
      pokerName() {
        return this.$store.state.gameSetting.pokerName;
      },
      gameStatus() {
        return this.gameData("gameStatus");
      }
    },
    methods: {
      changeShowPokerValue() {
        const userID = this.$store.state.userInfo.userID;
        if (this.currUserID === userID) {
          this.showPokerValue = !this.showPokerValue;
        }
      },
      gameData(key) {
        return this.$store.state.gameWetscoketData[key];
      }
    }
  };
</script>

<style scoped>
  .sort-ful-card {
    /* position: relative; */
    margin-left: 2px;
    /* flex-direction: column; */
    align-self: flex-end;
    justify-content: flex-start;
    width: 60px;
    height: 60px;
  }
  .sort-ful-card .poker {
    flex-direction: column;
    align-self: flex-end;
    justify-content: flex-start;
    width: 50px;
    height: 60px;
    position: relative;
  }
  .sort-ful-card .poker .poker_bz,
  .sort-ful-card .poker .poker_ssz {
    width: 18px;
  }
  .sort-ful-card .poker .selPoker_0 {
    position: relative;
    width: 33px;
    height: 50px;
  }
  .sort-ful-card .poker .selPoker_1 {
    position: relative;
    width: 100%;
    height: 29.44px;
  }
  .sort-ful-card .poker .selPoker_2 {
    position: relative;
    width: 100%;
    height: 29.44px;
  }
  /* selPoker_2 */
  .sort-ful-card .poker .selPoker_0 .poker_bz:nth-child(1),
  .sort-ful-card .poker .selPoker_1 .poker_bz:nth-child(1),
  .sort-ful-card .poker .selPoker_2 .poker_bz:nth-child(1) {
    position: absolute;
    bottom: 0;
    left: 0;
  }
  .sort-ful-card .poker .selPoker_0 .poker_bz:nth-child(2),
  .sort-ful-card .poker .selPoker_1 .poker_bz:nth-child(2),
  .sort-ful-card .poker .selPoker_2 .poker_bz:nth-child(2) {
    position: absolute;
    bottom: 0;
    left: 13.5px;
  }
  .sort-ful-card .poker .selPoker_0 .poker_bz:nth-child(3),
  .sort-ful-card .poker .selPoker_1 .poker_bz:nth-child(3),
  .sort-ful-card .poker .selPoker_2 .poker_bz:nth-child(3) {
    position: absolute;
    bottom: 0;
    left: 27px;
  }
  .sort-ful-card .poker .selPoker_0 .poker_ssz:nth-child(1),
  .sort-ful-card .poker .selPoker_1 .poker_ssz:nth-child(1),
  .sort-ful-card .poker .selPoker_2 .poker_ssz:nth-child(1) {
    position: absolute;
    bottom: 0;
    left: 0;
  }
  .sort-ful-card .poker .selPoker_0 .poker_ssz:nth-child(2),
  .sort-ful-card .poker .selPoker_1 .poker_ssz:nth-child(2),
  .sort-ful-card .poker .selPoker_2 .poker_ssz:nth-child(2) {
    position: absolute;
    bottom: 0;
    left: 7.5px;
  }
  .sort-ful-card .poker .selPoker_0 .poker_ssz:nth-child(3),
  .sort-ful-card .poker .selPoker_1 .poker_ssz:nth-child(3),
  .sort-ful-card .poker .selPoker_2 .poker_ssz:nth-child(3) {
    position: absolute;
    bottom: 0;
    left: 15px;
  }
  .sort-ful-card .poker .selPoker_0 .poker_ssz:nth-child(4),
  .sort-ful-card .poker .selPoker_1 .poker_ssz:nth-child(4),
  .sort-ful-card .poker .selPoker_2 .poker_ssz:nth-child(4) {
    position: absolute;
    bottom: 0;
    left: 22.5px;
  }
  .sort-ful-card .poker .selPoker_0 .poker_ssz:nth-child(5),
  .sort-ful-card .poker .selPoker_1 .poker_ssz:nth-child(5),
  .sort-ful-card .poker .selPoker_2 .poker_ssz:nth-child(5) {
    position: absolute;
    bottom: 0;
    left: 30px;
  }
  .score {
    width: 10px;
    height: 60px;
    align-items: flex-start;
    justify-content: flex-start;
    flex-direction: column;
  }
  .score > span {
    font-size: 10px;
  }
</style>
