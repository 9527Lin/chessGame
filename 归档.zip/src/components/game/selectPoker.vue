
<template>
  <div class="select-poker" :style="pokerStyle" ref="selectPoker">
    <img :src="require(`pokerImg/${pokerName}/${card}.png`)">
  </div>
</template>
<script>
  export default {
    props: {
      index: Number,
      card: String,
      cardNum: Number,
      parentClass: String,
      containerIndex: Number
    },
    data() {
      return {
        pokerStyle: {}
      };
    },
    mounted() {
      this.createPokerStyle();
    },
    computed: {
      pokerName() {
        return this.$store.state.gameSetting.pokerName;
      }
    },
    methods: {
      createPokerStyle() {
        this.$nextTick(function() {
          const parentEl = this.$refs.selectPoker.parentNode
          const parentHieght = parentEl.clientHeight;
          const parentWidth = parentEl.clientWidth;
          const realPokerWidth = parentHieght * (131 / 176);
          const pokerWidth = parentWidth / this.cardNum;
          const lastPokerLessWidth = realPokerWidth - pokerWidth;
          const left =
            this.index *
            (parentWidth / this.cardNum -
              lastPokerLessWidth / (this.cardNum - 1));
          this.pokerWidth = pokerWidth;
          this.pokerStyle = {
            position: "absolute",
            left: left + "px",
            width: "auto",
            zIndex: 10000 + this.index,
            height: "100%"
          };
        });
      }
    }
  };
</script>

<style scoped>
  .select-poker {
  }
  .select-poker img {
    height: 100%;
    box-shadow: -0.2px 0px 5px rgba(0, 0, 0, 0.5);
  }
</style>
