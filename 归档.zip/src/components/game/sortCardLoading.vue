<template>
  <div class="flex sort-card-loading">
    <img class="card" v-for="i in 8" :style="cardStyle(i)" src="~gameImg/game/bz/poke_small_55.png">
    <img class="sort-card-title" src="~gameImg/game/bz/sortCard.png">
  </div>
</template>

<script>
  export default {
    data() {
      return {};
    },
    methods: {
      cardStyle(index) {
        const interval = 6;
        return {
          position: "absolute",
          top: "0px",
          left: `${interval * (index - 1)}px`
        };
      }
    }
  };
</script>

<style scoped lang="less">
  @keyframes cardAnimation {
    0% {
      transform: translateY(-5px);
    }
    50% {
      transform: translateY(0px);
    }
    100% {
      transform: translateY(-5px);
    }
  }
  .cardAnimation-enter-active {
    animation: cardAnimation 0.5s;
  }
  .cardAnimation-leave-active {
    animation: cardAnimation 0.5s reverse;
  }
  .sort-card-loading {
    position: relative;
    margin-left: 2px;
    align-self: flex-start;
    justify-content: flex-start;
    width: 45px;
  }
  .card {
    width: 22px;
  }
  .sort-card-title {
    position: absolute;
    width: 100%;
    top: 10px;
  }
  //   @list: 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13;
  //   .card-loop(@list,@i:1,@val:extract(@list,@i)) when (length(@list)>=@i) {
  //     .card@{val} {
  //       width: 22px;
  //       animation: cardAnimation 1s @val * 1s;
  //     }
  //     .card-loop(@list, (@i+1));
  //   }
  //   .card-loop(@list);
</style>
