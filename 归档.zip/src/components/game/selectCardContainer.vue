<template>
  <div
    class="card-container"
    :style="styleObj"
    v-if="isShow"
    @click="isClick?clickContainerEven():false"
  >
    <img :style="pokerTypeStyle" :src="cardCombImgPath">
    <img
      v-if="isShowCloseBtn"
      @click.stop="clickContainerEven()"
      :style="closeBtnStyle"
      src="~gameImg/game/bz/closeBtnNormal1.png"
    >
    <SelectPoker
      v-for="pokerObj,index in $store.getters.selContainerPokerData(containerIndex)"
      :index="index"
      :card="pokerObj.card"
      :cardID="pokerObj.cardID"
      :cardNum="cardNum"
      :containerIndex="cIndex"
      :parentClass="'card-container'"
    ></SelectPoker>
  </div>
</template>

<script>
  import SelectPoker from "./selectPoker";
  import {
    SelDouByIndex,
    SelShunByIndex,
    SelThrByIndex,
    SelFlowerByIndex,
    dataConversion
  } from "@js/lib/bz_lib";
  export default {
    props: {
      containerIndex: Number,
      cardNum: Number,
      styleObj: Object
    },
    data() {
      return {
        selPokerData: [],
        isShow: false,
        isShowCloseBtn: false,
        isClick: true,
        cardCombImgPath: "",
        cIndex: this.containerIndex
      };
    },
    components: { SelectPoker },
    watch: {
      "$store.state.tempState.selectPoker": {
        handler: function(newArr) {
          let selPokerData = this.$store.state.tempState.selPokerContainerState
            .pokerData[`selPoker_${this.cIndex}`];
          if (selPokerData.length) {
            this.isClick = !newArr.length;
          } else {
            this.isShow = newArr.length === this.cardNum;
          }
        }
      },
      "$store.state.tempState.selPokerContainerState": {
        handler(newObj) {
          let selPokerData = newObj.pokerData[`selPoker_${this.cIndex}`];
          if (!selPokerData.length) {
            this.cardCombImgPath = "";
            this.isShow = false;
            this.isShowCloseBtn = false;
          } else {
            this.isShowCloseBtn = true;
            this.isShow = true;
            this.judgeCardCombType(
              this.$store.getters.selContainerPokerData(this.cIndex)
            );
          }
        },
        deep: true
      }
    },
    computed: {
      pokerTypeStyle() {
        return {
          position: "absolute",
          left: this.cIndex === 0 ? "-130%" : "-80%",
          top: this.cIndex === 0 ? "37%" : "54%",
          width: this.cIndex === 0 ? "80%" : "58.2%"
        };
      },
      closeBtnStyle() {
        return {
          position: "absolute",
          right: this.cIndex === 0 ? "-80%" : "-45.3%",
          top: this.cIndex === 0 ? "10%" : "30%",
          width: this.cIndex === 0 ? "30%" : "22%"
        };
      }
    },
    methods: {
      clickContainerEven() {
        //当selPokerData无值时，将选中poker的cardID放入selPokerData中，并将相应cardID的poker的isShow设为false,isClick=true
        //当selPokerData有值且selectPokerArr无值时，selPokerData值清空，pokerArr中相应的cardID的pokerObj的isShow=true,isClick=true
        //当selPokerData有值且selectPokerArr有值时，isClick=false
        let $this = this;
        let selectPokerArr = this.$store.state.tempState.selectPoker;
        let pokerArr = this.$store.state.gameWetscoketData.pokerData.pokerArr;
        // let selPokerData = this.selPokerData;
        let selPokerData = this.$store.getters.selContainerPokerData(this.cIndex);
        //反选取消时
        if (selPokerData.length) {
          selPokerData.filter((selectPokerObj, index, self) => {
            pokerArr.filter((pokerObj, index, self) => {
              const obj = {
                index: index,
                isActive: false
              };
              //显示poker
              if (selectPokerObj.cardID === pokerObj.cardID) {
                pokerObj.isShow = true;
              }
              //存入selectPoker
              this.$store.commit("setActivePokerbyIndex", obj);
            });
          });
          //清空selPokerData
          const stateObj = {
            label: "pokerData",
            value: [],
            index: this.cIndex
          };
          this.$store.commit("setSelPokerContainerState", stateObj);
        } else {
          let tempArr = [];
          selectPokerArr.filter((cardID, index, self) => {
            const selectPokerObj = {};
            pokerArr.filter((pokerObj, index, self) => {
              if (cardID === pokerObj.cardID) {
                selectPokerObj.cardID = pokerObj.cardID;
                selectPokerObj.card = pokerObj.card;
                pokerObj.isShow = false;
              }
            });
            tempArr.push(selectPokerObj);
          });
          const stateObj = {
            label: "pokerData",
            value: tempArr,
            index: this.cIndex
          };
          this.$store.commit("setSelPokerContainerState", stateObj);
        }
        //清空selectPokerArr
        this.$store.commit("setSelectPoker", { action: "empty", cardID: "" });
        //更新牌组合
        const stateObj = {
          label: "updatePokerCombData",
          value: true
        };
        this.$store.commit("setTempState", stateObj);
        this.judgeCardCombType(
          this.$store.getters.selContainerPokerData(this.cIndex)
        );
      },
      judgeCardCombType(pokerArr) {
        let cardCombImgPath = "";
        const libData = dataConversion(pokerArr);
        //对子
        const pair = SelDouByIndex(libData);
        //炸弹
        const bomb = SelThrByIndex(libData);
        //顺子
        const straight = SelShunByIndex(libData);
        //同花顺
        const straight_flush = SelFlowerByIndex(libData);
        if (pair.length) {
          cardCombImgPath = require("gameImg/game/bz/pokerType1.png");
        } else if (bomb.length) {
          cardCombImgPath = require("gameImg/game/bz/pokerType7.png");
        } else if (straight.length) {
          cardCombImgPath = require("gameImg/game/bz/pokerType4.png");
        } else if (straight_flush.length) {
          cardCombImgPath = require("gameImg/game/bz/pokerType8.png");
        } else {
          cardCombImgPath = require("gameImg/game/bz/pokerType0.png");
        }
        this.cardCombImgPath = cardCombImgPath;
      }
    }
  };
</script>

<style scoped>
  .card-container {
    background-image: url("~gameImg/game/bz/PokerCandSelect.png");
  }
</style>
