<template>
  <transition name="alertBox">
    <div
      class="alert-box alert-ssz"
      v-if="$store.state.alertBoxState.isShowSSZBox"
    >
      <img
        class="img-btn"
        src="~indexImg/userinfo/win_closeBtnSelected.png"
        @click="isShowBox(false)"
      >
      <div class="alert-content">
        <RoomMoney></RoomMoney>
        <PeopleNum :gameType="'ssz'"></PeopleNum>
        <board-num></board-num>
        <KingCard :gameType="'ssz'"></KingCard>
        <OutCardTime></OutCardTime>
        <GameDesc></GameDesc>
        <CreateRoom :gameType="'ssz'"></CreateRoom>
      </div>
    </div>
  </transition>
</template>

<script>
  import RoomMoney from "../roomSetingBtn/common/roomMoney";
  import PeopleNum from "../roomSetingBtn/common/peopleNum";
  import BoardNum from "../roomSetingBtn/common/boardNum";
  import KingCard from "../roomSetingBtn/common/kingCard";
  import OutCardTime from "../roomSetingBtn/common/outCardTime";
  import GameDesc from "../roomSetingBtn/SSZ/gameDesc";
  import CreateRoom from "../roomSetingBtn/common/createRoom";
  export default {
    watch: {
      "$store.state.alertBoxState.isShowSSZBox": {
        handler: function(newValue) {
          if (newValue) {
            const commonSetting = this.$store.state.roomSetting.common;
          }
        }
      },
      "$store.state.roomSetting": {
        handler: function(newSetting) {
          const commonSetting = newSetting.common; //公共设置
          const BZSetting = newSetting.bz; //八张设置
          const roomSetting = Object.assign(commonSetting, BZSetting);
          localStorage.setItem("ssz_roomSetting", JSON.stringify(roomSetting));
        },
        deep: true
      }
    },
    components: {
      RoomMoney,
      PeopleNum,
      BoardNum,
      KingCard,
      OutCardTime,
      GameDesc,
      CreateRoom
    },
    methods: {
      isShowBox(flag) {
        this.$store.commit("setAlertBoxState", { isShowSSZBox: flag });
      }
    }
  };
</script>

<style scoped>
  .alert-ssz {
    top: calc(50% - 100px);
    z-index: 9999;
    width: 350px;
    height: 200px;
    background-repeat: no-repeat;
    background-size: 100%;
    background-image: url("~indexImg/bz/bg.png");
  }
  .alert-ssz .img-btn:nth-child(1) {
    position: absolute;
    width: 20px;
    top: 15px;
    right: 17px;
  }
  .alert-content {
    width: calc(81.8% - 20px);
    height: 77%;
    left: 9%;
    top: 16%;
    position: absolute;
    padding: 0 10px;
  }
</style>
