<template>
  <transition name="alertBox">
    <div class="alert-box alert-userinfo" v-if="$store.state.alertBoxState.isShowUserInfoBox">
      <img
        class="img-btn"
        src="~indexImg/userinfo/win_closeBtnSelected.png"
        @click="isShowBox(false)"
      >
      <div class="flex left-content">
        <div class="avatar">
          <img :src="getUserInfoProperty('avatar')">
          <img :src="sexImg">
        </div>
        <div class="flex coin-num">{{getUserInfoProperty('coinNum')}}</div>
      </div>
      <div class="flex right-content">
        <span>玩家昵称: {{getUserInfoProperty('nickName')}}</span>
        <span>ID: {{getUserInfoProperty('userID')}}</span>
        <span>对局总数: {{getUserInfoProperty('allGame')}}</span>
        <span>玩家胜率: {{getUserInfoProperty('winRate')}}</span>
        <span>胜利局数: {{getUserInfoProperty('winGame')}}</span>
        <span>失败局数: {{getUserInfoProperty('failGame')}}</span>
      </div>
    </div>
  </transition>
</template>

<script>
  const boyImg = require("indexImg/userinfo/userInfo_Boy.png");
  const girlImg = require("indexImg/userinfo/userInfo_Girl.png");
  export default {
    data() {
      return {};
    },
    computed: {
      sexImg() {
        return this.getUserInfoProperty("sex") ? boyImg : girlImg;
      }
    },
    methods: {
      isShowBox(flag) {
        this.$store.commit("setAlertBoxState", { isShowUserInfoBox: flag });
      },
      getUserInfoProperty(property) {
        return this.$store.state.userInfo[property];
      }
    }
  };
</script>

<style scoped>
  .alert-userinfo {
    top: calc(50% - 85px);
    z-index: 9999;
    width: 230px;
    height: 170px;
    background-repeat: no-repeat;
    background-size: 100%;
    background-image: url("~indexImg/userinfo/userinfoBG.png");
  }
  .alert-userinfo .img-btn {
    position: absolute;
    width: 20px;
    top: 10px;
    right: 0;
  }
  .left-content {
    position: absolute;
    left: 6%;
    top: 20%;
    padding: 0 5px;
    width: calc(30% - 10px);
    flex-direction: column;
    justify-content: flex-start;
    height: 70%;
    /* background-color: rgba(0, 0, 0, 0.7); */
  }
  .avatar {
    width: 56px;
    height: 56px;
    background-size: 100%;
    padding: 2px;
    position: relative;
    background-repeat: no-repeat;
    background-image: url("~indexImg/userinfo/userWindow_iconBg.png");
  }
  .avatar > img {
    width: 99%;
    height: 99%;
    border-radius: 2px;
  }
  .avatar > img:nth-child(2) {
    width: 8px;
    height: 8px;
    right: 3px;
    bottom: 3px;
    position: absolute;
  }
  .coin-num {
    margin-top: 20px;
    font-size: 10px;
    width: 56px;
    height: 17px;
    color: #854a29;
    background-size: 100%;
    background-repeat: no-repeat;
    background-image: url("~indexImg/userinfo/roomCardBg.png");
  }
  .right-content {
    position: absolute;
    left: 43%;
    top: 25%;
    width: 44%;
    flex-direction: column;
    justify-content: space-between;
    align-items: flex-start;
    height: 57%;
    /* background-color: rgba(0, 0, 0, 0.7); */
  }
  .right-content > span {
    font-weight: 700;
    font-size: 8px;
  }
</style>
