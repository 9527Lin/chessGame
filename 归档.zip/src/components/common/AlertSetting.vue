<template>
  <transition name="alertBox">
    <div
      class="alert-box alert-setting"
      v-if="$store.state.alertBoxState.isShowSettingBox"
    >
      <img
        class="img-btn"
        src="~indexImg/userinfo/win_closeBtnSelected.png"
        @click="isShowBox(false)"
      >
      <span class="version">版本：2.2.2.2</span>
      <div class="flex switch-btn">
        <img
          v-for="item,index  in switchBtns"
          @click="switchBtnEven(index)"
          :src="item.is_on?item.on:item.off"
        >
      </div>
      <div class="flex other-btn">
        <img
          class="img-btn"
          @click="setAlertBoxSatet('isShowExitBox',true)"
          src="~indexImg/setting/settingWindow_logout.png"
        >
        <img
          class="img-btn"
          @click="$router.push('/login')"
          src="~indexImg/setting/settingWindow_changeAccount.png"
        >
      </div>
    </div>
  </transition>
</template>

<script>
  const getUserSetting = _ => {
    return JSON.parse(localStorage.getItem("userSetting"));
  };
  export default {
    data() {
      return {
        switchBtns: [
          {
            name: "music",
            is_on: getUserSetting() ? getUserSetting().music : true,
            off: require("indexImg/setting/music_off.png"),
            on: require("indexImg/setting/music_on.png")
          },
          {
            name: "soundEffect",
            is_on: getUserSetting() ? getUserSetting().soundEffect : true,
            off: require("indexImg/setting/soundEffect_off.png"),
            on: require("indexImg/setting/soundEffect_on.png")
          },
          {
            name: "shake",
            is_on: getUserSetting() ? getUserSetting().shake : true,
            off: require("indexImg/setting/shake_off.png"),
            on: require("indexImg/setting/shake_on.png")
          },
          {
            name: "mute",
            is_on: getUserSetting() ? getUserSetting().mute : false,
            off: require("indexImg/setting/mute_off.png"),
            on: require("indexImg/setting/mute_on.png")
          }
        ]
      };
    },
    methods: {
      isShowBox(flag) {
        this.$store.commit("setAlertBoxState", { isShowSettingBox: flag });
      },
      setAlertBoxSatet(boxStateName, state) {
        const alertBoxObj = { [boxStateName]: state };
        const settingBoxoBJ = { isShowSettingBox: false };
        this.$store.commit("setAlertBoxState", settingBoxoBJ);
        this.$store.commit("setAlertBoxState", alertBoxObj);
      },
      switchBtnEven(index) {
        let btnDataObj = this.switchBtns[index];
        let musicBtnObj = this.switchBtns[0];
        let soundEffectBtnObj = this.switchBtns[1];
        let muteBtnObj = this.switchBtns[3];
        btnDataObj.is_on = !btnDataObj.is_on;
        //音乐和音效都为on
        if (index === 0 || index === 1) {
          if (musicBtnObj.is_on === true && soundEffectBtnObj.is_on === true) {
            muteBtnObj = false;
          } else if (
            musicBtnObj.is_on === false &&
            soundEffectBtnObj.is_on === false
          ) {
            muteBtnObj.is_on = true;
          } else {
            muteBtnObj.is_on = false;
          }
        } else if (index === 3) {
          musicBtnObj.is_on = soundEffectBtnObj.is_on = !muteBtnObj.is_on;
        }
        this.saveUserSettingToLocal();
      },
      saveUserSettingToLocal() {
        const userSettingObj = {};
        for (const item of this.switchBtns) {
          userSettingObj[item.name] = item.is_on;
        }
        localStorage.userSetting = JSON.stringify(userSettingObj);
      }
    }
  };
</script>

<style scoped>
  .alert-setting {
    top: calc(50% - 95px);
    z-index: 9999;
    width: 250px;
    height: 190px;
    background-repeat: no-repeat;
    background-size: 100%;
    background-image: url("~indexImg/setting/bg.png");
  }
  .alert-setting > .img-btn:nth-child(1) {
    position: absolute;
    width: 20px;
    top: 13px;
    right: 3px;
  }
  .version {
    position: absolute;
    top: 35px;
    font-weight: 500;
    left: 20px;
    font-size: 10px;
  }
  .switch-btn {
    width: calc(87% - 30px);
    height: 42%;
    position: absolute;
    top: 51px;
    left: 14.5px;
    padding: 0 15px;
    justify-content: space-between;
    flex-wrap: wrap;
  }
  .switch-btn img {
    width: 45%;
  }
  .other-btn {
    width: calc(87% - 30px);
    height: 23%;
    position: absolute;
    top: calc(51px + 42%);
    left: 14.5px;
    padding: 0 15px;
    justify-content: space-around;
    /* background-color: rgba(0, 0, 0, 0.9) */
  }
  .other-btn > img {
    /* margin-right: 5px; */
    width: 60px;
  }
</style>
