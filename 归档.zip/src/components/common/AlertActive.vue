<template>
	<transition name="alertBox">
		<div class="alert-box alert-active" v-if="$store.state.alertBoxState.isShowActiveBox">
			<img class="img-btn" src="~indexImg/userinfo/win_closeBtnSelected.png" @click="isShowBox(false)">
			<div class="flex title-item add-item-bg" ref="item_activity" @click="atciveItem='activity'">
				<img src="~indexImg/active/activity_activityTitle.png" />
			</div>
			<div class="flex title-item" ref="item_announcement" @click="atciveItem='announcement'">
				<img src="~indexImg/active/activity_announcementTitle.png" />
			</div>
		</div>
	</transition>
</template>

<script>
	export default {
		data() {
			return {
				atciveItem: ''
			}
		},
		watch: {
			atciveItem: {
				handler: function(newValue) {
					const items = ['activity', 'announcement']
					const bg = require('indexImg/active/wintab_selecttab_icon.png')
					for (const item of items) {
						this.$refs[`item_${item}`].classList.remove('add-item-bg')
						this.$refs[`item_${item}`].style.backgroundImage =
							item === newValue ? `url('${bg}')` : ''
					}
				}
			}
		},
		methods: {
			isShowBox(flag) {
				this.$store.commit('setAlertBoxState', {
					isShowActiveBox: flag
				})
			}
		}
	}
</script>

<style scoped>
	.alert-active {
		top: calc(50% - 47.5%);
		z-index: 9999;
		width: 95%;
		height: 95%;
		flex-direction: column;
		justify-content: flex-end;
		background-repeat: no-repeat;
		background-size: 100% 100%;
		background-image: url('~indexImg/active/bg.png');
	}

	.alert-active .img-btn {
		position: absolute;
		width: 20px;
		top: 10px;
		right: 8px;
	}

	.title-bar {
		width: 172px;
		height: 35px;
		top: 3px;
		left: calc(50% - 90px);
		position: absolute;
		background-repeat: no-repeat;
		background-size: 100% 93%;
		background-image: url('~indexImg/active/recordTabBg.png');
	}

	.title-item:nth-child(2) {
		transform: translateZ(0);
		margin-top: 6px;
		position: absolute;
		left: 101px;
		width: 74px;
		height: 23px;
		background-repeat: no-repeat;
		background-size: 100% 100%;
	}

	.add-item-bg {
		background-image: url('~indexImg/active/wintab_selecttab_icon.png');
	}

	.title-item:nth-child(3) {
		margin-top: 6px;
		position: absolute;
		left: 174px;
		width: 74px;
		height: 23px;
		background-repeat: no-repeat;
		background-size: 100% 100%;
		/* background-image: url('~indexImg/active/wintab_selecttab_icon.png'); */
	}

	.title-item img {
		position: absolute;
		top: calc(50% - 8.5px);
		left: calc(50% - 27px);
		width: 55px;
	}
</style>
