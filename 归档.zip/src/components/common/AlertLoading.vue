<template>
  <div class="flex loading" v-if="$store.state.alertBoxState.isShowLoadingBox">
    <img :src="imgSrc">
    <img src="~loadingImg/title.png">
  </div>
</template>

<script>
  export default {
    data() {
      return {
        imgSrc: "",
        imgIndex: 0,
        timer: {},
        imgData: [
          require("../../assets/img/loading/img_1.png"),
          require("../../assets/img/loading/img_2.png")
        ]
      };
    },
    watch: {
      "$store.state.alertBoxState.isShowLoadingBox": {
        handler: function(newValue) {
          if (newValue) {
            this.startLoading();
          } else {
            clearInterval(this.timer);
          }
        }
      }
    },
    methods: {
      startLoading() {
        let $this = this;
        this.timer = setInterval(() => {
          $this.imgIndex = $this.imgIndex ? 0 : 1;
          $this.imgSrc = $this.imgData[$this.imgIndex];
        }, 100);
      }
    }
  };
</script>

<style scoped>
  .loading {
    position: absolute;
    width: 60px;
    top: 35%;
    z-index: 9999;
    flex-direction: column;
  }
  .loading > img:nth-child(1) {
    width: 40px;
  }
  .loading > img:nth-child(2) {
    width: 60px;
  }
</style>
