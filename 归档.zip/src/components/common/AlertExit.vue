<template>
  <transition name="alertBox">
    <div
      class="flex alert-box alert-exit"
      v-if="$store.state.alertBoxState.isShowExitBox"
    >
      <p>万水千山总是情，再来一局行不行？</p>
      <div class="flex btn-group">
        <img
          class="img-btn"
          @click="isShowBox(false)"
          src='~indexImg/setting/exit/getback.png'
        />
        <img
          class="img-btn"
          @click="isShowBox(false)"
          src='~indexImg/setting/exit/playForAWhile.png'
        />
      </div>
    </div>
  </transition>
</template>

<script>
    export default {
      data() {
        return {}
      },
      methods: {
        isShowBox(flag) {
          this.$store.commit('setAlertBoxState', { isShowExitBox: flag })
        },
      }
    }
</script>

<style scoped>
    .alert-exit {
      top: calc(50% - 55px);
      z-index: 9999;
      width: 190px;
      height: 100px;
      background-repeat: no-repeat;
      flex-direction: column;
      justify-content: flex-start;
      background-size: 100%;
      background-image: url('~indexImg/setting/win_commonFrameBg.png');
    }
    .alert-exit p:nth-child(1) {
      margin-top: 30px;
      font-size: 10px;
      font-weight: 600;
      color: rgb(145, 92, 27);
    }
    .btn-group{
        position: absolute;
        bottom: 15px;
        justify-content: space-around;
        width: 100%;
    }
    .btn-group>img{
        width: 35%;
    }
</style>
