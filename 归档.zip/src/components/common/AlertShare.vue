<template>
  <transition name="alertBox">
    <div class="flex alert-box alert-share" v-if="$store.state.alertBoxState.isShowShareBox">
      <img
        class="img-btn"
        src="~indexImg/share/playBackShareCloseBtn.png"
        @click="isShowBox(false)"
      >
      <img class="img-btn" src="~indexImg/share/shareto_weixin.png" @click="share('shareFriend')">
      <img
        class="img-btn"
        src="~indexImg/share/shareto_friends.png"
        @click="share('shareFriendCircle')"
      >
    </div>
  </transition>
</template>

<script>
  export default {
    data() {
      return {};
    },
    methods: {
      isShowBox(flag) {
        this.$store.commit("setAlertBoxState", { isShowShareBox: flag });
      },
      share(type) {
        this.nativeFun(type, {});
      }
    }
  };
</script>

<style scoped>
  .alert-share {
    padding-bottom: 25px;
    top: calc(50% - 85px);
    z-index: 9999;
    width: 230px;
    height: 145px;
    flex-direction: column;
    justify-content: flex-end;
    background-repeat: no-repeat;
    background-size: 100%;
    background-image: url("~indexImg/share/shareWindowBg.png");
  }
  .alert-share img:nth-child(1) {
    position: absolute;
    width: 20px;
    top: 20px;
    right: 10px;
  }
  .alert-share img:nth-child(2),
  .alert-share img:nth-child(3) {
    width: 70px;
  }
</style>
