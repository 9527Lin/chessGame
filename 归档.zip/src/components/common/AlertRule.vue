<template>
  <transition name="alertBox">
    <div
      class="alert-box alert-rule"
      v-if="$store.state.alertBoxState.isShowRuleBox"
    >
      <img
        class="img-btn"
        src="~indexImg/userinfo/win_closeBtnSelected.png"
        @click="isShowBox(false)"
      >
      <div class="flex rule-left-bar">
        <div
          v-for="item,index in imgBtns"
          class="flex left-bar-item"
          :name="item.name"
          @click="activeLabel(index,item.name)"
        >
          <img
            v-if="item.active"
            class="clickImg"
            :src="item.clicked"
          >
          <img
            v-else
            class="normalImg"
            :src="item.normal"
          />
        </div>
      </div>
      <div class="flex rule-right-content">
        <div class="flex content-top-bar">
          <div
            class="flex top-bar-item"
            v-for="item,index in ruleDetailBtns"
            :name="item.name"
            @click="activeChildLabel(index,item.name)"
          >
            <img
              v-if="item.active"
              class="clickImg"
              :src="item.clicked"
            >
            <img
              v-else
              class="normalImg"
              :src="item.normal"
            />
          </div>
        </div>
        <div class="bottom-content-item">
          <div
            :class="`flex ${childLabel_active}`"
            v-html="gameRule[label_active][childLabel_active]"
          ></div>
        </div>
      </div>
    </div>
    </div>
  </transition>
</template>

<script>
import {gameRule} from '@js/rule'
  export default {
    data() {
      return {
        label_active:'bz',
        childLabel_active:'normalRule',
        gameRule:gameRule,
        imgBtns: [
          {
            name:'bz',
            active: true,
            normal: require('indexImg/rule/bazhang_normal.png'),
            clicked: require('indexImg/rule/bazhang_clicked.png')
          },
          {
            name:'ssz',
            active: false,
            normal: require('indexImg/rule/shisanzhang_normal.png'),
            clicked: require('indexImg/rule/shisanzhang_clicked.png')
          }
        ],
        ruleDetailBtns:[
          { 
            name:'normalRule',
            active:true,
            normal:require('indexImg/rule/rules_base_normal.png'),
            clicked:require('indexImg/rule/rules_base_select.png')
          },
          { 
            name:'cardDesc',
            active:false,
            normal:require('indexImg/rule/rules_paixing_normal.png'),
            clicked:require('indexImg/rule/rules_paixing_select.png')
          },
          { 
            name:'specialRule',
            active:false,
            normal:require('indexImg/rule/rules_spec_normal.png'),
            clicked:require('indexImg/rule/rules_spec_select.png')
          }
        ]
      }
    },
    methods: {
      isShowBox(flag) {
        this.$store.commit('setAlertBoxState', { isShowRuleBox: flag })
      },
      activeLabel(index,name) {
        let imgBtns = this.imgBtns
        imgBtns[index].active = true
        for (let i = 0; i < imgBtns.length; i++) {
          const item = imgBtns[i]
          if (index !== i) {
            item.active = false
          }
        }
        this.label_active=name
      },
      activeChildLabel(index,name) {
        let ruleDetailsBtns = this.ruleDetailBtns
        ruleDetailsBtns[index].active = true
        for (let i = 0; i < ruleDetailsBtns.length; i++) {
          const item = ruleDetailsBtns[i]
          if (index !== i) {
            item.active = false
          }
        }
        this.childLabel_active=name
      }
    }
  }
</script> 

<style scoped>
  .alert-rule {
    top: calc(50% - 47.5%);
    z-index: 9999;
    width: 95%;
    height: 95%;
    flex-direction: column;
    justify-content: flex-end;
    background-repeat: no-repeat;
    background-size: 100% 100%;
    background-image: url('~indexImg/rule/bg.png');
  }
  .alert-rule .img-btn {
    position: absolute;
    width: 20px;
    top: 15px;
    right: 8px;
  }
  .rule-left-bar {
    position: absolute;
    left: 25px;
    top: 40px;
    width: 24%;
    height: 75%;
    flex-direction: column;
    justify-content: flex-start;
  }
  .left-bar-item {
    width: 100%;
    height: 24px;
    margin-bottom: 10px;
    background-size: 100%;
    justify-content: flex-start;
    background-repeat: no-repeat;
  }
  .left-bar-item .normalImg {
    width: 90%;
  }
  .left-bar-item .clickImg {
    width: 100%;
  }
  .rule-right-content{
    padding: 4px;
    position: absolute;
    flex-direction: column;
    justify-content: flex-start;
    left: 32%;
    top: calc(50% - 27.5%);
    width: calc(60% - 8px);
    height: calc(70% - 8px);
    align-items: flex-start;
  }
  .content-top-bar{
   width: 100%;
   height: 15%;
   flex-shrink: 0;
   justify-content: flex-start;
   align-items: flex-end;
  }
  .top-bar-item{
    width: 25%;
    justify-content: flex-start;
    margin-right: 3px;
  }
  .top-bar-item > img{
    width: 100%;
  }
  .bottom-content-item{
    flex: 1;
    height: 91%;
    width: 100%;
    /* background-color: rgba(0, 0, 0, 0.5) */
  }
  .normalRule,.cardDesc,.specialRule {
    padding: 5px 0;
    height: 90%;
    align-items: flex-start;
    overflow-y: auto;
    justify-content: flex-start;
    flex-direction: column;
    /* position: relative; */
  }
</style>

<style>
 .normalRule > p,span,.specialRule > p,span{
   color:#A86746;
 }
  .normalRule > p,.specialRule > p{
    font-size: 8px;
  }
  .normalRule > span,.specialRule > span{
    text-indent:1em;
    font-size: 8px;
  }
  .cardDesc img{
     width: 80%;
  }
</style>
