<template>
  <transition name="alertBox">
    <div class="alert-box alert-bz" v-if="$store.state.alertBoxState.isShowBZBox">
      <img
        class="img-btn"
        src="~indexImg/userinfo/win_closeBtnSelected.png"
        @click="isShowBox(false)"
      >
      <div class="alert-content">
        <RoomMoney></RoomMoney>
        <PeopleNum :gameType="'bz'"></PeopleNum>
        <board-num></board-num>
        <CardNum></CardNum>
        <KingCard :gameType="'bz'"></KingCard>
        <OutCardTime></OutCardTime>
        <GameDesc></GameDesc>
        <CreateRoom :gameType="'bz'"></CreateRoom>
      </div>
    </div>
  </transition>
</template>

<script>
  import RoomMoney from "../roomSetingBtn/common/roomMoney";
  import PeopleNum from "../roomSetingBtn/common/peopleNum";
  import BoardNum from "../roomSetingBtn/common/boardNum";
  import KingCard from "../roomSetingBtn/common/kingCard";
  import OutCardTime from "../roomSetingBtn/common/outCardTime";
  import CardNum from "../roomSetingBtn/BZ/cardNum";
  import GameDesc from "../roomSetingBtn/BZ/gameDesc";
  import CreateRoom from "../roomSetingBtn/common/createRoom";
  export default {
    watch: {
      "$store.state.alertBoxState.isShowBZBox": {
        handler: function(newValue) {
          if (newValue) {
            const commonSetting = this.$store.state.roomSetting.common;
          }
        }
      },
      "$store.state.roomSetting": {
        handler: function(newSetting) {
          const commonSetting = newSetting.common; //公共设置
          const BZSetting = newSetting.bz; //八张设置
          const roomSetting = Object.assign(commonSetting, BZSetting);
          localStorage.setItem("bz_roomSetting", JSON.stringify(roomSetting));
        },
        deep: true
      }
    },
    components: {
      RoomMoney,
      PeopleNum,
      BoardNum,
      KingCard,
      OutCardTime,
      CardNum,
      GameDesc,
      CreateRoom
    },
    methods: {
      isShowBox(flag) {
        this.$store.commit("setAlertBoxState", { isShowBZBox: flag });
      }
    }
  };
</script>

<style scoped>
  .alert-bz {
    top: calc(50% - 100px);
    z-index: 9999;
    width: 350px;
    height: 200px;
    background-repeat: no-repeat;
    background-size: 100%;
    background-image: url("~indexImg/bz/bg.png");
  }
  .alert-bz .img-btn:nth-child(1) {
    position: absolute;
    width: 20px;
    top: 15px;
    right: 17px;
  }
  .alert-content {
    width: calc(81.8% - 20px);
    height: 77%;
    left: 9%;
    top: 16%;
    position: absolute;
    padding: 0 10px;
  }
</style>
