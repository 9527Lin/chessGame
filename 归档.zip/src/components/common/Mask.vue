<template>
  <div
    class="mask"
    @click="hideAlert"
    v-if="$store.state.isShowMask"
  ></div>
</template>

<script>
  export default {
    methods: {
      hideAlert() {
        const alertStateObj = this.$store.state.alertBoxState;
        for (const key in alertStateObj) {
          const alertSatet = alertStateObj[key] ? false : false;
          const alertBoxObj = { [key]: alertSatet };
          this.$store.commit("setAlertBoxState", alertBoxObj);
        }
      }
    }
  };
</script>

<style scoped>
  .mask {
    z-index: 9998;
    width: 100%;
    height: 100%;
    position: absolute;
    background-color: rgba(0, 0, 0, 0.4);
  }
</style>
