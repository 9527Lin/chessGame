<template>
    <transition name="alertBox">
        <div class="alert-box alert-invite" v-if="$store.state.alertBoxState.isShowInviteBox">
            <img class="img-btn" src="~indexImg/userinfo/win_closeBtnSelected.png" @click="isShowBox(false)">
        </div>
    </transition>
</template>

<script>
    export default {
      data() {
        return {}
      },
      methods: {
        isShowBox(flag) {
          this.$store.commit('setAlertBoxState', { isShowInviteBox: flag })
        }
      }
    }
</script>

<style scoped>
    .alert-invite {
      top: calc(50% - 85px);
      z-index: 9999;
      width: 280px;
      height: 170px;
      background-repeat: no-repeat;
      background-size: 100%;
      background-image: url('~indexImg/invite/bg.png');
    }
    .alert-invite .img-btn {
      position: absolute;
      width: 20px;
      top: 10px;
      right: 0;
    }
</style>
