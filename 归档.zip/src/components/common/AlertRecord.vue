<template>
  <transition name="alertBox">
    <div class="alert-box alert-record" v-if="$store.state.alertBoxState.isShowRecordBox">
      <img class="img-btn" src="~indexImg/userinfo/win_closeBtnSelected.png" @click="isShowBox(false)">
      <div class=" flex btn-group">
        <img class="img-btn detail-btn" v-for="item in btns" :src="item.imgSrc" @click="$router.push(`/recordDetail/${item.name}`)">
      </div>
    </div>
  </transition>
</template>

<script>
  export default {
    data() {
      return {
        btns: [
          { name: 'bz', imgSrc: require('indexImg/record/bazhang.png') },
          { name: 'ssz', imgSrc: require('indexImg/record/shisanzhang.png') }
        ]
      }
    },
    mounted() {
    },
    methods: {
      isShowBox(flag) {
        this.$store.commit('setAlertBoxState', { isShowRecordBox: flag })
      },
      toDetailView(gameType) {
        this.$router.push(`/recordDetail/${gameType}`)
      }
    }
  }
</script>

<style scoped>
  .alert-record {
    top: calc(50% - 85px);
    z-index: 9999;
    width: 240px;
    height: 170px;
    background-repeat: no-repeat;
    background-size: 100%;
    background-image: url('~indexImg/record/bg.png');
  }
  .alert-record > img:nth-child(1) {
    position: absolute;
    width: 20px;
    top: 13px;
    right: 0;
  }
  .btn-group {
    position: absolute;
    top: 40px;
    left: calc(50% - 42.5%);
    width: 85%;
    height: 50%;
    /* background-color: aquamarine; */
    justify-content: flex-start;
    align-items: flex-start;
    flex-wrap: wrap;
  }
  .btn-group > img {
    margin-right: 5px;
    width: 60px;
  }
</style>
