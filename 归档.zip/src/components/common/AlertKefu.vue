<template>
    <transition name="alertBox">
        <div class="flex alert-box alert-kefu" v-if="$store.state.alertBoxState.isShowKefuBox">
            <p>若您有任何问题添加微信客服了解咨询</p>
            <p class="flex">客服微信号：<span>xxxxxxxxxx</span>
                <img class="img-btn" src='~indexImg/kefu/copyBt.png' /></p>
        </div>
    </transition>
</template>

<script>
    export default {
      data() {
        return {}
      },
      methods: {
        isShowBox(flag) {
          this.$store.commit('setAlertBoxState', { isShowKefuBox: flag })
        }
      }
    }
</script>

<style scoped>
    .alert-kefu {
      top: calc(50% - 55px);
      z-index: 9999;
      width: 200px;
      height: 110px;
      background-repeat: no-repeat;
      flex-direction: column;
      justify-content: center;
      background-size: 100%;
      background-image: url('~indexImg/kefu/win_commonFrameBg.png');
    }
    .alert-kefu p:nth-child(1) {
      font-size: 8px;
      color: rgb(145, 92, 27);
    }
    .alert-kefu p:nth-child(2) {
      margin-top: 20px;
      font-size: 8px;
      color: rgb(145, 92, 27);
    }
    .alert-kefu p:nth-child(2) span {
      font-size: 8px;
      color: red;
      margin-right: 5px;
    }
    .alert-kefu p:nth-child(2) img {
      width: 50px;
    }
</style>
