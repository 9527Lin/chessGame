<template>
  <div class="flex top-btn-bar">
    <img v-for="item in imgBtns" @click="setAlertBoxSatet(item.stateName,true)" class="img-btn" :src="item.src" />
  </div>
</template>

<script>
  export default {
    data() {
      return {
        imgBtns: [
          {
            src: require('indexImg/youxiang.png'),
            stateName: 'isShowEmailBox'
          },
          {
            src: require('indexImg/hall_sharesBtnNormal.png'),
            stateName: 'isShowShareBox'
          },
          {
            src: require('indexImg/hall_rulesBtnNormal.png'),
            stateName: 'isShowRuleBox'
          },
          {
            src: require('indexImg/hall_settingBtnNormal.png'),
            stateName: 'isShowSettingBox'
          }
        ]
      }
    },
    methods: {
      setAlertBoxSatet(boxStateName, state) {
        const alertBoxObj = { [boxStateName]: state }
        this.$store.commit('setAlertBoxState', alertBoxObj)
      }
    }
  }
</script>

<style scoped>
  .top-btn-bar {
    height: 20px;
    width: calc(100% - 260px);
    justify-content: space-around;
    align-items: flex-end;
  }
  .top-btn-bar img {
    width: 20px;
  }
</style>
