<template>
    <transition name="alertBox">
        <div class="alert-box alert-invite" v-if="$store.state.alertBoxState.isShowCircleRule">
            <img class="img-btn" src="~indexImg/userinfo/win_closeBtnSelected.png" @click="isShowBox(false)">
            <div class="text_content">
                <div>【牌友圈说明】</div>
                <div>全新牌友圈，拼桌更容易，圈主更轻松！真正的全自动化线上棋牌室</div>
                <div>【使用步骤】</div>
                <div> 1、推广员可以创建圈子，并分享至微信圈/好友；</div>
                <div> 2、好友通过申请加入圈子，圈主审核后即可成为会员；</div>
                <div> 3、牌友圈内会员可随机自动组局，无需圈主创建房间，真正的全自动化线上棋牌馆!</div>
                <div>【功能说明】</div>
                <div> 1、支付方式：支持圈主支付，也支持AA支付；</div>
                <div> 2、可视化界面：房间座位供玩家自由选择，点击座位即可进入房间，实时查看房间各用户状态；</div>
                <div> 3、会员审核：用户加入牌友圈需提交申请，圈主审核通过立即成为会员</div>
                <div> 4、自定义房间：创建圈子需配置默认房间属性，同时支持会员可自定义房间属性，以桌面颜色座位分区；</div>
                <div> 5、会员管理：圈主可点击用户头像查看会员信息，支持移除离线会员</div>
                <div> 6、数据查询：支持按照日期、圈主模式等条件筛选会员数据，并支持局数/大赢家次数排序；</div>
                <div> 7、添加会员：支持圈主添加其邀请绑定的用户直接成为会员；</div>
                <div> 8、座位同步：大厅座位即为房间座位，会员可自由选择</div>
                <div> 【开通条件】 需推广员身份且不少于500颗砖石；</div>
                <div> 【创建游戏】 支持麻将、双扣、十三张、八张、比鸡等游戏；</div>
                <div> 【圈子数量】 每个圈主最多可创建10个圈子；</div>
                <div> 【圈内成员】 每个圈子最多可邀请500人加入圈子；</div>
            </div>
        </div>
    </transition>
</template>

<script>
    export default {
        data() {
            return {}
        },
        methods: {
            isShowBox(flag) {
                this.$store.commit('setAlertBoxState', { isShowCircleRule: flag })
            }
        }
    }
</script>

<style scoped>
    .alert-invite {
        top: calc(50% - 100px);
        left:calc(50% - 45%);
        z-index: 9999;
        width: 90%;
        height: 200px;
        background-repeat: no-repeat;
        background-size: 100%;
        background-image: url('../../assets/img/cardCircle/diban.png');
    }
    .alert-invite .img-btn {
        position: absolute;
        width: 20px;
        top: 10px;
        right: 0;
    }
    .text_content{
        position: absolute;
        width: 90%;
        height: 145px;
        left:20px;
        top:35px;
        font-size: 10px;
        overflow-y: scroll;
        color: #8b6149;
    }
</style>