<template>
    <transition name="alertBox">
        <div class="alert-box alert-joinroom" v-if="$store.state.alertBoxState.isShowJoinRoomBox">
            <img class="img-btn" src="~indexImg/userinfo/win_closeBtnSelected.png" @click="isShowBox(false)">
            <div class="flex title">
                <div :class="item_1_class" @click="item_1_ActiveState=true;item_2_ActiveState=false"></div>
                <div :class="item_2_class" @click="item_2_ActiveState=true;item_1_ActiveState=false"></div>
            </div>
            <div class="flex num-input">
                <div v-for="num in roomNum" class="flex input-item">{{num}}</div>
            </div>
            <div class="flex num-keys">
                <p v-for="i in 9" :index="i+''" @click="numKeyClickEven(i+'')" class="flex key-item">
                    {{i}}
                </p>
                <p index="10" class="flex key-item" @click="cleanRoomNum">清空</p>
                <p index="11" @click="numKeyClickEven('0')" class="flex key-item">0</p>
                <p index="12" class="flex key-item" @click="deleteRoomNum">删除</p>
            </div>
        </div>
    </transition>
</template>

<script>
    export default {
      data() {
        return {
          item_1_ActiveState: true,
          item_2_ActiveState: false,
          roomNum: ['', '', '', '', '', '']
        }
      },
      mounted() {
        this.roomNum = ['', '', '', '', '', '']
      },
      computed: {
        item_1_class() {
          return this.item_1_ActiveState
            ? 'title-item title-item_1_clicked'
            : 'title-item title-item_1_normal'
        },
        item_2_class() {
          return this.item_2_ActiveState
            ? 'title-item title-item_2_clicked'
            : 'title-item title-item_2_normal'
        }
      },
      watch: {
        roomNum() {
          let isFullRoomNum = 1
          for (const item of this.roomNum) {
            isFullRoomNum *= !!item
          }
          if (isFullRoomNum) {
            console.log('加入房间操作')
          }
        }
      },
      methods: {
        isShowBox(flag) {
          this.$store.commit('setAlertBoxState', { isShowJoinRoomBox: flag })
        },
        numKeyClickEven(num) {
          console.log(num);
          
          let roomNum = this.roomNum
          for (let index = 0; index < roomNum.length; index++) {
            const item = roomNum[index]
            if (!item) {
              this.$set(roomNum, index, num)
              break
            }
          }
        },
        deleteRoomNum() {
          for (let index = 5; index >= 0; index--) {
            const element = this.roomNum[index]
            if (element) {
              this.$set(this.roomNum, index, '')
              break
            }
          }
        },
        cleanRoomNum() {
          this.roomNum = ['', '', '', '', '', '']
        }
      }
    }
</script>

<style scoped>
    .alert-joinroom {
      top: calc(50% - 48%);
      z-index: 9999;
      width: 60%;
      height: 85%;
      background-repeat: no-repeat;
      background-size: 100%;
      background-image: url('~indexImg/joinRoom/bg.png');
    }
    .alert-joinroom .img-btn {
      position: absolute;
      width: 20px;
      top: 15px;
      right: 0;
    }
    .title {
      width: 75%;
      height: 10%;
      position: absolute;
      left: calc(12.5%);
      top: 18%;
      /* background-color: rgba(0, 0, 0, 0.5); */
    }
    .title .title-item {
      width: 50%;
      height: 100%;
      background-repeat: no-repeat;
      background-size: 100%;
    }
    .title-item_1_normal {
      background-image: url('~indexImg/joinRoom/item_1_normal.png');
    }
    .title-item_1_clicked {
      background-image: url('~indexImg/joinRoom/item_1_clicked.png');
    }
    .title-item_2_normal {
      background-image: url('~indexImg/joinRoom/item_2_normal.png');
    }
    .title-item_2_clicked {
      background-image: url('~indexImg/joinRoom/item_2_clicked.png');
    }
    .num-input {
      width: 70%;
      height: 10%;
      position: absolute;
      left: 15%;
      top: 30%;
      justify-content: space-between;
      /* background-color: rgba(0, 0, 0, 0.6); */
    }
    .input-item {
      width: 14%;
      height: calc(100% - 1px);
      font-weight: 700;
      font-size: 16px;
      color: rgb(240, 201, 155);
      border-bottom: 1px bisque solid;
    }
    .num-keys {
      position: absolute;
      left: 13px;
      top: 73.5px;
      width: 88.2%;
      height: 51.3%;
      flex-wrap: wrap;
      align-items: flex-start;
      justify-content: space-between;
    }
    .key-item {
      width: 33.1%;
      height: 25%;
      font-size: 13px;
      font-weight: 700;
      color: rgb(164, 114, 72);
      /* background-color: rgba(0, 0, 255, 0.178); */
    }
    .key-item:active {
      color: white;
      background: linear-gradient(rgb(220, 134, 45), rgb(213, 86, 28));
    }
</style>
