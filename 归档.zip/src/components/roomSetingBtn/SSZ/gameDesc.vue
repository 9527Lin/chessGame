<template>
  <div class="flex game-desc">
    <p class="title">{{settingItemData.name}}:</p>
    <div class="flex btns">
      <div
        class="flex btn"
        v-for="btn,btnIndex in settingItemData.btns"
        @click="chooseBtnEven(btnIndex)"
        :ref="`btn_${btn.label}`"
      >
        <img :src="btn.active?btn.clicked:btn.normal">
        <span :class="btn.active?'btn-span':''">{{btn.name}}</span>
      </div>
      <HorseCard></HorseCard>
      <AddColor></AddColor>
    </div>
  </div>
</template>
 
<script>
  import AddColor from "./addColor";
  import HorseCard from "./horseCard";
  export default {
    data() {
      return {
        disabledAddcolor: false,
        settingItemData: {
          name: "玩法",
          label: "gameDesc",
          is_single: false,
          btns: [
            {
              name: "疯狂模式",
              label: "fk",
              active: false,
              normal: require("indexImg/bz/rect_normal_check.png"),
              clicked: require("indexImg/bz/rect_select_check.png")
            },
            {
              name: "特殊牌型",
              label: "ts",
              active: false,
              normal: require("indexImg/bz/rect_normal_check.png"),
              clicked: require("indexImg/bz/rect_select_check.png")
            },
            {
              name: "房主霸王庄",
              label: "fzbwz",
              active: false,
              normal: require("indexImg/bz/rect_normal_check.png"),
              clicked: require("indexImg/bz/rect_select_check.png")
            },
            {
              name: "中途加入",
              label: "ztjr",
              active: false,
              normal: require("indexImg/bz/rect_normal_check.png"),
              clicked: require("indexImg/bz/rect_select_check.png")
            },
            {
              name: "极速比牌",
              label: "jsbp",
              active: false,
              normal: require("indexImg/bz/rect_normal_check.png"),
              clicked: require("indexImg/bz/rect_select_check.png")
            }
          ]
        }
      };
    },
    components: { AddColor, HorseCard },
    methods: {
      chooseBtnEven(btnIndex, isCancel) {
        const activeBtns = {};
        let settingItemData = this.settingItemData;
        let btn = settingItemData.btns[btnIndex];
        this.$set(btn, "active", isCancel !== undefined ? isCancel : !btn.active);
        settingItemData.btns.filter((el, index, self) => {
          if (btn.active) {
            const btnLabel = settingItemData.btns[index].label;
            const btnIsActive = settingItemData.btns[index].active;
            activeBtns[btnLabel] = btnIsActive;
          }
        });
        //生成传输对象
        const BZSettingObj = {
          gameType: "ssz",
          label: settingItemData.label,
          value: activeBtns
        };
        this.$store.commit("setSpecialRoomSettingState", BZSettingObj);
      }
    }
  };
</script>

<style scoped>
  .game-desc {
    width: 100%;
    /* height: 12%; */
    padding: 2px 0;
    border-bottom: 0.5px #854a29 dashed;
  }
  .title {
    font-size: 8px;
    font-weight: 600;
    width: 10%;
    color: #854a29;
  }
  .btns {
    justify-content: flex-start;
    flex-wrap: wrap;
    width: 90%;
  }
  .btns .btn {
    min-width: 20%;
    width: auto;
    justify-content: flex-start;
  }
  .btns .btn img {
    margin-right: 2px;
    height: 11px;
  }
  .btns .btn span {
    white-space: nowrap;
    font-size: 6.5px;
    font-weight: 600;
    color: #854a29;
  }
  .btn-span {
    color: #b10000 !important;
  }
</style>
