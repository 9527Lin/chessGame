<template>
  <div
    class="flex btn"
    @click="chooseBtnEven"
  >
    <img :src="btn.active?btn.clicked:btn.normal">
    <span :class="btn.active?'btn-span':''">{{btn.name}}</span>
    <ChoosePoker
      :disabled="!btn.active"
      :lessLength="lessLength"
      :activeArr="activeArr"
    ></ChoosePoker>
  </div>
</template>

<script>
  import ChoosePoker from "./choosePoker";
  export default {
    data() {
      return {
        isBanClose: false, //禁止关闭选择框
        lessLength: 1, //加色数量,
        activeArr: [],
        btn: {
          name: "加色",
          label: "js",
          active: false,
          normal: require("indexImg/bz/rect_normal_check.png"),
          clicked: require("indexImg/bz/rect_select_check.png")
        }
      };
    },
    watch: {
      "btn.active": {
        handler: function(newValue) {
          if (!newValue) {
            this.setParams(1, []);
          } else {
            let peopleNum = this.$store.state.roomSetting.common.peopleNum;
            if (parseInt(peopleNum) < 5) {
              this.setParams(1, ["bt"]);
            }
          }
        }
      },
      "$store.state.roomSetting.common.peopleNum": {
        handler: function(newValue) {
          if (parseInt(newValue) < 5) {
            //默认关闭
            this.isBanClose = false;
            //取消勾选
            this.btn.active = false;
          } else {
            //禁止关闭
            this.isBanClose = true;
            //勾选
            switch (parseInt(newValue)) {
              case 5:
                this.setParams(1, ["bt"]);
                break;
              case 6:
                this.setParams(2, ["bt", "rt"]);
                break;
              case 8:
                this.setParams(4, ["bt", "rt", "mh", "fk"]);
                break;
            }
            this.btn.active = true;
          }
        },
        immediate: true
      }
    },
    methods: {
      chooseBtnEven() {
        let btn = this.btn;
        if (!this.isBanClose) {
          btn.active = !btn.active;
        }
      },
      setParams(lessLength, activeArr) {
        this.lessLength = lessLength;
        this.activeArr = activeArr;
      }
    },
    components: { ChoosePoker }
  };
</script>

<style scoped>
  .title {
    font-size: 8px;
    font-weight: 600;
    width: 10%;
    color: #854a29;
  }
  .btns {
    justify-content: flex-start;
    flex-wrap: wrap;
    width: 90%;
  }
  .btns .btn {
    /* min-width: 20%; */
    width: auto;
    margin-left: 4px;
    justify-content: flex-start;
  }
  .btns .btn > img:nth-child(1) {
    margin-right: 2px;
    height: 11px;
  }
  .btns .btn span {
    white-space: nowrap;
    font-size: 6.5px;
    font-weight: 600;
    color: #854a29;
  }
  .btn-span {
    color: #b10000 !important;
  }
</style>
