<template>
  <div
    class="flex btn"
    @click="chooseBtnEven"
  >
    <img :src="btn.active?btn.clicked:btn.normal">
    <span :class="btn.active?'btn-span':''">{{btn.name}}</span>
    <div class="flex choose-box">
      <img :src="require(`pokerImg/poker_small_0/${imgName}`)">
    </div>
    <p
      @click.stop="setAlertBoxSatet('isShowSSZ_mp_Box',true)"
      class="card-choose"
    >[切换]</p>
  </div>
</template>

<script>
  export default {
    data() {
      return {
        btn: {
          name: "马牌",
          label: "mp",
          active: false,
          normal: require("indexImg/bz/rect_normal_check.png"),
          clicked: require("indexImg/bz/rect_select_check.png")
        }
      };
    },
    watch: {
      "btn.active": {
        handler: function(isActive) {
          if (isActive) {
            let gameDescObj = {
              [this.btn.label]: this.$store.state.tempState.horseCard
            };
            this.$store.commit("setSSZHorseCardState", gameDescObj);
          } else {
            this.$store.commit("setSSZHorseCardState", {});
          }
        }
      },
      "$store.state.tempState.horseCard": {
        handler: function(newValue) {
          if (this.btn.active) {
            let gameDescObj = {
              [this.btn.label]: this.$store.state.tempState.horseCard
            };
            this.$store.commit("updateSSZHorseCardState", gameDescObj);
          }
        }
      }
    },
    computed: {
      imgName() {
        return this.$store.state.tempState.horseCard;
      }
    },
    methods: {
      chooseBtnEven() {
        let btnState = this.btn;
        btnState.active = !btnState.active;
      },
      setAlertBoxSatet(boxStateName, state) {
        const alertBoxObj = { [boxStateName]: state };
        this.$store.commit("setAlertBoxState", alertBoxObj);
      },
      requireImg(imgSrc) {
        return require(imgSrc);
      }
    }
  };
</script>

<style scoped>
  .title {
    font-size: 8px;
    font-weight: 600;
    width: 10%;
    color: #854a29;
  }
  .btns {
    justify-content: flex-start;
    flex-wrap: wrap;
    width: 90%;
  }
  .btns .btn {
    /* min-width: 20%; */
    width: auto;
    justify-content: flex-start;
  }
  .btns .btn > img:nth-child(1) {
    margin-right: 2px;
    height: 11px;
  }
  .btns .btn span {
    white-space: nowrap;
    font-size: 6.5px;
    font-weight: 600;
    color: #854a29;
  }
  .btn-span {
    color: #b10000 !important;
  }
  .choose-box {
    width: 14px;
    height: 18px;
    margin: 0 2px;
    background-size: 100%;
    background-repeat: no-repeat;
    border-radius: 2px;
    padding: 0 0.5px;
    background-image: url("~indexImg/ssz/diban.png");
  }
  .choose-box img {
    height: 16px;
  }
  .card-choose {
    font-size: 6px;
    margin-right: 2px;
    color: red;
  }
</style>
