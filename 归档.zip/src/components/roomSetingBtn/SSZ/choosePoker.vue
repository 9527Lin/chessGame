<template>
  <div class="flex choose-poker">
    <img
      v-for="btn,btnIndex in btns"
      :src="btn.active?btn.clicked:btn.normal"
      @click.stop="disabled?false:chooseBtnEven(btnIndex)"
    >
  </div>
</template>

<script>
  export default {
    props: {
      disabled: Boolean,
      lessLength: Number,
      activeArr: Array
    },
    data() {
      return {
        activeBtns: this.activeArr, //激活的按钮
        btns: [
          {
            name: "黑桃",
            label: "bt",
            active: false,
            normal: require("indexImg/ssz/mapai2Normal.png"),
            clicked: require("indexImg/ssz/mapai2Click_yellow.png")
          },
          {
            name: "红桃",
            label: "rt",
            active: false,
            normal: require("indexImg/ssz/mapai3Normal.png"),
            clicked: require("indexImg/ssz/mapai3Click_yellow.png")
          },
          {
            name: "梅花",
            label: "mh",
            active: false,
            normal: require("indexImg/ssz/mapai4Normal.png"),
            clicked: require("indexImg/ssz/mapai4Click_yellow.png")
          },
          {
            name: "方块",
            label: "fk",
            active: false,
            normal: require("indexImg/ssz/mapai1Normal.png"),
            clicked: require("indexImg/ssz/mapai1Click_yellow.png")
          }
        ]
      };
    },
    watch: {
      activeArr: {
        handler: function(newArr) {
          for (const btn of this.btns) {
            btn.active = this.activeArr.includes(btn.label) ? true : false;
            this.activeBtns = newArr;
          }
        }
      },
      activeBtns: {
        handler: function(newBtns) {
          this.$store.commit("setSSZAddcolorState", newBtns);
        }
      }
    },
    methods: {
      chooseBtnEven(btnIndex) {
        let activeBtns = this.activeBtns;
        let btn = this.btns[btnIndex];
        //判断激活按钮数组中是否已存在
        if (activeBtns.includes(btn.label)) {
          if (activeBtns.length > this.lessLength) {
            activeBtns.remove(btn.label);
          }
        } else {
          activeBtns.push(btn.label);
        }
      }
    }
  };
</script>

<style scoped>
  .choose-poker {
    width: 52px;
    height: 18px;
    background-repeat: no-repeat;
    border-radius: 2px;
    margin: 0 2px;
    background-size: 100%;
    background-image: url("~indexImg/ssz/ChooseMapiBg.png");
  }
  .choose-poker img {
    height: 16px;
  }
</style>
