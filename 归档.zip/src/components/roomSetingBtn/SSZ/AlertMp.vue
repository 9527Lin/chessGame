<template>
  <transition name="alertBox">
    <div
      class="mask"
      v-if="$store.state.alertBoxState.isShowSSZ_mp_Box"
    >
      <div class="alert-box alert-mp">
        <img
          class="img-btn"
          src="~indexImg/userinfo/win_closeBtnSelected.png"
          @click="isShowBox(false)"
        >
        <div class="flex pokerArea">
          <img
            class="img-btn"
            :ref="imgName.replace('.png','')"
            @click="cardClickEven(imgName)"
            v-for="imgName in pokerImgs"
            :src="require(`pokerImg/poker_small_0/${imgName}`)"
          >
        </div>
      </div>
    </div>
  </transition>
</template>

<script>
  //创建扑克图片数组
  //pokerType:b_m:黑色梅花;b_t:黑色桃花;r_x:红心;r_f:红方块
  const createPokerArrs = () => {
    const pokerTypes = ["b_m", "b_t", "r_x", "r_f"];
    let pokerArr = [];
    for (const pokerType of pokerTypes) {
      for (let i = 1; i < 14; i++) {
        const imgName = `${pokerType}_${i}.png`;
        pokerArr.push(imgName);
      }
    }
    return pokerArr;
  };
  export default {
    data() {
      return {
        pokerImgs: createPokerArrs()
      };
    },
    methods: {
      isShowBox(flag) {
        this.$store.commit("setAlertBoxState", { isShowSSZ_mp_Box: flag });
      },
      setAlertBoxSatet(boxStateName, state) {
        const alertBoxObj = { [boxStateName]: state };
        this.$store.commit("setAlertBoxState", alertBoxObj);
      },
      cardClickEven(imgName) {
        const tempObj = {
          label: "horseCard",
          value: imgName
        };
        this.$store.commit("setTempState", tempObj);
        this.setAlertBoxSatet("isShowSSZ_mp_Box", false);
      }
    }
  };
</script>

<style scoped>
  .alert-mp {
    left: calc(50% - 140px);
    top: calc(50% - 67.5px);
    z-index: 10000;
    width: 280px;
    height: 135px;
    background-repeat: no-repeat;
    background-size: 100%;
    background-image: url("~indexImg/ssz/mapai/diban.png");
  }
  .alert-mp > img:nth-child(1) {
    position: absolute;
    width: 20px;
    top: -5px;
    right: 0;
  }
  .mask {
    width: 100%;
    height: 100%;
    position: absolute;
    z-index: 9999;
    background-color: rgba(0, 0, 0, 0.5);
  }
  .pokerArea {
    position: absolute;
    left: calc(50% - 44.5% - 1px);
    top: calc(50% - 39% - 1px);
    width: 88%;
    height: 78%;
    flex-wrap: wrap;
    padding: 0.5px;
    justify-content: space-around;
    align-items: center;
    border-radius: 3px;
    background-color: #dec599;
  }

  .pokerArea > img {
    width: 7.2%;
  }
</style> 
