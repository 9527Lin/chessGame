<template>
  <div class="flex ratio-type">
    <div
      v-if="!disable"
      class="flex choosebtn"
      v-for="btn,btnIndex in chooseBtns"
      @click="chooseBtnEven(btnIndex)"
    >
      <img :src="btn.active?btn.clicked:btn.normal">
      <span :class="btn.active?'choosebtn-span':''">{{btn.name}}</span>
    </div>
    <div
      v-if="disable"
      class="flex choosebtn-disable"
      v-for="btn,btnIndex in chooseBtns"
    >
      <img :src="btn.disabled">
      <span>{{btn.name}}</span>
    </div>
  </div>
</template>

<script>
  export default {
    data() {
      return {
        disable: false,
        chooseBtns: [
          {
            name: "点数比",
            value: "pointsRatio",
            active: true,
            disabled: require("indexImg/ssz/check_backGroundDisabled.png"),
            normal: require("indexImg/bz/create_normal_chobox.png"),
            clicked: require("indexImg/bz/create_select_chobox.png")
          },
          {
            name: "真假比",
            value: "booleanRatio",
            active: false,
            disabled: require("indexImg/ssz/check_backGroundDisabled.png"),
            normal: require("indexImg/bz/create_normal_chobox.png"),
            clicked: require("indexImg/bz/create_select_chobox.png")
          }
        ]
      };
    },
    watch: {
      "$store.state.roomSetting.common.kingCard": {
        handler: function(newValue) {
          let sszRoomSettingObj = {};
          if (parseInt(newValue) === 0) {
            sszRoomSettingObj = {
              gameType: "ssz",
              label: "ratioType",
              value: "null"
            };
            this.disable = true;
          } else {
            sszRoomSettingObj = {
              gameType: "ssz",
              label: "ratioType",
              value: "pointRatio"
            };
            this.disable = false;
          }
          this.$store.commit("setSpecialRoomSettingState", sszRoomSettingObj);
        },
        immediate: true
      }
    },
    methods: {
      chooseBtnEven(btnIndex) {
        let btns = this.chooseBtns;
        btns.filter((el, index, self) => {
          self[index].active = index != btnIndex ? false : true;
        });
        const sszRoomSettingObj = {
          gameType: "ssz",
          label: "ratioType",
          value: btns[btnIndex].value
        };
        this.$store.commit("setSpecialRoomSettingState", sszRoomSettingObj);
      }
    }
  };
</script>

<style scoped>
  .ratio-type {
    width: 33.2%;
    background-color: #eadcaa;
    border-radius: 3px;
    height: 13px;
  }
  .choosebtn,
  .choosebtn-disable {
    min-width: 50%;
    width: auto;
    justify-content: center;
  }
  .choosebtn > img,
  .choosebtn-disable > img {
    margin-right: 2px;
    height: 11px;
  }
  .choosebtn > span,
  .choosebtn-disable > span {
    white-space: nowrap;
    font-size: 6.5px;
    font-weight: 600;
    color: #854a29;
  }
  .choosebtn-span {
    color: #b10000 !important;
  }
  .choosebtn-disable span {
    color: #bebba5;
  }
</style>
