<template>
  <div class="flex game-desc">
    <p class="title">{{settingItemData.name}}:</p>
    <div class="flex btns">
      <div
        class="flex btn"
        v-for="btn,btnIndex in settingItemData.btns"
        @click="chooseBtnEven(btnIndex)"
      >
        <img :src="btn.active?btn.clicked:btn.normal">
        <span :class="btn.active?'btn-span':''">{{btn.name}}</span>
      </div>
    </div>
  </div>
</template>
 
<script>
  export default {
    data() {
      return {
        settingItemData: {
          name: "玩法",
          label: "gameDesc",
          btns: [
            {
              name: "特殊牌型",
              label: "ts",
              active: false,
              normal: require("indexImg/bz/rect_normal_check.png"),
              clicked: require("indexImg/bz/rect_select_check.png")
            },
            {
              name: "翻车(翻倍)",
              label: "fc",
              active: false,
              normal: require("indexImg/bz/rect_normal_check.png"),
              clicked: require("indexImg/bz/rect_select_check.png")
            },
            {
              name: "红波浪",
              label: "hbl",
              active: false,
              normal: require("indexImg/bz/rect_normal_check.png"),
              clicked: require("indexImg/bz/rect_select_check.png")
            },
            {
              name: "中途加入",
              label: "ztjr",
              active: false,
              normal: require("indexImg/bz/rect_normal_check.png"),
              clicked: require("indexImg/bz/rect_select_check.png")
            },
            {
              name: "极速比牌",
              label: "jsbp",
              active: false,
              normal: require("indexImg/bz/rect_normal_check.png"),
              clicked: require("indexImg/bz/rect_select_check.png")
            }
          ]
        }
      };
    },
    methods: {
      chooseBtnEven(btnIndex) {
        const activeBtns = {};
        let settingItemData = this.settingItemData;
        let btn = settingItemData.btns[btnIndex];
        btn.active = !btn.active;
        settingItemData.btns.filter((el, index, self) => {
          if (el.active) {
            const btnLabel = settingItemData.btns[index].label;
            const btnIsActive = settingItemData.btns[index].active;
            activeBtns[btnLabel] = btnIsActive;
          }
        });
        //生成传输对象
        const BZSettingObj = {
          gameType: "bz",
          label: settingItemData.label,
          value: activeBtns
        };
        this.$store.commit("setSpecialRoomSettingState", BZSettingObj);
      }
    }
  };
</script>

<style scoped>
  .game-desc {
    width: 100%;
    height: 12%;
    border-bottom: 0.5px #854a29 dashed;
  }
  .title {
    font-size: 8px;
    font-weight: 600;
    width: 10%;
    color: #854a29;
  }
  .btns {
    justify-content: flex-start;
    flex-wrap: wrap;
    width: 90%;
  }
  .btns .btn {
    min-width: 20%;
    width: auto;
    justify-content: flex-start;
  }
  .btns .btn img {
    margin-right: 2px;
    height: 11px;
  }
  .btns .btn span {
    white-space: nowrap;
    font-size: 6.5px;
    font-weight: 600;
    color: #854a29;
  }
  .btn-span {
    color: #b10000 !important;
  }
</style>
