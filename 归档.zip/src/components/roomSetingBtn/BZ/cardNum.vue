<template>
  <div class="flex card-num">
    <p class="title">{{settingItemData.name}}:</p>
    <div class="flex btns">
      <div
        class="flex btn"
        v-for="btn,btnIndex in settingItemData.btns"
        @click="chooseBtnEven(btnIndex)"
      >
        <img :src="settingItemData.activeBtnIndex===btnIndex?btn.clicked:btn.normal">
        <span :class="settingItemData.activeBtnIndex===btnIndex?'btn-span':''">{{btn.name}}</span>
      </div>
    </div>
  </div>
</template>
 
<script>
  export default {
    data() {
      return {
        settingItemData: {
          name: "牌数",
          label: "cardNum",
          activeBtnIndex: 0,
          btns: [
            {
              name: "不去牌",
              value: "0",
              normal: require("indexImg/bz/create_normal_chobox.png"),
              clicked: require("indexImg/bz/create_select_chobox.png")
            },
            {
              name: "去掉2-4",
              value: "[2,3,4]",
              normal: require("indexImg/bz/create_normal_chobox.png"),
              clicked: require("indexImg/bz/create_select_chobox.png")
            },
            {
              name: "去掉2-6",
              value: "[2,3,4,5,6]",
              normal: require("indexImg/bz/create_normal_chobox.png"),
              clicked: require("indexImg/bz/create_select_chobox.png")
            },
            {
              name: "去掉2-7",
              value: "[2,3,4,5,6,7]",
              normal: require("indexImg/bz/create_normal_chobox.png"),
              clicked: require("indexImg/bz/create_select_chobox.png")
            },
            {
              name: "去掉2-8",
              value: "[2,3,4,5,6,7,8]",
              normal: require("indexImg/bz/create_normal_chobox.png"),
              clicked: require("indexImg/bz/create_select_chobox.png")
            }
          ]
        }
      };
    },
    methods: {
      chooseBtnEven(btnIndex) {
        let settingItemData = this.settingItemData;
        settingItemData.activeBtnIndex = btnIndex;
        //生成传输对象
        const specialSettingObj = {
          gameType: "bz",
          label: settingItemData.label,
          value: settingItemData.btns[btnIndex].value
        };
        console.log(specialSettingObj);
        this.$store.commit("setSpecialRoomSettingState", specialSettingObj);
      }
    }
  };
</script>

<style scoped>
  .card-num {
    width: 100%;
    height: 12%;
    border-bottom: 0.5px #854a29 dashed;
  }
  .title {
    font-size: 8px;
    font-weight: 600;
    width: 10%;
    color: #854a29;
  }
  .btns {
    justify-content: flex-start;
    flex-wrap: wrap;
    width: 90%;
  }
  .btns .btn {
    min-width: 16.6%;
    width: auto;
    justify-content: flex-start;
  }
  .btns .btn img {
    margin-right: 2px;
    height: 11px;
  }
  .btns .btn span {
    white-space: nowrap;
    font-size: 6.5px;
    font-weight: 600;
    color: #854a29;
  }
  .btn-span {
    color: #b10000 !important;
  }
</style>
