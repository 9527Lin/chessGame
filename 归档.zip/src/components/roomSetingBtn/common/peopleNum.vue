<template>
  <div class="flex people-num">
    <p class="title">{{settingItemData.name}}:</p>
    <div class="flex btns">
      <div
        class="flex btn"
        v-for="btn,btnIndex in settingItemData.btns"
        @click="chooseBtnEven(btnIndex)"
      >
        <img :src="settingItemData.activeBtnIndex===btnIndex?btn.clicked:btn.normal">
        <span :class="settingItemData.activeBtnIndex===btnIndex?'btn-span':''">{{btn.name}}</span>
      </div>
    </div>
  </div>
</template>
 
<script>
  const Data = {
    bz: [2, 3, 4, 5, 6],
    ssz: [2, 3, 4, 5, 6, 8]
  };
  const createBtns = gameType => {
    const btns = [];
    for (const item of Data[gameType]) {
      const btn = {
        name: `${item}人`,
        value: `${item}`,
        normal: require("indexImg/bz/create_normal_chobox.png"),
        clicked: require("indexImg/bz/create_select_chobox.png")
      };
      btns.push(btn);
    }
    return btns;
  };
  export default {
    props: {
      gameType: String
    },
    data() {
      return {
        settingItemData: {
          name: "人数",
          label: "peopleNum",
          activeBtnIndex: 0,
          btns: createBtns(this.gameType)
        }
      };
    },
    methods: {
      chooseBtnEven(btnIndex) {
        let settingItemData = this.settingItemData;
        settingItemData.activeBtnIndex = btnIndex;
        //生成传输对象
        const commonSettingObj = {
          label: settingItemData.label,
          value: settingItemData.btns[btnIndex].value
        };
        this.$store.commit("setCommonRoomSettingState", commonSettingObj);
      }
    }
  };
</script>

<style scoped>
  .people-num {
    width: 100%;
    height: 12%;
    border-bottom: 0.5px #854a29 dashed;
  }
  .title {
    font-size: 8px;
    font-weight: 600;
    width: 10%;
    color: #854a29;
  }
  .btns {
    justify-content: flex-start;
    flex-wrap: wrap;
    width: 90%;
  }
  .btns .btn {
    min-width: 16.6%;
    width: auto;
    justify-content: flex-start;
  }
  .btns .btn img {
    margin-right: 2px;
    height: 11px;
  }
  .btns .btn span {
    white-space: nowrap;
    font-size: 6.5px;
    font-weight: 600;
    color: #854a29;
  }
  .btn-span {
    color: #b10000 !important;
  }
</style>
