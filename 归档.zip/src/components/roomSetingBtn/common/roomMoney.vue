<template>
  <div class="flex room-money">
    <p class="title">{{settingItemData.name}}:</p>
    <div class="flex btns">
      <div
        class="flex btn"
        v-for="btn,btnIndex in settingItemData.btns"
        @click="chooseBtnEven(btnIndex)"
      >
        <img :src="settingItemData.activeBtnIndex===btnIndex?btn.clicked:btn.normal">
        <span :class="settingItemData.activeBtnIndex===btnIndex?'btn-span':''">{{btn.name}}</span>
      </div>
    </div>
  </div>
</template>
 
<script>
  export default {
    data() {
      return {
        settingItemData: {
          name: "房费",
          label: "roomMoney",
          activeBtnIndex: 0,
          btns: [
            {
              name: "AA制",
              value: "AA",
              normal: require("indexImg/bz/create_normal_chobox.png"),
              clicked: require("indexImg/bz/create_select_chobox.png")
            },
            {
              name: "房主",
              value: "Homeowner",
              normal: require("indexImg/bz/create_normal_chobox.png"),
              clicked: require("indexImg/bz/create_select_chobox.png")
            }
          ]
        }
      };
    },
    methods: {
      chooseBtnEven(btnIndex) {
        let settingItemData = this.settingItemData;
        settingItemData.activeBtnIndex = btnIndex;
        //生成传输对象
        const commonSettingObj = {
          label: settingItemData.label,
          value: settingItemData.btns[btnIndex].value
        };
        this.$store.commit("setCommonRoomSettingState", commonSettingObj);
      }
    }
  };
</script>

<style scoped>
  .room-money {
    width: 100%;
    height: 12%;
    border-bottom: 0.5px #854a29 dashed;
  }
  .title {
    font-size: 8px;
    font-weight: 600;
    width: 10%;
    color: #854a29;
  }
  .btns {
    justify-content: flex-start;
    flex-wrap: wrap;
    width: 90%;
  }
  .btns .btn {
    min-width: 16.6%;
    width: auto;
    justify-content: flex-start;
  }
  .btns .btn img {
    margin-right: 2px;
    height: 11px;
  }
  .btns .btn span {
    white-space: nowrap;
    font-size: 6.5px;
    font-weight: 600;
    color: #854a29;
  }
  .btn-span {
    color: #b10000 !important;
  }
</style>
