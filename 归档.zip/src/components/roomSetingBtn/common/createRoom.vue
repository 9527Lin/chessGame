<template>
  <div class="flex create-room">
    <p class="desc">备注：房间内支持提前开始，2人准备即可开始，游戏开始发牌吼扣除钻石，提前解散不扣除钻石</p>
    <img class="img-btn" @click="createRoomSetting()" src="~indexImg/bz/createRoomBtn.png">
    <p class="flex coin">
      <span>(</span>
      <img src="~indexImg/bz/house_createcard_icon.png">
      <span>x{{needCoin}})</span>
    </p>
  </div>
</template>

<script>
  export default {
    props: {
      gameType: String
    },
    watch: {
      "$store.state.gameWebscoketData": {
        handler: function(newValue) {},
        deep: true
      }
    },
    computed: {
      needCoin() {
        const unitCoin = 8;
        let roomMoneyValue = this.$store.state.roomSetting.common.roomMoney;
        let peopleNumValue = this.$store.state.roomSetting.common.peopleNum;
        return roomMoneyValue === "AA" ? unitCoin : unitCoin * peopleNumValue;
      }
    },
    methods: {
      setAlertBoxSatet(boxStateName, state) {
        const alertBoxObj = { [boxStateName]: state };
        this.$store.commit("setAlertBoxState", alertBoxObj);
      },
      //合成房间数据
      createRoomSetting() {
        let $this = this;
        let setting = {};
        let commonSetting = this.$store.state.roomSetting.common;
        if (this.gameType === "bz") {
          let bzSetting = this.$store.state.roomSetting.bz;
          setting = { ...commonSetting, ...bzSetting };
        } else {
          let sszSetting = this.$store.state.roomSetting.ssz;
          let sszGameDesc = this.$store.state.roomSetting.ssz.gameDesc;
          setting = { ...commonSetting, ...sszSetting };
        }
        this.$store.commit("setRoomSettingState", setting);
        const boxName = `isShow${this.gameType.toString().toUpperCase()}Box`;
        this.setAlertBoxSatet(boxName, false);
        //webscoket请求，连接成功后跳转
        this.setAlertBoxSatet("isShowLoadingBox", true);
        this.$store.state.gameWebscoketObj.send(
          JSON.stringify({
            action: "createRoom",
            data: this.$store.state.userInfo
          })
        );
        setTimeout(() => {
          this.setAlertBoxSatet("isShowLoadingBox", false);
          $this.$router.push("/game");
        }, 1000);
      }
    }
  };
</script>

<style scoped>
  .create-room {
    width: calc(100% - 20px);
    height: 15%;
    justify-content: space-between;
    padding-left: 20px;
  }
  .create-room .desc {
    width: 50%;
    color: #854a29;
    font-size: 5.5px;
  }
  .create-room .img-btn {
    height: 100%;
  }
  .create-room .coin {
    font-size: 8px;
  }
  .create-room .coin span {
    font-size: 8px;
    font-weight: 700;
  }
  .create-room .coin img {
    height: 10px;
  }
</style>
