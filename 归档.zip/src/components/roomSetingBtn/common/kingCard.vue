<template>
  <div class="flex king-card">
    <p class="title">{{settingItemData.name}}:</p>
    <div class="flex btns">
      <div
        class="flex btn"
        v-for="btn,btnIndex in settingItemData.btns"
        @click="chooseBtnEven(btnIndex)"
      >
        <img :src="settingItemData.activeBtnIndex===btnIndex?btn.clicked:btn.normal">
        <span :class="settingItemData.activeBtnIndex===btnIndex?'btn-span':''">{{btn.name}}</span>
      </div>
      <RatioType v-if="gameType==='ssz'"></RatioType>
    </div>
  </div>
</template>
 
<script>
  import RatioType from "../SSZ/ratioType";
  const Data = {
    bz: [
      { label: "不带王", value: "0" },
      { label: "两王", value: "2" },
      { label: "四王", value: "4" }
    ],
    ssz: [
      { label: "不带王", value: "0" },
      { label: "两王", value: "2" },
      { label: "四王", value: "4" },
      { label: "六王", value: "6" }
    ]
  };
  const createBtns = gameType => {
    const btns = [];
    for (const btnItem of Data[gameType]) {
      const btn = {
        name: btnItem.label,
        value: btnItem.value,
        normal: require("indexImg/bz/create_normal_chobox.png"),
        clicked: require("indexImg/bz/create_select_chobox.png")
      };
      btns.push(btn);
    }
    return btns;
  };
  export default {
    props: {
      gameType: String
    },
    data() {
      return {
        settingItemData: {
          name: "王牌",
          label: "kingCard",
          activeBtnIndex: 0,
          btns: createBtns(this.gameType)
        }
      };
    },
    components: { RatioType },
    methods: {
      chooseBtnEven(btnIndex) {
        let settingItemData = this.settingItemData;
        settingItemData.activeBtnIndex = btnIndex;
        //生成传输对象
        const commonSettingObj = {
          label: settingItemData.label,
          value: settingItemData.btns[btnIndex].value
        };
        this.$store.commit("setCommonRoomSettingState", commonSettingObj);
      }
    }
  };
</script>

<style scoped>
  .king-card {
    width: 100%;
    height: 12%;
    border-bottom: 0.5px #854a29 dashed;
  }
  .title {
    font-size: 8px;
    font-weight: 600;
    width: 10%;
    color: #854a29;
  }
  .btns {
    justify-content: flex-start;
    flex-wrap: wrap;
    width: 90%;
  }
  .btns .btn {
    min-width: 16.6%;
    width: auto;
    justify-content: flex-start;
  }
  .btns .btn img {
    margin-right: 2px;
    height: 11px;
  }
  .btns .btn span {
    white-space: nowrap;
    font-size: 6.5px;
    font-weight: 600;
    color: #854a29;
  }
  .btn-span {
    color: #b10000 !important;
  }
</style>
