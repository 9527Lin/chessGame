import { login } from '../apis/request_app'

async function loginProcessData() {
  const { error, errorMsg, data } = await login()
  if (error === 0) {
    //对数据进行处理
    return { error, data }
  } else {
    return { error, errorMsg }
  }
}

// async function processData() {
//   const param = {
//     $path: 'plugin.php',
//     id: 'api:index',
//     act: 'sowing',
//     cid: 4,
//     nums: 8
//   }
//   const { error, errmsg, data } = await getData_simple(param)
//   if (error === 0) {
//     //数据正确时处理
//     const newData = data[0]
//     return newData
//   } else {
//     //进行错误处理
//   }
// }
export { loginProcessData }
