const userPosition = {
  1: [
    {
      bottom: '0%',
      left: '40%'
    }
  ],
  2: [
    {
      bottom: '0%',
      left: '40%'
    },
    {
      top: '10%',
      left: '40%'
    }
  ],
  3: [
    { bottom: '0%', left: '40%' },
    { top: '10%', left: '30%' },
    { top: '10%', left: '60%' }
  ],
  4: [
    { bottom: '0%', left: '30%' },
    { bottom: '0%', left: '60%' },
    { top: '10%', left: '30%' },
    { top: '10%', left: '60%' }
  ],
  5: [
    { bottom: '0%', left: '30%' },
    { bottom: '0%', left: '60%' },
    { top: '10%', left: 'calc(25% - 12.5px)' },
    { top: '10%', left: 'calc(50% - 12.5px)' },
    { top: '10%', left: 'calc(75% - 12.5px)' }
  ],
  6: [
    { bottom: '0%', left: 'calc(25% - 12.5px)' },
    { bottom: '0%', left: 'calc(50% - 12.5px)' },
    { bottom: '0%', left: 'calc(75% - 12.5px)' },
    { top: '10%', left: 'calc(25% - 12.5px)' },
    { top: '10%', left: 'calc(50% - 12.5px)' },
    { top: '10%', left: 'calc(75% - 12.5px)' }
  ],
  8: [
    { bottom: '0%', left: 'calc(25% - 37.5px)' },
    { bottom: '0%', left: 'calc(50% - 12.5px)' },
    { bottom: '0%', left: 'calc(75% - 12.5px)' },
    { top: '10%', left: 'calc(25% - 12.5px)' },
    { top: '10%', left: 'calc(50% - 12.5px)' },
    { top: '10%', left: 'calc(75% - 12.5px)' },
    { top: '45%', left: '0%' },
    { top: '45%', right: '0%' }
  ]
}
export { userPosition }
