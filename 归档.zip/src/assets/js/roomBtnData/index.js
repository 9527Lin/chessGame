const roomBtnData = {
  bz: [
    
    {
      name: '人数',
      label: 'peopleNum',
      is_single: true,
      btns: [
        {
          name: '2人',
          value: '2',
          active: true,
          normal: require('indexImg/bz/create_normal_chobox.png'),
          clicked: require('indexImg/bz/create_select_chobox.png')
        },
        {
          name: '3人',
          value: '3',
          active: false,
          normal: require('indexImg/bz/create_normal_chobox.png'),
          clicked: require('indexImg/bz/create_select_chobox.png')
        },
        {
          name: '4人',
          value: '4',
          active: false,
          normal: require('indexImg/bz/create_normal_chobox.png'),
          clicked: require('indexImg/bz/create_select_chobox.png')
        },
        {
          name: '5人',
          value: '5',
          active: false,
          normal: require('indexImg/bz/create_normal_chobox.png'),
          clicked: require('indexImg/bz/create_select_chobox.png')
        },
        {
          name: '6人',
          value: '6',
          active: false,
          normal: require('indexImg/bz/create_normal_chobox.png'),
          clicked: require('indexImg/bz/create_select_chobox.png')
        }
      ]
    },
    {
      name: '局数',
      label: 'boardNum',
      is_single: true,
      btns: [
        {
          name: '10局',
          value: '10',
          active: true,
          normal: require('indexImg/bz/create_normal_chobox.png'),
          clicked: require('indexImg/bz/create_select_chobox.png')
        },
        {
          name: '20局',
          value: '20',
          active: false,
          normal: require('indexImg/bz/create_normal_chobox.png'),
          clicked: require('indexImg/bz/create_select_chobox.png')
        },
        {
          name: '30局',
          value: '30',
          active: false,
          normal: require('indexImg/bz/create_normal_chobox.png'),
          clicked: require('indexImg/bz/create_select_chobox.png')
        }
      ]
    },
    {
      name: '牌数',
      label: 'cardNum',
      is_single: true,
      btns: [
        {
          name: '不去牌',
          value: '0',
          active: true,
          normal: require('indexImg/bz/create_normal_chobox.png'),
          clicked: require('indexImg/bz/create_select_chobox.png')
        },
        {
          name: '去掉2-4',
          value: '[2,3,4]',
          active: false,
          normal: require('indexImg/bz/create_normal_chobox.png'),
          clicked: require('indexImg/bz/create_select_chobox.png')
        },
        {
          name: '去掉2-6',
          value: '[2,3,4,5,6]',
          active: false,
          normal: require('indexImg/bz/create_normal_chobox.png'),
          clicked: require('indexImg/bz/create_select_chobox.png')
        },
        {
          name: '去掉2-7',
          value: '[2,3,4,5,6,7]',
          active: false,
          normal: require('indexImg/bz/create_normal_chobox.png'),
          clicked: require('indexImg/bz/create_select_chobox.png')
        },
        {
          name: '去掉2-8',
          value: '[2,3,4,5,6,7,8]',
          active: false,
          normal: require('indexImg/bz/create_normal_chobox.png'),
          clicked: require('indexImg/bz/create_select_chobox.png')
        }
      ]
    },
    {
      name: '王牌',
      label: 'kingCard',
      is_single: true,
      btns: [
        {
          name: '不带王',
          value: '0',
          active: true,
          normal: require('indexImg/bz/create_normal_chobox.png'),
          clicked: require('indexImg/bz/create_select_chobox.png')
        },
        {
          name: '两个王',
          value: '2',
          active: false,
          normal: require('indexImg/bz/create_normal_chobox.png'),
          clicked: require('indexImg/bz/create_select_chobox.png')
        },
        {
          name: '四个王',
          value: '4',
          active: false,
          normal: require('indexImg/bz/create_normal_chobox.png'),
          clicked: require('indexImg/bz/create_select_chobox.png')
        }
      ]
    },
    {
      name: '出牌',
      label: 'outCardTime',
      is_single: true,
      btns: [
        {
          name: '不限时',
          value: '0',
          active: true,
          normal: require('indexImg/bz/create_normal_chobox.png'),
          clicked: require('indexImg/bz/create_select_chobox.png')
        },
        {
          name: '45秒',
          value: '45',
          active: false,
          normal: require('indexImg/bz/create_normal_chobox.png'),
          clicked: require('indexImg/bz/create_select_chobox.png')
        },
        {
          name: '60秒',
          value: '60',
          active: false,
          normal: require('indexImg/bz/create_normal_chobox.png'),
          clicked: require('indexImg/bz/create_select_chobox.png')
        },
        {
          name: '90秒',
          value: '90',
          active: false,
          normal: require('indexImg/bz/create_normal_chobox.png'),
          clicked: require('indexImg/bz/create_select_chobox.png')
        }
      ]
    },
    {
      name: '玩法',
      label: 'gameDesc',
      is_single: false,
      btns: [
        {
          name: '特殊牌型',
          label: 'ts',
          active: false,
          normal: require('indexImg/bz/rect_normal_check.png'),
          clicked: require('indexImg/bz/rect_select_check.png')
        },
        {
          name: '翻车(翻倍)',
          label: 'fc',
          active: false,
          normal: require('indexImg/bz/rect_normal_check.png'),
          clicked: require('indexImg/bz/rect_select_check.png')
        },
        {
          name: '红波浪',
          label: 'hbl',
          active: false,
          normal: require('indexImg/bz/rect_normal_check.png'),
          clicked: require('indexImg/bz/rect_select_check.png')
        },
        {
          name: '中途加入',
          label: 'ztjr',
          active: false,
          normal: require('indexImg/bz/rect_normal_check.png'),
          clicked: require('indexImg/bz/rect_select_check.png')
        },
        {
          name: '极速比牌',
          label: 'jsbp',
          active: false,
          normal: require('indexImg/bz/rect_normal_check.png'),
          clicked: require('indexImg/bz/rect_select_check.png')
        }
      ]
    }
  ],
  ssz: [
    {
      name: '房费',
      label: 'roomMoney',
      is_single: true, //是否单选
      btns: [
        {
          name: 'AA制',
          value: 'AA',
          active: true,
          normal: require('indexImg/bz/create_normal_chobox.png'),
          clicked: require('indexImg/bz/create_select_chobox.png')
        },
        {
          name: '房主',
          value: 'Homeowner',
          active: false,
          normal: require('indexImg/bz/create_normal_chobox.png'),
          clicked: require('indexImg/bz/create_select_chobox.png')
        }
      ]
    },
    {
      name: '人数',
      label: 'peopleNum',
      is_single: true,
      btns: [
        {
          name: '2人',
          value: '2',
          active: true,
          normal: require('indexImg/bz/create_normal_chobox.png'),
          clicked: require('indexImg/bz/create_select_chobox.png')
        },
        {
          name: '3人',
          value: '3',
          active: false,
          normal: require('indexImg/bz/create_normal_chobox.png'),
          clicked: require('indexImg/bz/create_select_chobox.png')
        },
        {
          name: '4人',
          value: '4',
          active: false,
          normal: require('indexImg/bz/create_normal_chobox.png'),
          clicked: require('indexImg/bz/create_select_chobox.png')
        },
        {
          name: '5人',
          value: '5',
          active: false,
          normal: require('indexImg/bz/create_normal_chobox.png'),
          clicked: require('indexImg/bz/create_select_chobox.png')
        },
        {
          name: '6人',
          value: '6',
          active: false,
          normal: require('indexImg/bz/create_normal_chobox.png'),
          clicked: require('indexImg/bz/create_select_chobox.png')
        },
        {
          name: '8人',
          value: '8',
          active: false,
          normal: require('indexImg/bz/create_normal_chobox.png'),
          clicked: require('indexImg/bz/create_select_chobox.png')
        }
      ]
    },
    {
      name: '局数',
      label: 'boardNum',
      is_single: true,
      btns: [
        {
          name: '10局',
          value: '10',
          active: true,
          normal: require('indexImg/bz/create_normal_chobox.png'),
          clicked: require('indexImg/bz/create_select_chobox.png')
        },
        {
          name: '20局',
          value: '20',
          active: false,
          normal: require('indexImg/bz/create_normal_chobox.png'),
          clicked: require('indexImg/bz/create_select_chobox.png')
        },
        {
          name: '30局',
          value: '30',
          active: false,
          normal: require('indexImg/bz/create_normal_chobox.png'),
          clicked: require('indexImg/bz/create_select_chobox.png')
        }
      ]
    },
    {
      name: '王牌',
      label: 'kingCard',
      is_single: true,
      btns: [
        {
          name: '不带王',
          value: '0',
          active: true,
          normal: require('indexImg/bz/create_normal_chobox.png'),
          clicked: require('indexImg/bz/create_select_chobox.png')
        },
        {
          name: '两王',
          value: '2',
          active: false,
          normal: require('indexImg/bz/create_normal_chobox.png'),
          clicked: require('indexImg/bz/create_select_chobox.png')
        },
        {
          name: '四王',
          value: '4',
          active: false,
          normal: require('indexImg/bz/create_normal_chobox.png'),
          clicked: require('indexImg/bz/create_select_chobox.png')
        },
        {
          name: '六王',
          value: '6',
          active: false,
          normal: require('indexImg/bz/create_normal_chobox.png'),
          clicked: require('indexImg/bz/create_select_chobox.png')
        }
      ]
    },
    {
      name: '出牌',
      label: 'outCardTime',
      is_single: true,
      btns: [
        {
          name: '不限时',
          value: '0',
          active: true,
          normal: require('indexImg/bz/create_normal_chobox.png'),
          clicked: require('indexImg/bz/create_select_chobox.png')
        },
        {
          name: '45秒',
          value: '45',
          active: false,
          normal: require('indexImg/bz/create_normal_chobox.png'),
          clicked: require('indexImg/bz/create_select_chobox.png')
        },
        {
          name: '60秒',
          value: '60',
          active: false,
          normal: require('indexImg/bz/create_normal_chobox.png'),
          clicked: require('indexImg/bz/create_select_chobox.png')
        },
        {
          name: '90秒',
          value: '90',
          active: false,
          normal: require('indexImg/bz/create_normal_chobox.png'),
          clicked: require('indexImg/bz/create_select_chobox.png')
        }
      ]
    },
    {
      name: '玩法',
      label: 'gameDesc',
      is_single: false,
      btns: [
        {
          name: '加色',
          label: 'js',
          active: false,
          normal: require('indexImg/bz/rect_normal_check.png'),
          clicked: require('indexImg/bz/rect_select_check.png')
        },
        {
          name: '马牌',
          label: 'mp',
          active: false,
          normal: require('indexImg/bz/rect_normal_check.png'),
          clicked: require('indexImg/bz/rect_select_check.png')
        },
        {
          name: '疯狂模式',
          label: 'fk',
          active: false,
          normal: require('indexImg/bz/rect_normal_check.png'),
          clicked: require('indexImg/bz/rect_select_check.png')
        },
        {
          name: '特殊牌型',
          label: 'ts',
          active: false,
          normal: require('indexImg/bz/rect_normal_check.png'),
          clicked: require('indexImg/bz/rect_select_check.png')
        },

        {
          name: '房主霸王庄',
          label: 'fzbwz',
          active: false,
          normal: require('indexImg/bz/rect_normal_check.png'),
          clicked: require('indexImg/bz/rect_select_check.png')
        },
        {
          name: '中途加入',
          label: 'ztjr',
          active: false,
          normal: require('indexImg/bz/rect_normal_check.png'),
          clicked: require('indexImg/bz/rect_select_check.png')
        },
        {
          name: '极速比牌',
          label: 'jsbp',
          active: false,
          normal: require('indexImg/bz/rect_normal_check.png'),
          clicked: require('indexImg/bz/rect_select_check.png')
        }
      ]
    }
  ]
}
export { roomBtnData }
