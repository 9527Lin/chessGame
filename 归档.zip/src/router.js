import Vue from 'vue'
import Router from 'vue-router'
//登录页
import LoginPage from './view/login'
//主页
import IndexPage from './view/index'
//商城
import ShopPage from './view/shop'
//战绩详情
import RecordDetail from './view/recordDetail'
//对战界面
import GamePage from './view/game'
// 牌友圈界面
import CardCirclePage from "./view/cardCircle"

Vue.use(Router)

const routes = [
  {
    name: 'login',
    path: '/login',
    component: LoginPage
  },
  {
    name: 'index',
    path: '/index',
    component: IndexPage
  },
  {
    name: 'shop',
    path: '/shop',
    component: ShopPage
  },
  {
    name: 'recordDetail',
    path: '/recordDetail/:gameType',
    component: RecordDetail
  },
  {
    name: 'gamePage',
    path: '/game',
    component:GamePage
  },
    {
        name: 'cardCircke',
        path: '/cardCircke',
        component:CardCirclePage
    }
]

// add route path
routes.forEach(route => {
  route.path = route.path || '/' + (route.name || '')
})

const router = new Router({ routes })

router.beforeEach((to, from, next) => {
  const title = to.meta && to.meta.title
  if (title) {
    document.title = title
  }
  next()
})

export { router }
