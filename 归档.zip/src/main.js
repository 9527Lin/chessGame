import Vue from 'vue'
import App from './App'
import { router } from './router'
import store from './store'
import 'amfe-flexible'
import { server } from './apis/request'
import VueAwesomeSwiper from 'vue-awesome-swiper'
import 'swiper/dist/css/swiper.css'
import FastClick from 'fastclick'
Vue.use(VueAwesomeSwiper)
Vue.prototype.$http = server
Array.prototype.indexOf = function(val) {
  for (var i = 0; i < this.length; i++) {
    if (this[i] == val) return i
  }
  return -1
}
Array.prototype.remove = function(val) {
  var index = this.indexOf(val)
  if (index > -1) {
    this.splice(index, 1)
  }
}
const nativeFun = (evenName, params = {}) => {
  const getUA = () => {
    let ua = navigator.userAgent
    if (ua.indexOf('Android') > -1 || ua.indexOf('Linux') > -1) {
      //安卓手机
      ua = 'android'
    } else if (ua.indexOf('iPhone') > -1) {
      ua = 'iphone'
      //苹果手机
    }
    return ua
  }
  //判断params是否为空
  if (Object.keys(params).length) {
    let dataStr = ''
    for (const key in params) {
      dataStr += `'${params[key]}',`
    }
    let newDataStr = dataStr.substring(0, dataStr.length - 1)
    getUA() === 'iphone'
      ? eval(`${evenName}(${newDataStr})`)
      : eval(`window.jsCallJavaObj.${evenName}(${newDataStr})`)
  } else {
    getUA() === 'iphone'
      ? eval(`${evenName}()`)
      : eval(`window.jsCallJavaObj.${evenName}()`)
  }
}
//定义全局变量
Vue.prototype.nativeFun = nativeFun
FastClick.attach(document.body)
new Vue({
  router,
  store,
  el: '#app',
  render: h => h(App)
})
