<template>
  <div id="app">
    <router-view v-if="isRouterAlive" style="width:100%;height:100%"></router-view>
  </div>
</template>

<script>
  // import { processData } from './datas/datas_app'
  export default {
      provide(){
          return{
              reload:this.reload
          }
      },
    data() {
      return {
        imgData: {},
        msgData: [],
          isRouterAlive:true
      };
    },
    mounted() {
      // this.getData()
    },
    methods: {
      // async getData() {
      //   const data = await processData()
      //   this.imgData = data
      // }
        reload(){
            this.isRouterAlive = false
            this.$nextTick(function () {
                this.isRouterAlive = true
            })
        }
    }
  };
</script>

<style>
  html,
  body {
    height: 100%;
    width: 100%;
    overflow-x: hidden;
  }
  body {
    margin: 0;
    font-size: 16px;
    background-color: #f8f8f8;
    -webkit-font-smoothing: antialiased;
  }
  p {
    margin: 0;
    font-size: 32px;
  }
  div {
    width: 100%;
  }
  .img-btn:active {
    /* background-color: aqua; */
    transform: scale(1.15);
  }
  .flex {
    display: flex;
    justify-content: center;
    align-items: center;
  }
  #app {
    height: 100%;
    width: 100%;
  }
  /* 弹窗 */
  .alert-box {
    position: absolute;
  }
  /* 弹窗动画 */
  .alertBox-enter-active {
    animation: alertBox 0.5s;
  }
  .alertBox-leave-active {
    animation: alertBox 0.5s reverse;
  }
  @keyframes alertBox {
    0% {
      transform: scale(0);
    }
    100% {
      transform: scale(1);
    }
  }
</style>
