import Vue from 'vue'
import Vuex from 'vuex'
Vue.use(Vuex)
export default new Vuex.Store({
  state: {
    isShowMask: false,
    alertBoxState: {
      isShowUserInfoBox: false,
      isShowEmailBox: false,
      isShowShareBox: false,
      isShowRuleBox: false,
      isShowSettingBox: false,
      isShowActiveBox: false,
      isShowRecordBox: false,
      isShowInviteBox: false,
      isShowKefuBox: false,
      isShowJoinRoomBox: false,
      isShowExitBox: false,
      isShowBZBox: false, //八张创建房间
      isShowSSZBox: false, //十三张创建房间
      isShowSSZ_mp_Box: false, //十三张创建房间,
      isShowSettingPanel: false, //进入房间游戏设置
      isShowDissRoomBox: false,
      isShowLoadingBox: false,
      isShowRobotBox: false,
      isShowInviteBox: false,
      isShowPutCard: false, //选牌界面
      isShowCircleRule: false
    },
    //用户信息
    userInfo: {
      imgSrc: '',
      nickName: '',
      sex: 0,
      userID: 3,
      allGame: 0,
      winRate: '0%',
      winGame: 12,
      failGame: 22,
      coinNum: 0 //钻石个数
    },
    roomSetting: {
      //公共部分
      common: {
        roomMoney: 'AA', //房费
        peopleNum: '2', //人数
        boardNum: '10', //局数
        kingCard: '0', //王牌
        outCardTime: '0' //出牌
      },
      ssz: {
        gameDesc: {}, //玩法
        horseCard: {}, //马牌
        addColor: [], //加色
        ratioType: 'pointRatio' //点数比
      },
      bz: {
        gameDesc: {}, //玩法
        cardNum: [] //牌数
      },
      setting: {},
      settingDescArr: [] //房间设置部分参数
    },
    tempState: {
      //过渡数据
      horseCard: 'b_t_1.png',
      //被选中牌
      selectPoker: [],
      //更新PokerCombData
      updatePokerCombData: false,
      //控制头中尾道容器
      selPokerContainerState: {
        isShow: {
          isShow_0: false,
          isShow_1: false,
          isShow_2: false
        },
        pokerData: {
          selPoker_0: [],
          selPoker_1: [],
          selPoker_2: []
        }
      }
    },
    //游戏设置
    gameSetting: {
      sound: false,
      soundEffect: false,
      backgroundImgName: 'thirteenGameBg1.png',
      //牌型
      pokerShape: 'rect',
      //牌面
      pokerName: 'poke_small_3',
      //摆牌
      putPokerType: ''
    },
    //游戏webscoketData
    gameWebscoketObj: {},
    //webscoket数据
    gameWetscoketData: {}
  },
  mutations: {
    setAlertBoxState(state, alertBoxObj) {
      const hideMaskBox = [
        'isShowSSZ_mp_Box',
        'isShowSettingPanel',
        'isShowInviteBox'
      ]
      const alertBoxStateName = Object.keys(alertBoxObj)[0]
      state.alertBoxState[alertBoxStateName] = alertBoxObj[alertBoxStateName]
      //不包含在hideMaskBox中才显示mask
      if (!hideMaskBox.includes(alertBoxStateName)) {
        state.isShowMask = alertBoxObj[alertBoxStateName]
      }
    },
    //用户数据
    setUserInfoState(state, userInfo) {
      state.userInfo = userInfo
    },
    //房间公共设置
    setCommonRoomSettingState(state, settingObj) {
      const { label, value } = settingObj
      state.roomSetting.common[label] = value
    },
    //房间特殊设置
    setSpecialRoomSettingState(state, settingObj) {
      const { gameType, label, value } = settingObj
      state.roomSetting[gameType][label] = value
    },
    //单独设置十三张HorseCardState
    setSSZHorseCardState(state, horseCardObj) {
      state.roomSetting.ssz.horseCard = horseCardObj
    },
    updateSSZHorseCardState(state, horseCardObj) {
      Object.assign(state.roomSetting.ssz.horseCard, horseCardObj)
    },
    //单独设置十三张addcolorState
    setSSZAddcolorState(state, addColorArr) {
      state.roomSetting.ssz.addColor = addColorArr
    },
    //设置最终房间数据
    setRoomSettingState(state, settingObj) {
      state.roomSetting.setting = settingObj
    },
    //设置房间部分参数说明
    setSettingDescArr(state, settingDescArr) {
      state.roomSetting.settingDescArr = settingDescArr
    },
    //过渡数据设置
    setTempState(state, stateObj) {
      const { label, value } = stateObj
      state.tempState[label] = value
    },
    //设置游戏房间数据
    setSettingState(state, settingObj) {
      const { label, value } = settingObj
      state.gameSetting[label] = value
    },
    //设置游戏webscoket对象
    setWebscoketObj(state, webscoketObj) {
      state.gameWebscoketObj = webscoketObj
    },
    //设置游戏数据
    setGameWetscoketData(state, gameData) {
      state.gameWetscoketData = gameData
    },
    //设置已选中牌数组
    setSelectPoker(state, obj) {
      const { action, cardID } = obj
      switch (action) {
        case 'add':
          state.tempState.selectPoker.push(cardID)
          break
        case 'del':
          state.tempState.selectPoker.remove(cardID)
          break
        case 'empty':
          state.tempState.selectPoker = []
          break
        default:
          break
      }
    },
    //激活或取消某张牌 按index
    setActivePokerbyIndex(state, obj) {
      const { index, isActive } = obj
      let pokerObj = state.gameWetscoketData.pokerData.pokerArr[index]
      pokerObj.active = isActive
    },
    //激活或取消某张牌 按cardID
    setActivePokerbyCardID(state, obj) {
      const { cardID, isActive } = obj
      let pokerArr = state.gameWetscoketData.pokerData.pokerArr
      pokerArr.filter((pokerObj, index, self) => {
        if (pokerObj.cardID === cardID) {
          pokerObj.active = isActive
        }
      })
    },
    //取消激活所有牌
    cancelAllActivePoker(state) {
      let pokerArr = state.gameWetscoketData.pokerData.pokerArr
      pokerArr.filter((pokerObj, index, self) => {
        pokerObj.active = false
      })
    },
    //隐藏或显示所有牌
    displayStateAllPoker(state, isShow) {
      let pokerArr = state.gameWetscoketData.pokerData.pokerArr
      pokerArr.filter((pokerObj, index, self) => {
        pokerObj.isShow = isShow
      })
    },
    //设置selectPokerContainerState
    setSelPokerContainerState(state, stateObj) {
      const { label, value, index } = stateObj
      const key = label === 'pokerData' ? 'selPoker_' : 'isShow_'
      state.tempState.selPokerContainerState[label][`${key}${index}`] = value
    },
    //清空selpoker
    clearSelPoker(state) {
      let pokerData = state.tempState.selPokerContainerState.pokerData
      for (const selPoker in pokerData) {
        pokerData[selPoker] = []
      }
    }
  },
  getters: {
    isShowSelContainer: state => index => {
      return state.tempState.selPokerContainerState.isShow[`isShow_${index}`]
    },
    selContainerPokerData: state => index => {
      return state.tempState.selPokerContainerState.pokerData[
        `selPoker_${index}`
      ]
    }
  }
})
