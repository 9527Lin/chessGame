import { fetch, post, patch, put } from './request'
async function login() {
  const requestObj = { $path: 'getUserInfo' }
  return await fetch(requestObj)
}
export { login }
