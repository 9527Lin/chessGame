<template>
  <div class="flex index-page">
    <img
      class="clound"
      src="~indexImg/cloudEffect/e@2x.png"
    ></img>
    <img
      class="clound"
      src="~indexImg/cloudEffect/er@2x.png"
    ></img>
    <img
      class="clound"
      src="~indexImg/cloudEffect/t@2x.png"
    ></img>
    <!-- 右下角星星 -->
    <img
      class="start_rb"
      src="~indexImg/DH_guangdian_1.png"
    />
    <img
      class="start_rb"
      src="~indexImg/DH_guangdian_1.png"
    />
    <!-- 湖面星星 -->
    <img
      class="start_hm"
      v-for="i in 14"
      src="~indexImg/changjing0.png"
    >
    <div class="flex top-bar">
      <div class="flex bar-left">
        <div
          class="flex avatar"
          @click="setAlertBoxSatet('isShowUserInfoBox',true)"
        >
        <img :src="avatar"></div>
        <div
          class="flex nickname"
          @click="setAlertBoxSatet('isShowUserInfoBox',true)"
        >
          <span>{{nickName}}</span>
          <span>ID:{{userID}}</span>
        </div>
        <div class="flex diamond">
          <img
            class="diamondimg"
            src="~indexImg/house_card_icon.png"
          />
          <span>{{coinNum}}</span>
          <img
            class="addbtn img-btn"
            @click="$router.push('/shop')"
            src="~indexImg/addCoinNormal.png"
          />
        </div>
      </div>
      <TopBarRight></TopBarRight>
    </div>
    <div class="flex notice">
      <img
        class="img-btn"
        src="~indexImg/systemMessageIcon.png"
      />
      <span></span>
    </div>
    <div class="flex content">
      <div class="content-left"></div>
      <div class="flex content-right">
        <swiper :options="swiperOption">
          <swiper-slide><img
              class="game-item img-btn"
              @click="$router.push('/cardCircke')"
              src="~indexImg/paiyouquan.png"
            ></swiper-slide>
          <swiper-slide><img
              class="game-item img-btn"
              @click="setAlertBoxSatet('isShowBZBox',true)"
              src="~indexImg/bazhang.png"
            ></swiper-slide>
          <swiper-slide><img
              class="game-item img-btn"
              @click="setAlertBoxSatet('isShowSSZBox',true)"
              src="~indexImg/shisanzhang.png"
            ></swiper-slide>
        </swiper>
      </div>
    </div>
    <div class="flex bottom-bar">
      <div class="flex bottom-bar-left">
        <img
          class="img-btn"
          @click="$router.push('/shop')"
          src="~indexImg/hall_shopsBtnNormal.png"
        >
        <img
          class="img-btn"
          @click="setAlertBoxSatet('isShowActiveBox',true)"
          src="~indexImg/hall_activityBtnNormal.png"
        >
        <img
          class="img-btn"
          @click="setAlertBoxSatet('isShowRecordBox',true)"
          src="~indexImg/hall_recordBtnNormal.png"
        >
        <img
          class="img-btn"
          @click="setAlertBoxSatet('isShowInviteBox',true)"
          src="~indexImg/hall_inviteBtnNormal.png"
        >
        <img
          class="img-btn"
          @click="setAlertBoxSatet('isShowKefuBox',true)"
          src="~indexImg/hall_ServiceNormal.png"
        >
      </div>
      <div class="flex bottom-bar-right">
        <img
          @click="joinRoomEven()"
          src="~indexImg/hall_joinRoomBtnNormal.png"
        />
      </div>
    </div>
    <alert-box-user-info></alert-box-user-info>
    <alert-box-email></alert-box-email>
    <alert-box-share></alert-box-share>
    <alert-box-rule></alert-box-rule>
    <alert-box-setting></alert-box-setting>
    <alert-box-active></alert-box-active>
    <alert-box-record></alert-box-record>
    <alert-box-invite></alert-box-invite>
    <alert-box-kefu></alert-box-kefu>
    <alert-box-join-room></alert-box-join-room>
    <alert-box-exit></alert-box-exit>
    <alert-box-b-z></alert-box-b-z>
    <alert-box-s-s-z></alert-box-s-s-z>
    <alert-box-m-p></alert-box-m-p>
    <alert-loading></alert-loading>
    <mask-comp></mask-comp>
  </div>
</template>

<script>
  import TopBarRight from "components/common/TopBtnBar";
  import MaskComp from "components/common/Mask";
  import AlertBoxUserInfo from "components/common/AlertUserInfo";
  import AlertBoxEmail from "components/common/AlertEmail";
  import AlertBoxShare from "components/common/AlertShare";
  import AlertBoxRule from "components/common/AlertRule";
  import AlertBoxSetting from "components/common/AlertSetting";
  import AlertBoxActive from "components/common/AlertActive";
  import AlertBoxRecord from "components/common/AlertRecord";
  import AlertBoxInvite from "components/common/AlertInvite";
  import AlertBoxKefu from "components/common/AlertKefu";
  import AlertBoxJoinRoom from "components/index/AlertJoinRoom";
  import AlertBoxExit from "components/common/AlertExit";
  import AlertBoxBZ from "components/common/AlertBZ";
  import AlertBoxSSZ from "components/common/AlertSSZ";
  import AlertBoxMP from "components/roomSetingBtn/SSZ/AlertMp";
  import AlertLoading from "components/common/AlertLoading";
  export default {
    data() {
      return {
        swiperOption: {
          slidesPerView: 3,
          spaceBetween: 30,
          freeMode: true,
          spaceBetween: 0,
          pagination: {
            el: ".swiper-pagination",
            clickable: true
          }
        }
      };
    },
    components: {
      TopBarRight,
      MaskComp,
      AlertBoxUserInfo,
      AlertBoxEmail,
      AlertBoxShare,
      AlertBoxRule,
      AlertBoxSetting,
      AlertBoxActive,
      AlertBoxRecord,
      AlertBoxInvite,
      AlertBoxKefu,
      AlertBoxJoinRoom,
      AlertBoxExit,
      AlertBoxBZ,
      AlertBoxSSZ,
      AlertBoxMP,
      AlertLoading
    },
    computed: {
       avatar(){
        return this.$store.state.userInfo.avatar
      },
      nickName(){
        return this.$store.state.userInfo.nickName
      },
      userID(){
        return this.$store.state.userInfo.userID
      },
      coinNum(){
        return this.$store.state.userInfo.coinNum
      }
    },
    methods: {
      scaleFun(even) {
        let $el = even.srcElement;
        setTimeout(() => {
          $el.style = "transform: scale(1.15);";
        }, 50);
        setTimeout(() => {
          $el.style = "transform: scale(1);";
        }, 100);
      },
      setAlertBoxSatet(boxStateName, state) {
        const alertBoxObj = { [boxStateName]: state };
        this.$store.commit("setAlertBoxState", alertBoxObj);
      },
      addCoinBtnEven(even) {},
      joinRoomEven(){
        // setAlertBoxSatet('isShowJoinRoomBox',true)
        this.$store.state.gameWebscoketObj.send(
          JSON.stringify({
            action: "joinRoom",
            data: this.$store.state.userInfo
          })
        );
        setTimeout(() => {
          // setAlertBoxSatet('isShowJoinRoomBox',false)
          this.$router.push('/game')
        }, 1000);
        
      }
    }
  };
</script>

<style scoped>
  .index-page {
    background-image: url("~indexImg/hall_HallMainBg.png");
    background-size: cover;
    flex-direction: column;
    justify-content: flex-start;
    align-items: center;
  }
  /* 顶部栏 */
  .top-bar {
    width: 100%;
    height: 23px;
    flex-shrink: 1;
    justify-content: flex-start;
    background-repeat: no-repeat;
    background-size: 105% 23px;
    background-image: url("~indexImg/hall_topBg.png");
  }
  .top-bar .bar-left {
    height: 20px;
    width: 260px;
    align-items: center;
    justify-content: flex-start;
  }
  .top-bar .bar-left .avatar {
    margin-left: 5px;
    height: 16px;
    width: 16px;
    border-radius: 3px;
    border: 0.3px solid #f1c857;
  }
  .top-bar .bar-left .avatar>img{
    border-radius: 3px;
    width: 90%;
    height: 90%;
  }
  .top-bar .bar-left .nickname {
    margin-left: 2px;
    width: 90px;
    flex-direction: column;
    align-items: flex-start;
  }
  .top-bar .bar-left .nickname span {
    font-size: 6px;
    color: white;
    font-weight: 700;
  }
  .top-bar .bar-left .diamond {
    height: 13px;
    width: 60px;
    justify-content: space-between;
    background-size: 60px 13px;
    background-image: url("~indexImg/roomCard_treasureBg.png");
  }
  .top-bar .bar-left .diamond img {
    height: 13px;
  }
  .top-bar .bar-left .diamond span {
    font-size: 8px;
    color: #f1c857;
    font-weight: 700;
  }
  .notice {
    width: 65%;
    height: 10px;
    flex-shrink: 1;
    justify-content: flex-start;
    background-size: 100% 10px;
    background-position: center;
    background-repeat: no-repeat;
    background-image: url("~indexImg/systemMessageBg.png");
  }
  .notice img {
    width: 10px;
  }
  .notice span {
    margin-left: 5%;
    width: 80%;
    height: 10px;
  }
  .content {
    flex: 0.8;
    width: 100%;
  }
  .content .content-left {
    height: 100%;
    width: 25%;
    background-position: center;
    background-repeat: no-repeat;
    background-size: auto 100%;
    z-index: 2;
    background-image: url("~indexImg/renwu/renwu.png");
  }
  .content .content-right {
    height: 100%;
    width: 75%;
  }
  .swiper-container {
    height: 80%;
  }
  .game-item {
    height: 100%;
    width: 78%;
  }
  .bottom-bar {
    position: absolute;
    padding: 2px 30px;
    width: calc(100% - 60px);
    height: 42px;
    bottom: 0;
    left: 0;
    background-position: bottom;
    justify-content: flex-start;
    align-items: flex-end;
    background-size: 100%;
    background-repeat: no-repeat;
    background-image: url("~indexImg/hall_BtnBg.png");
  }
  .bottom-bar .bottom-bar-left {
    align-items: flex-end;
    justify-content: space-between;
    width: 70%;
    height: 32px;
  }
  .bottom-bar .bottom-bar-left img {
    height: 24px;
  }
  .bottom-bar .bottom-bar-left img:nth-child(1) {
    height: 32px;
  }
  .bottom-bar .bottom-bar-right {
    width: 30%;
    height: 100%;
    justify-content: flex-end;
  }
  .bottom-bar .bottom-bar-right img {
    height: 100%;
  }

  /* 动态云 */
  @keyframes slideCould_1 {
    0% {
      right: -100px;
    }
    100% {
      right: 100%;
    }
  }
  @keyframes slideCould_2 {
    0% {
      left: -200px;
    }
    100% {
      left: 100%;
    }
  }
  @keyframes slideCould_3 {
    0% {
      left: -200px;
    }
    100% {
      left: 100%;
    }
  }
  @keyframes start_rb {
    0% {
      transform: scale(1);
    }
    50% {
      transform: scale(2);
    }
    100% {
      transform: scale(1);
    }
  }
  @keyframes satrt_hm_1 {
    0% {
      transform: rotate(-180deg) translate(1);
      opacity: 0;
    }
    50% {
      transform: rotate(-360deg) translate(2);
      opacity: 1;
    }
    100% {
      transform: rotate(-480deg) translate(1);
      opacity: 0;
    }
  }
  @keyframes satrt_hm_2 {
    0% {
      transform-origin: center;
      transform: rotate(60deg) scale(1);
      opacity: 0;
    }
    50% {
      transform-origin: center;
      transform: rotate(180deg) scale(1.15);
      opacity: 1;
    }
    100% {
      transform-origin: center;
      transform: rotate(240deg) scale(1);
      opacity: 0;
    }
  }
  .clound {
    pointer-events: none;
    position: absolute;
  }
  .clound:nth-child(1) {
    width: 100px;
    top: 10px;
    right: -100px;
    animation: slideCould_1 20s linear 2s infinite;
  }
  .clound:nth-child(2) {
    width: 100px;
    top: -10px;
    left: -200px;
    animation: slideCould_2 25s linear 2s infinite;
  }
  .clound:nth-child(3) {
    width: 100px;
    top: 60px;
    left: -200px;
    animation: slideCould_3 25s linear 2s infinite;
  }
  .start_rb,
  .start_hm {
    pointer-events: none;
    position: absolute;
  }
  .start_rb:nth-child(4) {
    bottom: 31px;
    right: 44px;
    width: 20px;
    animation: start_rb 2s infinite reverse;
  }
  .start_rb:nth-child(5) {
    bottom: 19px;
    right: 73px;
    width: 14px;
    animation: start_rb 2s infinite reverse;
  }
  .start_hm:nth-child(6) {
    top: 130px;
    left: 80px;
    width: 10px;
    animation: satrt_hm_1 0.5s infinite reverse;
  }
  .start_hm:nth-child(7) {
    top: 110px;
    width: 20px;
    animation: satrt_hm_2 1.2s infinite reverse;
  }
  .start_hm:nth-child(8) {
    top: 125px;
    left: 280px;
    width: 15px;
    animation: satrt_hm_1 0.65s infinite reverse;
  }
  .start_hm:nth-child(9) {
    top: 120px;
    left: 150px;
    width: 13px;
    animation: satrt_hm_2 0.8s infinite reverse;
  }
  .start_hm:nth-child(10) {
    top: 100px;
    left: 240px;
    width: 13px;
    animation: satrt_hm_2 0.54s infinite reverse;
  }
  .start_hm:nth-child(11) {
    top: 130px;
    left: 240px;
    width: 6px;
    animation: satrt_hm_1 0.59s infinite reverse;
  }
  .start_hm:nth-child(12) {
    top: 130px;
    left: 245px;
    width: 6px;
    animation: satrt_hm_2 0.6s infinite reverse;
  }
  .start_hm:nth-child(13) {
    top: 130px;
    left: 250px;
    width: 6px;
    animation: satrt_hm_1 0.7s infinite reverse;
  }
  .start_hm:nth-child(14) {
    top: 120px;
    left: 320px;
    width: 6px;
    animation: satrt_hm_1 0.8s infinite reverse;
  }
  .start_hm:nth-child(15) {
    top: 122px;
    left: 325px;
    width: 6px;
    animation: satrt_hm_1 0.9s infinite reverse;
  }
  .start_hm:nth-child(16) {
    top: 125px;
    left: 327px;
    width: 6px;
    animation: satrt_hm_1 0.5s infinite reverse;
  }
  .start_hm:nth-child(17) {
    top: 135px;
    left: 120px;
    width: 6px;
    animation: satrt_hm_1 0.5s infinite reverse;
  }
  .start_hm:nth-child(18) {
    top: 137px;
    left: 125px;
    width: 6px;
    animation: satrt_hm_1 2s infinite reverse;
  }
  .start_hm:nth-child(19) {
    top: 110px;
    left: 105px;
    width: 6px;
    animation: satrt_hm_1 0.4s infinite reverse;
  }
  .start_hm:nth-child(20) {
    top: 114px;
    left: 100px;
    width: 6px;
    animation: satrt_hm_2 0.9s infinite reverse;
  }
</style>
