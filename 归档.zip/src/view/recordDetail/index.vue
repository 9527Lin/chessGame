<template>
    <div class="flex record-detail">
        <img class="img-btn" @click="$router.push('/index')" src="~indexImg/record/detail/record_go_back.png">
        <div class="flex detail-list">
            <img class="no-data" src="~indexImg/record/detail/agentPlay_noData.png">
        </div>
    </div>
</template>

<script>
    export default {
      data() {
        return {}
      },
      components: {}
    }
</script>

<style scoped>
    .record-detail {
      background-image: url('~indexImg/record/detail/bg.png');
      background-size: cover;
      flex-direction: column;
      justify-content: flex-start;
      align-items: flex-start;
    }
    .record-detail > img:nth-child(1) {
      height: 30px;
    }
    .detail-list {
      flex: 1;
      padding: 20px;
      width: calc(100% - 40px);
      /* background-color: aquamarine; */
    }
    .no-data {
      width: 50%;
    }
</style>
