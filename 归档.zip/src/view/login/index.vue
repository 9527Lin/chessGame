<template>
  <div class="flex login-page">
    <div class="flex start"></div>
    <div class="flex start"></div>
    <div class="flex start"></div>
    <div class="flex start"></div>
    <div class="version">版本号:2.1.1.132/2.1/50</div>
    <div class="flex logo">
      <img class="img-btn" src="~loginImg/LOGO.png">
      <!-- <div class="eyebrow">
        <img src="~loginImg/meimao.png">
      </div>
      <div class="flex eye">
        <img class="eye-img" src="~loginImg/yangjing2.png">
      </div>-->
    </div>
    <div class="flex login-btn-group">
      <img :class="{'img-btn':checkBoxState}" :src="btnSrcs.wxBtnImgSrc" @click="wxBtnEven">
      <img
        :class="{'img-btn':checkBoxState}"
        src="~loginImg/btnKLLoginSelected.png"
        @click="klBtnEven"
      >
    </div>
    <div class="flex agreement">
      <div class="flex agreement-warp">
        <img :src="btnSrcs.checkBoxImgSrc" @click="checkBoxState=!checkBoxState">
        <span>我已经详细阅读并同意</span>
        <span @click="showAlertBox=true">小马游娱许可及服务协议</span>
      </div>
    </div>
    <div class="flex prompt">
      <span>抵制不良游戏，拒绝盗版游戏。注意自我保护，谨防上当受骗。适度游戏益脑，沉迷游戏伤身。合理安排时间，享受健康生活。</span>
    </div>
    <transition name="alertBox">
      <div class="alertBox" v-if="showAlertBox">
        <img class="alertBox-title" src="~loginImg/win_frameTitleBg.png">
        <img class="alert-title-content" src="~loginImg/protocol_title.png">
        <img
          class="alertBox-close"
          @click="showAlertBox=false"
          src="~loginImg/win_closeBtnSelected.png"
        >
        <img class="alertBox-icon" src="~loginImg/win_futext_icon.png">
      </div>
    </transition>
    <div class="mask" v-if="showAlertBox"></div>
  </div>
</template>

<script>
  import { loginProcessData } from "././../../datas/datas_app";
  let checkImg = require("../../assets/img/login/checkNormal.png");
  let checkedImg = require("../../assets/img/login/checkSelected.png");
  let wxLoginImg = require("../../assets/img/login/btnWxLoginNormal.png");
  let wxLoginSelectImg = require("../../assets/img/login/btnWxLoginSelected.png");
  let wxLoginDisableImg = require("../../assets/img/login/btnWxLoginDisable.png");
  let eye_1 = require("../../assets/img/login/yangjing2.png");
  let eye_2 = require("../../assets/img/login/yangjing3.png");
  let eye_3 = require("../../assets/img/login/yangjing4.png");
  let eye_4 = require("../../assets/img/login/yangjing5.png");
  import { userPosition } from "../../assets/js/userPostion";
  export default {
    data() {
      return {
        startAnimation: "",
        checkBoxState: true,
        showAlertBox: false,
        btnSrcs: {
          wxBtnImgSrc: wxLoginImg,
          checkBoxImgSrc: checkedImg
        },
        eyeSrcs: [eye_1, eye_2, eye_3, eye_4, eye_3, eye_2, eye_1],
        webscoket: {}
      };
    },
    watch: {
      checkBoxState(checkBoxState) {
        this.btnSrcs.checkBoxImgSrc = checkBoxState ? checkedImg : checkImg;
        this.btnSrcs.wxBtnImgSrc = checkBoxState ? wxLoginImg : wxLoginDisableImg;
      }
    },
    mounted() {
      window.loginStatus = this.loginStatus;
    },
    methods: {
      async wxBtnEven(even) {
        if (this.checkBoxState) {
          const userInfo = {
            imgSrc: "",
            nickName: "",
            sex: 0,
            userID: new Date().getSeconds(),
            allGame: 0,
            winRate: "0%",
            winGame: 12,
            failGame: 22,
            coinNum: 0 //钻石个数
          };
          this.$store.commit("setUserInfoState", userInfo);
          this.$router.push("/index");
          this.initwebscoket();
          // const result = await loginProcessData();
          // if (result.error === 0) {
          //   this.$store.commit("setUserInfoState", result.data);
          //   // this.nativeFun('login',{type:'wx'})
          //   this.$router.push("/index");
          //   this.initwebscoket();
          // } else {
          //   alert(result.errorMsg);
          // }
        }
        //后续登陆逻辑
      },
      loginStatus(data) {
        alert(data);
      },
      klBtnEven(even) {
        if (this.checkBoxState) {
          this.nativeFun("login", { type: "xl" });
        } else {
          alert(result.errorMsg);
        }
        //后续登陆逻辑
      },
      eyeAnimition() {
        let eye = document.getElementsByClassName("eye-img")[0];
        // console.log(eye);
        for (let i = 0; i < this.eyeSrcs.length; i++) {
          const eyeSrc = this.eyeSrcs[i];
          setTimeout(() => {
            eye.setAttribute("src", eyeSrc);
          }, 80 * i);
        }
      },
      //初始化webscoket连接
      initwebscoket() {
        //初始化weosocket
        const wsuri = "ws://localhost:8001";
        this.webscoket = new WebSocket(wsuri);
        this.webscoket.onopen = this.webscoketonopen;
        this.webscoket.onerror = this.webscoketonerror;
        this.webscoket.onclose = this.webscoketclose;
        this.webscoket.onmessage = this.webscoketonmessage;
        this.$store.commit("setWebscoketObj", this.webscoket);
      },
      webscoketonopen() {
        console.log("webscoket连接成功");
        const userInfoObj = {
          action: "setUserInfo",
          data: this.$store.state.userInfo
        };
        this.webscoket.send(JSON.stringify(userInfoObj));
      },
      webscoketonerror() {
        console.log("webscoketonerror:正在重新链接");
        this.initwebscoket(); //连接建立失败重连
      },
      webscoketclose() {
        console.log("webscoketclose:连接已关闭");
      },
      webscoketonmessage({ data }) {
        console.log("获取新数据");
        console.log(data);

        this.processData(JSON.parse(data));
      },
      //处理webscoketData
      processData(data) {
        const gameUserLen = data.gameUserArr.length;
        const gameUserPositionObj = userPosition[gameUserLen];
        //判断是否为房主
        const isRoomHost = () => {
          const currentUserID = this.$store.state.userInfo.userID;
          const roomHostID = data.roomHostID;
          return parseInt(currentUserID) === roomHostID;
        };
        //处理gameUserArr
        const processGameUserArr = () => {
          let oldGameUserArr = data.gameUserArr;
          // let tempGameUserArr = [];
          let newGameUserArr = [];
          let currentUserArr = {}; //当前用户对象
          const currentUserID = this.$store.state.userInfo.userID;
          //置顶当前用户
          oldGameUserArr.filter((item, index, self) => {
            if (currentUserID === item.userID) {
              currentUserArr = oldGameUserArr.splice(index, 1);
            }
          });
          newGameUserArr = currentUserArr.concat(oldGameUserArr);
          //合并userPosition
          newGameUserArr.filter((item, index, self) => {
            const positionObj = gameUserPositionObj[index];
            item.position = positionObj;
          });
          data.gameUserArr = newGameUserArr;
        };
        //为pokerArr添加isShow和isActive属性
        const addOtherAttr = () => {
          const pokerArr = data.pokerData.pokerArr;
          if (!pokerArr) return false;
          pokerArr.filter((pokerObj, index, self) => {
            pokerObj.active = false;
            pokerObj.isShow = true;
          });
        };
        //为pokerComb添加isOptional属性
        const addOptionalAttr = () => {
          const pokerComb = data.pokerData.pokerComb;
          if (!pokerComb) return false;
          for (const combName in pokerComb) {
            if (pokerComb.hasOwnProperty(combName)) {
              const comb = pokerComb[combName];
              comb.filter((item, index, self) => {
                item.isOptional = true;
              });
            }
          }
        };
        processGameUserArr();
        addOtherAttr();
        addOptionalAttr();
        this.$store.commit("setGameWetscoketData", data);
      }
    }
  };
</script>

<style scoped>
  @keyframes start {
    0% {
      transform: rotate(-90deg) scale(0);
      opacity: 0;
    }
    50% {
      transform: rotate(-180deg) scale(1.5);
      opacity: 1;
    }
    100% {
      transform: rotate(-360deg) scale(0);
      opacity: 0;
    }
  }
  .login-page {
    position: relative;
    background-image: url("~loginImg/loginBg.png");
    background-size: cover;
    justify-content: space-between;
    align-items: flex-start;
    flex-direction: column;
  }
  .version {
    width: calc(100% - 10px);
    padding: 4px;
    font-size: 7px;
    color: white;
  }
  .logo {
    position: relative;
    pointer-events: none;
    /* margin-top: -10px; */
  }
  .logo img {
    padding-right: 30px;
    width: 260px;
  }
  .logo .eyebrow {
    position: absolute;
    width: 25px;
    top: 47px;
    left: 140.5px;
    z-index: 999;
  }
  .logo .eyebrow img {
    width: 25px;
  }
  .logo .eye {
    position: absolute;
    left: 127px;
    width: 50px;
    height: 16px;
    top: 56px;
    /* background-color: wheat; */
  }
  .logo .eye img {
    height: 100%;
    /* width: 20px; */
  }
  .login-btn-group {
    margin-top: 10px;
    height: 30px;
  }

  .login-btn-group img {
    width: 70px;
    height: 23px;
  }
  .login-btn-group img:nth-child(1) {
    padding-right: 15px;
  }

  .login-btn-group img:nth-child(2) {
    padding-right: 15px;
  }
  .agreement {
    height: 15px;
    font-size: 6px;
  }
  .agreement-warp {
    width: 40%;
    height: 100%;
    background-size: cover;
    background-image: url("~loginImg/bottomTipInfoBg.png");
  }
  .agreement img {
    width: 8px;
  }
  .agreement span:nth-child(2) {
    color: white;
  }
  .agreement span:nth-child(3) {
    color: rgb(138, 194, 121);
  }
  .prompt {
    color: white;
    font-size: 6px;
  }
  .prompt span {
    -webkit-user-select: none;
    user-select: none;
  }
  .alertBox {
    position: absolute;
    z-index: 9999;
    top: 18px;
    width: 98%;
    left: 1%;
    height: 90%;
    background-repeat: no-repeat;
    background-size: 100% 98%;
    background-image: url("~loginImg/win_commonFrameBg.png");
  }
  .alertBox-title {
    position: absolute;
    width: 100px;
    top: -15px;
    left: calc(50% - 50px);
  }
  .alert-title-content {
    width: 55px;
    top: -13px;
    left: calc(50% - 27.5px);
    position: absolute;
  }
  .alertBox-close {
    width: 20px;
    position: absolute;
    left: 95%;
    top: -4px;
  }
  .alertBox-icon {
    position: absolute;
    width: 15px;
    left: 96%;
    top: 15px;
  }
  .start {
    position: absolute;
    background-image: url("~loginImg/DH_guangdian_1.png");
    background-size: cover;
    animation: start 2s infinite reverse;
  }
  .start:nth-child(1) {
    width: 15px;
    height: 15px;
    top: 100px;
    left: 40px;
  }
  .start:nth-child(2) {
    width: 20px;
    height: 20px;
    top: 70px;
    left: 350px;
  }
  .start:nth-child(3) {
    width: 20px;
    height: 20px;
    top: 0px;
    left: 170px;
  }
  .start:nth-child(4) {
    width: 7px;
    height: 7px;
    top: 120px;
    left: 60px;
  }
</style>
