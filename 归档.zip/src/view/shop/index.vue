<template>
  <div class="flex shop-page">
    <div class="flex top-bar">
      <div class="flex bar-left">
        <img @click="$router.push('/index')" class="img-btn" src="~indexImg/shop/topbarBackIcon.png">
        <img src="~indexImg/shop/shopNavBarTitleIcon.png">
        <div class="flex diamond">
          <img class="diamondimg" src="~indexImg/house_card_icon.png" />
          <span>100</span>
        </div>
      </div>
      <TopBarRight></TopBarRight>
    </div>
    <div class="flex content">
      <div class="content-left">
        <img src="~indexImg/shop/shopLeftTabZS_1.png" />
      </div>
      <div class="flex content-right">
        <div class="flex goods-item" v-for="item,index in zsArr">
          <img :src="require(`indexImg/shop/money/house_card_${index}.png`)">
          <img :src="require(`indexImg/shop/money/g_${index}.png`)">
          <img :src="require(`indexImg/shop/money/m_${index}.png`)">
          <img :src="item.stateImg">
          <div v-if="item.desc">{{item.desc}}</div>
        </div>
      </div>
    </div>
    <p class="prompt">钻石一毛一颗，多买多送</p>
    <alert-box-email></alert-box-email>
    <alert-box-share></alert-box-share>
    <alert-box-rule></alert-box-rule>
    <alert-box-setting></alert-box-setting>
    <alert-box-exit></alert-box-exit>
    <MaskComp></MaskComp>
  </div>
</template>

<script>
  let hotBuy_img = require('indexImg/shop/shop_hot_buy.png')
  let hotTime_img = require('indexImg/shop/shop_hot_time.png')
  import TopBarRight from 'components/common/TopBtnBar'
  import MaskComp from 'components/common/Mask'
  import AlertBoxEmail from 'components/common/AlertEmail'
  import AlertBoxShare from 'components/common/AlertShare'
  import AlertBoxRule from 'components/common/AlertRule'
  import AlertBoxSetting from 'components/common/AlertSetting'
  import AlertBoxExit from 'components/common/AlertExit'
  export default {
    data() {
      return {
        zsArr: [
          { num: 100, money: 10, desc: '', stateImg: '' },
          { num: 200, money: 20, desc: '多送10', stateImg: '' },
          { num: 500, money: 50, desc: '多送35', stateImg: hotBuy_img },
          { num: 1000, money: 100, desc: '多送100', stateImg: hotBuy_img },
          { num: 2000, money: 200, desc: '多送400', stateImg: hotTime_img },
          { num: 3000, money: 300, desc: '多送900', stateImg: hotTime_img },
          { num: 5000, money: 500, desc: '多送3000', stateImg: hotTime_img },
          { num: 10000, money: 1000, desc: '多送7000', stateImg: hotTime_img }
        ]
      }
    },
    components: {
      TopBarRight,
      MaskComp,
      AlertBoxEmail,
      AlertBoxShare,
      AlertBoxRule,
      AlertBoxSetting,
      AlertBoxExit
    },
    methods: {
      emailBtnEven(even) {},
      shareBtnEven(even) {},
      ruleBtnEven(even) {},
      settingBtnEven(even) {}
    }
  }
</script>

<style scoped>
  .shop-page {
    background-image: url('~indexImg/shop/hall_HallMainBg.png');
    background-size: cover;
    flex-direction: column;
    justify-content: flex-start;
    align-items: center;
  }
  /* 顶部栏 */
  .top-bar {
    width: 100%;
    height: 23px;
    flex-shrink: 1;
    justify-content: flex-start;
    background-repeat: no-repeat;
    background-size: 105% 23px;
    background-image: url('~indexImg/hall_topBg.png');
  }
  .top-bar .bar-left {
    height: 20px;
    width: 260px;
    align-items: center;
    justify-content: flex-start;
  }
  .top-bar .bar-left img:nth-child(1) {
    height: 20px;
  }
  .top-bar .bar-left img:nth-child(2) {
    height: 14px;
    margin-left: 20px;
  }
  .top-bar .bar-left .diamond {
    margin-left: 20px;
    height: 13px;
    width: 60px;
    justify-content: flex-start;
    background-size: 60px 13px;
    background-image: url('~indexImg/roomCard_treasureBg.png');
  }
  .top-bar .bar-left .diamond img {
    height: 13px;
  }
  .top-bar .bar-left .diamond span {
    margin-left: 5px;
    font-size: 8px;
    color: #f1c857;
    font-weight: 700;
  }
  .content {
    width: 100%;
    height: 100%;
    flex: 1;
  }
  .content-left {
    height: 100%;
    width: 13%;
    background-image: url('~indexImg/shop/shopLeftTabBg.png');
  }
  .content-left img {
    width: 110%;
    margin-top: 10px;
  }
  .content-right {
    padding: 10px;
    width: calc(100% - 20px);
    height: calc(100% - 20px);
    align-items: flex-start;
    justify-content: space-around;
    flex-wrap: wrap;
  }
  .goods-item {
    width: 70px;
    height: 60px;
    padding: 5px 0;
    position: relative;
    flex-direction: column;
    justify-content: space-between;
    background-size: 100%;
    background-repeat: no-repeat;
    background-image: url('~indexImg/shop/shop_rechargeItemBg.png');
  }
  .goods-item img:nth-child(1) {
    height: 30px;
  }
  .goods-item img:nth-child(2) {
    width: 35px;
  }
  .goods-item img:nth-child(3) {
    width: 50px;
  }
  .goods-item img:nth-child(4) {
    width: 29px;
    position: absolute;
    top: 0;
    left: 0.5px;
  }
  .goods-item div {
    position: absolute;
    color: #e95510;
    font-size: 5px;
    text-align: center;
    top: -2px;
    right: -5px;
    width: 34px;
    height: 15px;
    background-size: 100%;
    background-repeat: no-repeat;
    background-image: url('~indexImg/shop/money/bubble_icon_bg.png');
  }
  .prompt {
    position: absolute;
    bottom: 5px;
    right: 15px;
    color: rgb(182, 179, 179);
    font-size: 8px;
  }
</style>
