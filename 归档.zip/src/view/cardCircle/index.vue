<template>
    <div class="cardCircle">
        <div class="flex top-bar">
            <div class="flex bar-left">
                <img @click="$router.push('/index')" class="img-btn" src="~indexImg/shop/topbarBackIcon.png">
                <div @click="$router.push('/shop')" class="flex diamond">
                    <img class="diamondimg" src="~indexImg/house_card_icon.png" />
                    <span>100</span>
                </div>
            </div>
            <div class="top-btn-bar">
                <img @click="open_rule" class="img-btn" src="../../assets/img/cardCircle/gameLobbyPlayHow.png"/>
                <img @click="refresh" class="img-btn" src="../../assets/img/cardCircle/gameLobbyRefresh.png"/>
            </div>
        </div>
        <!--背景图-->
        <img class="background_img" src="../../assets/img/cardCircle/background.png"/>
        <!--底下按钮-->
        <div class="btn_box">
            <img @click="create_game" class="img-btn" src="../../assets/img/cardCircle/gameLobbyCreate.png"/>
            <img @click="join_room" class="img-btn" src="../../assets/img/cardCircle/gameLobbyJoin.png"/>
        </div>
        <!--加入房间弹窗-->
        <alert-box-join-room class="alert_join"></alert-box-join-room>
        <!--创建房间弹窗-->
        <alert-box-record class="alert_create"></alert-box-record>
        <!--规则弹窗-->
        <alert-circle-rule></alert-circle-rule>
        <!--遮罩层-->
        <mask-comp style="top: 0px;left: 0px;"></mask-comp>
    </div>
</template>
<script>
    import AlertBoxJoinRoom from "components/index/AlertJoinRoom";
    import AlertBoxRecord from "components/common/AlertRecord";
    import AlertCircleRule from "components/cardCircle/AlertCircleRule";
    import MaskComp from "components/common/Mask";
    export default {
        inject:["reload"],
        data() {
            return {

            }
        },
        computed: {

        },
        methods: {
            create_game:function () {
                this.$store.commit('setAlertBoxState', { isShowRecordBox: true })
            },
            join_room:function () {
                this.$store.commit('setAlertBoxState', { isShowJoinRoomBox: true })
            },
            open_rule:function () {
                this.$store.commit('setAlertBoxState', { isShowCircleRule: true })
            },
            refresh:function () {
                this.reload()
            }
        },
        components: {
            AlertBoxJoinRoom,
            AlertBoxRecord,
            AlertCircleRule,
            MaskComp
        }
    }
</script>
<style scoped>
    .cardCircle{
        width: 100%;height: 100%;position: relative
    }
    .background_img{
        position: absolute;top: 0px;left: 0px;width: 100%;height: 100%;z-index: -1
    }
    .btn_box{
        position: fixed;bottom: 0px;left: 0px;width: 100%;height: 28px;background-color:rgba(255,255,255,0.4);box-sizing: border-box;display: flex;justify-content: center
    }
    .btn_box >img{
        height: 20px;margin: 5px 30px;
    }
    /* 顶部栏 */
    .top-bar {
        width: 100%;
        height: 23px;
        flex-shrink: 1;
        background-repeat: no-repeat;
        background-size: 48% 23px;
        background-image: url('~indexImg/hall_topBg.png');
        justify-content: space-between !important;
    }
    .top-bar .bar-left {
        height: 20px;
        width: 200px;
        align-items: center;
        justify-content: flex-start;
    }
    .top-bar .bar-left img:nth-child(1) {
        height: 20px;
    }
    .top-bar .bar-left img:nth-child(2) {
        height: 14px;
        margin-left: 20px;
    }
    .top-bar .bar-left .diamond {
        height: 13px;
        width: 60px;
        justify-content: flex-start;
        background-size: 60px 13px;
        background-image: url('~indexImg/roomCard_treasureBg.png');
    }
    .top-bar .bar-left .diamond img {
        height: 13px;
    }
    .top-bar .bar-left .diamond span {
        margin-left: 5px;
        font-size: 8px;
        color: #f1c857;
        font-weight: 700;
    }
    .top-btn-bar {
        height: 20px;
        width: 60px;
        justify-content: space-around;
        align-items: flex-end;
    }
    .top-btn-bar img {
        width: 20px;
        margin-right:5px;
    }
    .alert_join{
        left:calc(50% - 30%);
    }
    .alert_create{
        left:calc(50% - 120px);
    }
</style>