<template>
  <div class="flex" :style="gamePageClass">
    <div class="flex top-bar">
      <div class="room-msg">
        <p>房号:{{gameData('roomNum')}} {{gameData('currentGame')}}/{{gameData('allGame')}}</p>
        <p>特殊牌型 四个王 翻倍 红波浪 去掉2-4</p>
      </div>
      <img
        class="setting-btn img-btn"
        src="~gameImg/openSettingBtnNormal.png"
        @click="setAlertBoxSatet('isShowSettingPanel',true)"
      >
    </div>
    <img
      class="hosting img-btn"
      src="~gameImg/trusteeshipBt.png"
      @click="setAlertBoxSatet('isShowRobotBox',true)"
    >
    <img class="game-name" src="~gameImg/eightBgTip4.png">
    <div v-if="$store.state.gameWetscoketData.gameStatus==='joinRoomed'">
      <!-- 房主端 -->
      <div class="flex btn-group_roomhost" v-if="isRoomHost">
        <img
          v-if="!isFullPeople"
          class="img-btn"
          src="~gameImg/inviteWeixinFriendBtnNormal.png"
          @click="setAlertBoxSatet('isShowInviteBox',true)"
        >
        <img
          v-if="isStartGame"
          class="img-btn"
          src="~gameImg/immediatelyStartBtnNormal.png"
          @click="immediatelyStart"
        >
        <img
          v-if="!isStartGame"
          class="img-btn"
          src="~gameImg/immediatelyStartBtnDisable.png"
        >
        <img v-if="!isFullPeople" class="img-btn" src="~gameImg/copyRoomIdBt.png">
      </div>
      <!-- 成员端 -->
      <div class="flex btn-group_people" v-else>
        <img
          v-if="!isFullPeople"
          class="img-btn"
          src="~gameImg/inviteWeixinFriendBtnNormal.png"
          @click="setAlertBoxSatet('isShowInviteBox',true)"
        >
        <img
          class="img-btn"
          src="~gameImg/readyStartBtnNormal.png"
          v-if="hideReadyBtn"
          @click="gameReady()"
        >
        <img v-if="!isFullPeople" class="img-btn" src="~gameImg/copyRoomIdBt.png">
      </div>
    </div>
    <game-setting></game-setting>
    <alert-box-rule></alert-box-rule>
    <alert-robot-box></alert-robot-box>
    <alert-box-diss-room></alert-box-diss-room>
    <mask-comp></mask-comp>
    <alert-invite-box></alert-invite-box>
    <player-box v-for="gameUser in gameData('gameUserArr')" :gameUser="gameUser"></player-box>
    <put-card></put-card>
  </div>
</template>
<script>
  import GameSetting from "../../components/game/gameSetting";
  import AlertBoxRule from "../../components/common/AlertRule";
  import AlertBoxDissRoom from "../../components/game/AlertDissRoom";
  import MaskComp from "components/common/Mask";
  import AlertRobotBox from "components/game/AlertRobot";
  import AlertInviteBox from "components/game/AlertInvite";
  import PlayerBox from "components/game/playerBox";
  import PutCard from "components/game/putCard";
  export default {
    data() {
      return {
        hideReadyBtn: true
      };
    },
    components: {
      GameSetting,
      AlertBoxRule,
      MaskComp,
      AlertBoxDissRoom,
      AlertRobotBox,
      AlertInviteBox,
      PlayerBox,
      PutCard
    },
    watch: {
      "$store.state.gameWetscoketData.gameStatus"(newValue) {
        if (newValue === "startGame") {
          this.setAlertBoxSatet("isShowPutCard", true);
        }
      }
    },
    computed: {
      gamePageClass() {
        const imgName = this.$store.state.gameSetting.backgroundImgName;
        const imgSrc = require(`gameImg/${imgName}`);
        return {
          backgroundImage: `url("${imgSrc}")`,
          backgroundSize: "cover",
          flexDirection: "column",
          justifyContent: "flex-start",
          alignItems: "center"
        };
      },
      getCenterImg() {
        const immediatelyStartBtn = require("gameImg/immediatelyStartBtnDisable.png");
        const readyStartBtnNormal = require("gameImg/readyStartBtnNormal.png");
        return this.isHomeowner ? immediatelyStartBtn : readyStartBtnNormal;
      },
      //判断是否为房主
      isRoomHost() {
        const userID = this.$store.state.userInfo.userID;
        const roomHostID = this.gameData("roomHostID");
        return parseInt(userID) === parseInt(roomHostID);
      },
      //判断人员是否到齐
      isFullPeople() {
        const setPeopleNum =
          this.$store.state.roomSetting.setting.peopleNum ||
          this.gameData("gamePeopleNum");
        let currentPeopleNum = 0;
        this.$nextTick(() => {
          currentPeopleNum = this.gameData("gameUserArr").length;
        });
        return parseInt(setPeopleNum) === currentPeopleNum;
      },
      //判断房主是否可以提前开始游戏
      isStartGame() {
        let countIsReady = 0;
        const currentPeopleNum = this.gameData("gameUserArr");
        currentPeopleNum.filter((item, index, self) => {
          if (item.isReady) {
            countIsReady++;
          }
        });
        return countIsReady >= 2;
      }
    },
    methods: {
      gameData(key) {
        return this.$store.state.gameWetscoketData[key];
      },
      setAlertBoxSatet(boxStateName, state) {
        const alertBoxObj = { [boxStateName]: state };
        this.$store.commit("setAlertBoxState", alertBoxObj);
      },
      gameReady() {
        const userID = this.$store.state.userInfo.userID;
        this.$store.state.gameWebscoketObj.send(
          JSON.stringify({
            action: "ready",
            data: { userID: userID }
          })
        );
        this.hideReadyBtn = false;
      },
      //提前开始
      immediatelyStart() {
        let $this = this;
        this.$store.state.gameWebscoketObj.send(
          JSON.stringify({
            action: "startGame",
            data: {}
          })
        );
      }
    }
  };
</script>

<style scoped>
  .game-page {
    background-image: url("~gameImg/thirteenGameBg1.png");
    background-size: cover;
    flex-direction: column;
    justify-content: flex-start;
    align-items: center;
  }

  .top-bar {
    width: calc(100% - 6px);
    top: 0;
    left: 0;
    padding: 0 3px;
    position: absolute;
    justify-content: space-between;
    height: 25px;
    background-repeat: no-repeat;
    background-size: 30% 100%;
    background-image: url("~gameImg/roomNumberBg.png");
  }

  .room-msg {
    color: white;
    justify-content: flex-start;
    flex-direction: column;
  }

  .room-msg > p:nth-child(1) {
    font-size: 8px;
  }

  .room-msg > p:nth-child(2) {
    font-size: 6px;
  }

  .top-bar img {
    height: 80%;
  }

  .hosting {
    position: absolute;
    left: 5px;
    top: 30px;
    width: 20px;
  }

  .game-name {
    position: absolute;
    width: 35px;
    height: 18px;
    top: calc(50% - 9px);
    left: calc(50% - 17.5px);
  }

  .btn-group_roomhost,
  .btn-group_people {
    justify-content: center;
    position: absolute;
    left: calc(50% - 80px);
    top: 50%;
    flex-wrap: wrap;
    width: 160px;
    height: 70px;
    /* background-color: rgba(0, 0, 0, 0.7); */
  }

  .btn-group_roomhost > img,
  .btn-group_people > img {
    width: 60px;
  }

  .btn-group_roomhost > img:nth-child(1),
  .btn-group_people > img:nth-child(1) {
    margin: 0 10px;
  }

  .btn-group_roomhost > img:nth-child(2),
  .btn-group_people > img:nth-child(2) {
    margin: 0 10px;
  }

  .setting-panel {
    position: absolute;
    right: 0;
    top: 0;
    height: 100%;
    width: 60%;
    background-size: cover;
    background-repeat: no-repeat;
    background-image: url("~gameImg/setting/roomSettingBg.png");
    /* background-color: rgba(0, 0, 0, 0.6); */
  }
</style>
